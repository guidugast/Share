 /*******************************************************************************
  * @file    TODO.c
  * @author  MCD Application Team
  * @brief   TODO
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
#if defined(RF_LLD_VALIDATION)
////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#ifdef STM32WB55xx
  #include "stm32wb55xx.h"
#endif
#ifdef STM32WB35xx
  #include "stm32wb35xx.h"
#endif
#ifdef STM32WB15xx
  #include "stm32wb15xx.h"
#endif // TODO : move to RLV_TFW_Types.h


#ifdef USE_PROTOCOL_802154
  #include "ip802154_lld.h"
  #include "ip802154_lld_priv.h"
  #include "ip802154_lld_registers.h"
  #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
  #include "ipBLE_lld.h"
  #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE

#include "RLV_BLE_Data.h"
#include "RLV_TFW_Data.h"
#include "RLV_BLE_Types.h"
#include "RLV_TFW_Types.h"
#include "RLV_EnvParameters.h"
#include "RLV_Logger.h"
#include "RLV_Timer.h"


////////////////////////////////////////////////////////////////////////////////
//////////////////                  Private types             //////////////////
////////////////////////////////////////////////////////////////////////////////


typedef struct bleData_t
{
    ActionPacket        actionPacket;
    actionPacket_e_t    apCurrentType; //used to identify ap type (NULL, empty, simple, custom)
    apDataRoutine_t     DataRoutineCallback;
    apCondRoutine_t     CondRoutineCallback;
    uint8_t             nextIfTrueApIndex;
    uint8_t             nextIfFalseApIndex;
    uint8_t             txBuffer[RLV_MAX_PACKET_SIZE];
    uint8_t             rxBuffer[RLV_MAX_PACKET_SIZE];
}bleData_t;


////////////////////////////////////////////////////////////////////////////////
//////////////////                Private variables           //////////////////
////////////////////////////////////////////////////////////////////////////////
static bleData_t        bleData[RLV_MAX_NUMBER_OF_STORED_DATA] = {0};
static int32_t          lastRssiInDbm = 255;

////////////////////////////////////////////////////////////////////////////////
//////////////////              Private Helpers               //////////////////
////////////////////////////////////////////////////////////////////////////////
/*#if 0
static void rlv_ble_SwapSnAndNesnOfHeader(ActionPacket* p,  ActionPacket* next)
{
    next->data[0] = p->data[0];
    if(((p->data[0] & RLV_HEADER_SN_BIT_MASK) == (p->data[0] & RLV_HEADER_NESN_BIT_MASK)) && (p->status & BIT_TX_MODE)) 
    {
        if(p->data[0] & RLV_HEADER_SN_BIT_MASK)
        {
            next->data[0] |= (uint8_t)RLV_HEADER_SN_BIT_MASK;
        }
        else
        {
            next->data[0] &= (uint8_t)~RLV_HEADER_SN_BIT_MASK;
        }
    }
    else if(((p->data[0] & RLV_HEADER_SN_BIT_MASK) == (p->data[0] & RLV_HEADER_NESN_BIT_MASK)) && !(p->status & BIT_TX_MODE)) 
    {
        if(p->data[0] & RLV_HEADER_NESN_BIT_MASK)
        {
            next->data[0] &= (uint8_t)~RLV_HEADER_NESN_BIT_MASK;
        }
        else
        {
            next->data[0] |= (uint8_t)RLV_HEADER_NESN_BIT_MASK;
        }
    }
    else
    {
        //do nothing
    }
}
#endif 0*/

#define NOT_FOUND 0xFF
static uint8_t FindStorageIndexOfCurrentAp(ActionPacket* p)
{
    uint8_t currentActionPacketIndex = NOT_FOUND; 
    for(uint8_t index = 0; index < RLV_MAX_NUMBER_OF_STORED_DATA ; index++)
    {
        if((ActionPacket*)&(bleData[index].actionPacket) == (ActionPacket*)p)
        {
            currentActionPacketIndex = index;
        }
    }
    return currentActionPacketIndex;
}

////////////////////////////////////////////////////////////////////////////////
//////////////////              Data & Cond routines          //////////////////
////////////////////////////////////////////////////////////////////////////////

/* @note: Warning: The DR (data routine) and CR (cond routine) are time critical.
 *        Routines are called in an IRQ and must end within 45 us. 
 */

static uint8_t DR_SimpleTrue(ActionPacket* p,  ActionPacket* next)
{
  return RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
}

static uint8_t DR_SimpleFalse(ActionPacket* p,  ActionPacket* next)
{
  return !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
}

static uint8_t DR_ClearPendingActionWhenIrqDone(ActionPacket* p,  ActionPacket* next)
{
    uint8_t ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS; 
    if((p->status & IRQ_DONE) != 0)
    {
        if((p->status & BIT_TX_MODE) != 0) //TX
        { 
            RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false);
        }
        else //RX
        {
            if((p->status & IRQ_RCV_FAIL) != 0) // no packet was received 
            {
                if((p->status & IRQ_CRC_ERR) != 0) //crc error or timeout
                {
                    if((p->status & IRQ_TIMEOUT) != 0) //only timeout error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                    else  //only crc error
                    {
                        RLV_BLE_UpdateRssiInDbm(p->rssi);
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                }
                else //unknown error
                {
                    ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                }
            }
            else 
            {
                if((p->status & IRQ_RCV_OK) != 0)//received + crc ok 
                {
                    RLV_BLE_UpdateRssiInDbm(p->rssi);
                    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false);
                }
                else 
                {
                    // no packet was received yet, but a byte was received
                }
            }
        }
        RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,false);
    }
    return ret_val;
}

/*#if 0
static uint8_t DR_ClearPendingActionAndToggleGpioC2WhenTxSuccess(ActionPacket* p,  ActionPacket* next)
{
    uint8_t ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
    GPIOC->BSRR = (uint32_t)GPIO_PIN_2;
    
    if((p->status & IRQ_DONE) != 0)
    {
        if((p->status & BIT_TX_MODE) != 0) //TX
        { 
            if((p->status & IRQ_TX_OK) != 0)//transmit ok 
            {
                RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false); //only works if header is BLE? check the BZ ticket 
            }
            RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false); //FIXME see previous comment with the IRQ_TX_OK bit
            GPIOC->BRR = (uint32_t)GPIO_PIN_2;
        }
        else //RX
        {
            if((p->status & IRQ_RCV_FAIL) != 0) // no packet was received 
            {
                if((p->status & IRQ_CRC_ERR) != 0) //crc error or timeout
                {
                    if((p->status & IRQ_TIMEOUT) != 0) //only timeout error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                    else  //only crc error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                }
                else //unknown error
                {
                    ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                }
            }
            else 
            {
                if((p->status & IRQ_RCV_OK) != 0)//received + crc ok 
                {
                    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false);
                }
                else 
                {
                    // no packet was received yet, but a byte was received
                }
            }
        }
        RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,false);
    }
    
    return ret_val;
}

static uint8_t DR_ClearPendingActionAndToggleGpioC5WhenRxSuccess(ActionPacket* p,  ActionPacket* next)
{
    uint8_t ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
    GPIOC->BSRR = (uint32_t)GPIO_PIN_5;
    
    if((p->status & IRQ_DONE) != 0)
    {
        if((p->status & BIT_TX_MODE) != 0) //TX
        { 
            if((p->status & IRQ_TX_OK) != 0)//transmit ok 
            {
                RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false); //only works if header is BLE? check the BZ ticket 
            }
            RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false); //FIXME see previous comment with the IRQ_TX_OK bit
        }
        else //RX
        {
            if((p->status & IRQ_RCV_FAIL) != 0) // no packet was received 
            {
                if((p->status & IRQ_CRC_ERR) != 0) //crc error or timeout
                {
                    if((p->status & IRQ_TIMEOUT) != 0) //only timeout error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                    else  //only crc error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                }
                else //unknown error
                {
                    ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                }
            }
            else 
            {
                if((p->status & IRQ_RCV_OK) != 0)//received + crc ok 
                {
                    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false);
                    GPIOC->BRR = (uint32_t)GPIO_PIN_5;
                }
                else 
                {
                    // no packet was received yet, but a byte was received
                }
            }
        }
        RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,false);
    }
    
    return ret_val;
}
#endif 0*/

static uint8_t DR_ClearPendingActionWhenTxRxActionDone(ActionPacket* p,  ActionPacket* next)
{
    uint8_t ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
   
    if((p->status & IRQ_DONE) != 0)
    {
        if((p->status & BIT_TX_MODE) != 0) //TX
        { 
            RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false);
            
            if(RLV_Parameters_ptr->shouldTxNotRx && !RLV_Parameters_ptr->withAck || !RLV_Parameters_ptr->shouldTxNotRx && RLV_Parameters_ptr->withAck)
            {
                RLV_Parameters_ptr->txSuccessCounter++;
            }
        }
        else //RX
        {
            if((p->status & IRQ_RCV_FAIL) != 0) // no packet was received 
            {
                if((p->status & IRQ_CRC_ERR) != 0) //crc error or timeout //TODO just CRC error would be great
                {
                    if((p->status & IRQ_TIMEOUT) != 0) //only timeout
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                        RLV_Parameters_ptr->rxTimeoutErrorCounter++;
                    }
                    else  //only crc
                    {
                        RLV_BLE_UpdateRssiInDbm(p->rssi);
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                        RLV_Parameters_ptr->rxCrcErrorCounter++;
                    }
                }
                else
                {
                    RLV_Parameters_ptr->rxUnkownErrorCounter++;
                }
            }
            else 
            {
                if((p->status & IRQ_RCV_OK) != 0)//received + crc ok 
                {
                    RLV_BLE_UpdateRssiInDbm(p->rssi);
                    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,false);
                    if(RLV_Parameters_ptr->shouldTxNotRx && RLV_Parameters_ptr->withAck || !RLV_Parameters_ptr->shouldTxNotRx && !RLV_Parameters_ptr->withAck)
                    {
                        RLV_Parameters_ptr->rxSuccessCounter++;
                    }
                }
                else 
                {
                    // no packet was received yet? but a byte was received ?
                }
            }
        }
                
        if((RLV_Parameters_ptr->shouldTxNotRx && !RLV_Parameters_ptr->withAck && (p->status & BIT_TX_MODE) != 0) ||
           (RLV_Parameters_ptr->shouldTxNotRx && RLV_Parameters_ptr->withAck && (p->status & BIT_TX_MODE) == 0) ||
           (!RLV_Parameters_ptr->shouldTxNotRx && RLV_Parameters_ptr->withAck && (p->status & BIT_TX_MODE) == 0) && ((p->status & IRQ_RCV_FAIL) != 0) ||
           (!RLV_Parameters_ptr->shouldTxNotRx && RLV_Parameters_ptr->withAck && (p->status & BIT_TX_MODE) != 0) ||
           (!RLV_Parameters_ptr->shouldTxNotRx && !RLV_Parameters_ptr->withAck && (p->status & BIT_TX_MODE) == 0))
        {
            RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,false);
        }
        
    }
    
    return ret_val;
}

static uint8_t DR_ClearPendingActionAndRetSuccess(ActionPacket* p,  ActionPacket* next)
{
    RLV_TFW_ClearFlags();
    return RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
}

static uint8_t DR_IncChannel(ActionPacket* p,  ActionPacket* next)
{
//    RLV_Parameters_ptr->channel = (RLV_Parameters_ptr->channel + RLV_Parameters_ptr->channelIncrement) % MAX_CHANNEL_NUMBER;
//    LLD_BLE_SetChannel(RLV_Parameters_ptr->apStateMachineId,
//                       RLV_Parameters_ptr->channel,
//                       0);
//    next->ActionTag |= INC_CHAN;
    return RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS; 
} 

static uint8_t DR_IncRxTxCounter(ActionPacket* p,  ActionPacket* next)
{
    if(((p->status & IRQ_DONE) != 0) && (!(p->status & BIT_TX_MODE) == !(p->ActionTag & TXRX)))
    {
        if((p->status & BIT_TX_MODE) == 0)
        {
            if(((p->status & IRQ_RCV_FAIL) == 0) && ((p->status & IRQ_RCV_OK) != 0))
            {
                uint8_t apIndex = FindStorageIndexOfCurrentAp(p);
                if((apIndex != NOT_FOUND) && (apIndex < RLV_MAX_NUMBER_OF_STORED_DATA))
                {
                    uint8_t* rxExpectedBuffer = bleData[apIndex].txBuffer;
                    if(RLV_BLE_ExpectPacketsEqual(true, p->data,rxExpectedBuffer[0],rxExpectedBuffer[1],&rxExpectedBuffer[2], false))
                    {
                        RLV_Parameters_ptr->rxSuccessCounter++;
                    }
                }
            }
            else
            {
                RLV_Parameters_ptr->rxCounter++;
            }
        }
        else
        {
             RLV_Parameters_ptr->txSuccessCounter++;
        }
    }
    return RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS; 
}

static uint8_t CR_SimpleTrue(ActionPacket* p)
{
    //us_delay(1000);//TODO for debug , remove me!
    return RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
}

static uint8_t CR_SimpleFalse(ActionPacket* p)
{
    return !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
}

static uint8_t CR_ReturnActionResult(ActionPacket* p)
{
    uint8_t ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS; 
    if((p->status & IRQ_DONE) != 0)
    {
        if((p->status & BIT_TX_MODE) != 0) //TX
        { 
        }
        else //RX
        {
            if((p->status & IRQ_RCV_FAIL) != 0) // no packet was received 
            {
                if((p->status & IRQ_CRC_ERR) != 0) //crc error or timeout
                {
                    if((p->status & IRQ_TIMEOUT) != 0) //only timeout error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                    else  //only crc error
                    {
                        ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                    }
                }
                else //unknown error
                {
                    ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                }
            }
            else 
            {
                if((p->status & IRQ_RCV_OK) != 0)//received + crc ok 
                {
                }
                else 
                {
                    // no packet was received yet, but a byte was received?
                    ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                }
            }
        }
    }
    return ret_val;
}

static uint8_t CR_ReturnIfPacketIsAsExpected(ActionPacket* p)
{
    uint8_t ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS; 
    if(((p->status & IRQ_DONE) != 0) && ((p->status & BIT_TX_MODE) == 0)) //RX
    {
        if(((p->status & IRQ_RCV_FAIL) == 0) && ((p->status & IRQ_RCV_OK) != 0)) // packet was received 
        {
            uint8_t apIndex = FindStorageIndexOfCurrentAp(p);
            if((apIndex != NOT_FOUND) && (apIndex < RLV_MAX_NUMBER_OF_STORED_DATA))
            {
                uint8_t* rxExpectedBuffer = bleData[apIndex].txBuffer;
                if(RLV_BLE_ExpectPacketsEqual(true, p->data,rxExpectedBuffer[0],rxExpectedBuffer[1],&rxExpectedBuffer[2], false))
                {
                    ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
                }
            }
        }
    }
    return ret_val;
}

static uint8_t CR_ReturnIfStressInTimeout(ActionPacket* p)
{
    uint8_t ret_val = !RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS; 
    if(RLV_TIM_GetTimeInS() >= RLV_Parameters_ptr->stressDurationInS)
    {
        ret_val = RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS;
    }
    return ret_val;
}

////////////////////////////////////////////////////////////////////////////////
//////////////////                Public functions            //////////////////
////////////////////////////////////////////////////////////////////////////////

void RLV_BLE_InitData(void)//TODO: to be called just after env parameter struct is init (memcpy with default param)
{

    bleData[0].apCurrentType = (actionPacket_e_t){AP_END};
    bleData[1].apCurrentType = (actionPacket_e_t){AP_EMPTY};
    for(uint8_t index = 2;index<RLV_MAX_NUMBER_OF_STORED_DATA;index++)
    {
        bleData[index].apCurrentType = (actionPacket_e_t){AP_UNINITIALIZED};
    }   
    RLV_BLE_ResetBuffersAndCounters();
        //GPIO for debugging timing
    GPIO_InitTypeDef  GPIO_InitStruct;

    GPIO_InitStruct.Pin = (GPIO_PIN_2);
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH  ;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = (GPIO_PIN_5);
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH  ;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIOC->BSRR = (uint32_t)GPIO_PIN_2;
    GPIOC->BSRR = (uint32_t)GPIO_PIN_5;
}

void RLV_BLE_PrintTestEnvParameters(void)
{
    LIST_BLE_param(SHOW_param)
}

void RLV_BLE_ResetBuffersAndCounters(void)
{
    for(uint8_t index = 0;index < RLV_MAX_NUMBER_OF_STORED_DATA;index++)
    {
        memset(bleData[index].rxBuffer,0x00,RLV_MAX_PACKET_SIZE);
    }
    lastRssiInDbm = 255;
    RLV_Parameters_ptr->rxCounter = 0;
    RLV_Parameters_ptr->txSuccessCounter = 0;
    RLV_Parameters_ptr->rxSuccessCounter = 0;
}
////////////////////////////////////////////////////////////////////////////////
//////////////////                Test functions              //////////////////
////////////////////////////////////////////////////////////////////////////////
bool RLV_BLE_ExpectPacketsEqual(bool precondition, uint8_t * rxPacket,uint8_t header,uint8_t length,uint8_t * payload, bool show)
{
    bool areEqual = false;
    bool sameHeaders = false;
    bool sameLengths = false;
    bool samePayload = true;
    uint8_t payloadDataIndex ;
    sameHeaders =(((uint8_t)rxPacket[0] & (uint8_t)~( RLV_HEADER_SN_BIT_MASK | RLV_HEADER_SN_BIT_MASK)) == ((uint8_t)header & (uint8_t)~( RLV_HEADER_SN_BIT_MASK | RLV_HEADER_SN_BIT_MASK))); // NS and NSEN bits are ignored
    sameLengths =(rxPacket[1] == length + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0));
    for(payloadDataIndex = 0; payloadDataIndex < length ; payloadDataIndex++)
    { 
        if( rxPacket[payloadDataIndex+2] != payload[payloadDataIndex] ) { samePayload = false; break; }
    }
    if(show) RLV_LOG_LINE("  - Checking header");
    if(precondition)
    {
        if(sameHeaders)
        {
           if(show) RLV_APPEND_LOG(RLV_PASS_STRING);
        }
        else
        {
           if(show) RLV_APPEND_LOG(RLV_FAILS_STRING" -- (o:0x%02x/e:0x%02x)",rxPacket[0],header);
        }
    }
    else
    {
        if(show) RLV_APPEND_LOG(RLV_SKIPPED_STRING);
    }
    if(show) RLV_LOG_LINE("  - Checking length");
    if(precondition && sameHeaders)
    {
        if(sameLengths)
        {
            if(show) RLV_APPEND_LOG(RLV_PASS_STRING);
        }
        else
        {
            if(show) RLV_APPEND_LOG(RLV_FAILS_STRING" -- (o:0x%02x/e:0x%02x)",rxPacket[1],length);
        }
    }
    else
    {
        if(show) RLV_APPEND_LOG(RLV_SKIPPED_STRING);
    }
    if(show) RLV_LOG_LINE("  - Checking payload");
    if(precondition && sameHeaders && sameLengths)
    {
        if(samePayload)
        {
             if(show) RLV_APPEND_LOG(RLV_PASS_STRING);
             areEqual = true;
        }
        else
        {
            if(show) RLV_APPEND_LOG(RLV_FAILS_STRING" -- (o[%u]:0x%02x/e[%u]:0x%02x)",payloadDataIndex,rxPacket[payloadDataIndex+2],payloadDataIndex,payload[payloadDataIndex]);
            if(RLV_Parameters_ptr->displayFullArrayIfCheckFails)
            {
                if(show) RLV_SHOW_ARRAY((uint8_t*)(rxPacket+2),length);
                if(show) RLV_SHOW_ARRAY(payload,length);
            }
        }
    }
    else
    {
        if(show) RLV_APPEND_LOG(RLV_SKIPPED_STRING);
    }

    return areEqual;
}


////////////////////////////////////////////////////////////////////////////////
//////////////////               Helper functions             //////////////////
////////////////////////////////////////////////////////////////////////////////
void RLV_BLE_FillPacket(uint8_t * txPacketBuffer,uint8_t header,uint8_t length,uint8_t * payload)
{
   memset(txPacketBuffer, 0, sizeof((uint8_t*)txPacketBuffer));
   txPacketBuffer[0] =  (uint8_t)header;
   txPacketBuffer[1] =  (uint8_t)length;
   for(uint8_t payloadDataIndex = 0; (payloadDataIndex < length) && (payloadDataIndex < RLV_MAX_PACKET_SIZE-2); payloadDataIndex++) 
   { 
       txPacketBuffer[payloadDataIndex+2] =  (uint8_t)payload[payloadDataIndex]; 
   }
}

int32_t RLV_BLE_GetLastRssiInDbm(void)
{
    return lastRssiInDbm;
}
void RLV_BLE_UpdateRssiInDbm(int32_t lastRssi)
{
    lastRssiInDbm = lastRssi;
}
////////////////////////////////////////////////////////////////////////////////
//////////////////              Build action packet           //////////////////
////////////////////////////////////////////////////////////////////////////////
uint32_t RLV_BLE_GetActionTag(void)
{
   return ((RLV_Parameters_ptr->radioFrequencyCalibrationEnabled ? PLL_TRIG : 0) | \
   (RLV_Parameters_ptr->actionIsTxNotRx ? TXRX : 0) | \
   (RLV_Parameters_ptr->timerWakeupBasedOnWakeupTimeNotB2B ? TIMER_WAKEUP : 0) | \
   (RLV_Parameters_ptr->nsEn ? NS_EN : 0) | \
   (RLV_Parameters_ptr->channelAutoIncrementEnabled ? INC_CHAN : 0) | \
   (RLV_Parameters_ptr->wakeupTimeIsRelativeNotAbsolute ? RELATIVE : 0) | \
   (RLV_Parameters_ptr->timestampFromPacketStartNotEnd ? TIMESTAMP_POSITION : 0));
}

uint8_t* RLV_BLE_GetRxPacketBuffer(uint8_t currentApIndex)
{    
    uint8_t* rxBuf;
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_GetRxPacketBuffer, buffer overflow ");
        rxBuf =  NULL;
    }
    else
    {
        rxBuf = bleData[currentApIndex].rxBuffer;
    }
    return rxBuf;
}

uint8_t RLV_BLE_GetExpectedHeader(uint8_t currentApIndex)
{    
    uint8_t rxExpectedHeader;
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_GetExpectedHeader, buffer overflow ");
        rxExpectedHeader =  NULL;
    }
    else
    {
        rxExpectedHeader = bleData[currentApIndex].txBuffer[0];
    }
    return rxExpectedHeader;
}

uint8_t RLV_BLE_GetExpectedLength(uint8_t currentApIndex)
{    
    uint8_t rxExpectedLength;
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_GetExpectedLength, buffer overflow ");
        rxExpectedLength =  NULL;
    }
    else
    {
        rxExpectedLength = bleData[currentApIndex].txBuffer[1];
    }
    return rxExpectedLength;
}

uint8_t* RLV_BLE_GetExpectedPayload(uint8_t currentApIndex)
{    
    uint8_t* rxExpectedBuf;
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_GetExpectedPayload, buffer overflow ");
        rxExpectedBuf =  NULL;
    }
    else
    {
        rxExpectedBuf = &bleData[currentApIndex].txBuffer[2];
    }
    return rxExpectedBuf;
}


void RLV_BLE_SetDataRoutine(uint8_t currentApIndex, apDataRoutine_e_t type)
{
    if(currentApIndex < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        switch(type.value)
        {
        case APDR_NULL: 
            bleData[currentApIndex].DataRoutineCallback = NULL;
            break;
        case APDR_SIMPLE_RET_TRUE: 
            bleData[currentApIndex].DataRoutineCallback = DR_SimpleTrue;
            break;
        case APDR_SIMPLE_RET_FALSE: 
            bleData[currentApIndex].DataRoutineCallback = DR_SimpleFalse;
            break;
        case APDR_CLEAR_FLAG_IF_IRQ_DONE: 
            bleData[currentApIndex].DataRoutineCallback = DR_ClearPendingActionWhenIrqDone;
            break;
        case APDR_CLEAR_FLAG_IF_TXRX_ACTION_DONE: 
            bleData[currentApIndex].DataRoutineCallback = DR_ClearPendingActionWhenTxRxActionDone;
            break;
        case APDR_JUST_CLEAR_FLAGS: 
            bleData[currentApIndex].DataRoutineCallback = DR_ClearPendingActionAndRetSuccess;
            break;
        case APDR_INC_CHANNEL: 
            bleData[currentApIndex].DataRoutineCallback = DR_IncChannel;
            break;
        case APDR_INC_RXTX_COUNTER: 
            bleData[currentApIndex].DataRoutineCallback = DR_IncRxTxCounter;
            break;
            
        default:
            bleData[currentApIndex].DataRoutineCallback = DR_ClearPendingActionWhenTxRxActionDone;
            break;
        }
    }
}
apDataRoutine_t RLV_BLE_GetDataRoutine(uint8_t currentApIndex)
{
    apDataRoutine_t retDr;
    if(currentApIndex < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        retDr = bleData[currentApIndex].DataRoutineCallback ;
    }
    else
    {
        retDr = NULL;
    }
    return retDr;
}

void RLV_BLE_SetCondRoutine(uint8_t currentApIndex, apCondRoutine_e_t type)
{
    if(currentApIndex < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        switch(type.value)
        {
        case APCR_NULL: 
            bleData[currentApIndex].CondRoutineCallback = NULL;
            break;
        case APCR_SIMPLE_RET_TRUE: 
            bleData[currentApIndex].CondRoutineCallback = CR_SimpleTrue;
            break;
        case APCR_SIMPLE_RET_FALSE: 
            bleData[currentApIndex].CondRoutineCallback = CR_SimpleFalse;
            break;
        case APCR_RET_TRUE_IF_SUCCESS: 
            bleData[currentApIndex].CondRoutineCallback = CR_ReturnActionResult;
            break;
        case APCR_RET_TRUE_IF_PACKET_AS_EXPECTED: 
            bleData[currentApIndex].CondRoutineCallback = CR_ReturnIfPacketIsAsExpected;
            break;
        case APCR_RET_TRUE_IF_STRESS_TIMES_OUT:
            bleData[currentApIndex].CondRoutineCallback = CR_ReturnIfStressInTimeout;
            break;
        default:
            bleData[currentApIndex].CondRoutineCallback = CR_SimpleTrue;
            break;
        }
    }
    else
    {
        RLV_LOG_ERROR("in RLV_BLE_SetCondRoutine, buffer overflow ");
    }
}
apCondRoutine_t RLV_BLE_GetCondRoutine(uint8_t currentApIndex)
{
    apCondRoutine_t retCr;
    if(currentApIndex < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        retCr = bleData[currentApIndex].CondRoutineCallback;
    }
    else
    {
        retCr = NULL;
    }
    return retCr;
}

void RLV_BLE_SetNextIfTrueActionPacketIndex(uint8_t currentApIndex, uint8_t nextIfTrueApIndex)
{
    if(currentApIndex < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        bleData[currentApIndex].nextIfTrueApIndex = nextIfTrueApIndex;
    }
    else
    {
        RLV_LOG_ERROR("in RLV_BLE_SetNextIfTrueActionPacketIndex, buffer overflow ");
    }
}

void RLV_BLE_SetNextIfFalseActionPacketIndex(uint8_t currentApIndex, uint8_t nextIfFalseApIndex)
{
    if(currentApIndex < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        bleData[currentApIndex].nextIfFalseApIndex = nextIfFalseApIndex;
    }
    else
    {
        RLV_LOG_ERROR("in RLV_BLE_SetNextIfFalseActionPacketIndex, buffer overflow ");
    }
}

ActionPacket* RLV_BLE_GetActionPacket(uint8_t index)
{
    ActionPacket* retAp;
    if((index < RLV_MAX_NUMBER_OF_STORED_DATA) && (index != 0))
    {
        switch(bleData[index].apCurrentType.value)
        {
        case AP_EMPTY:
            retAp = &bleData[1].actionPacket;
            break;
        case AP_TXRX:
            retAp = &bleData[index].actionPacket;
            break;
        case AP_END:
        default:
            retAp = (ActionPacket*)NULL;
            break;
        }
    }
    else if (index == 0)
    {
        retAp = (ActionPacket*)NULL;
    }
    else
    {
        RLV_LOG_ERROR("in RLV_BLE_SetNextIfFalseActionPacketIndex, buffer overflow ");
        retAp = (ActionPacket*)NULL;
    }
    return retAp;
}

static ActionPacket* GetNextIfTrueActionPacket(uint8_t currentApIndex)
{
    ActionPacket* retAp;
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in GetNextIfTrueActionPacket, buffer overflow ");
        retAp = NULL;
    }
    else
    {
        retAp = RLV_BLE_GetActionPacket(bleData[currentApIndex].nextIfTrueApIndex);
    }
    return retAp;
}

static ActionPacket* GetNextIfFalseActionPacket(uint8_t currentApIndex)
{
    ActionPacket* retAp;
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in GetNextIfFalseActionPacket, buffer overflow ");
        retAp = NULL;
    }
    else
    {
        retAp = RLV_BLE_GetActionPacket(bleData[currentApIndex].nextIfFalseApIndex);
    }
    return retAp;
}
void RLV_BLE_SetNextActionPacketPointers(uint8_t currentApIndex)
{
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_SetNextActionPacketPointers, buffer overflow ");
    }
    else
    {
        bleData[currentApIndex].actionPacket.next_true = GetNextIfTrueActionPacket(currentApIndex); 
        bleData[currentApIndex].actionPacket.next_false = GetNextIfFalseActionPacket(currentApIndex);
    }
}

void RLV_BLE_SetCurrentActionPacketType(uint8_t currentApIndex, actionPacket_e_t type)
{
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_SetCurrentActionPacketType, buffer overflow ");
    }
    else
    {
        bleData[currentApIndex].apCurrentType = type;
    }
}
void RLV_BLE_BuildCurrentActionPacket(uint8_t currentApIndex)
{
    if(currentApIndex >= RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        RLV_LOG_ERROR("in RLV_BLE_BuildCurrentActionPacket, buffer overflow ");
    }
    else
    {
        if((bleData[currentApIndex].apCurrentType.value == AP_END) && (currentApIndex != 0))
        {
            RLV_LOG_ERROR("index 0 is reserved for AP_END (end of chain)");
        }
        else if((bleData[currentApIndex].apCurrentType.value == AP_EMPTY) && (currentApIndex != 1))
        {
            RLV_LOG_ERROR("index 1 is reserved for AP_EMPTY (zero-initialized/empty packet)");
        }
        else if (bleData[currentApIndex].apCurrentType.value == AP_END)
        {
            //Do nothing, &bleData[0].actionPacket will be replaced by NULL when using RLV_BLE_GetCurrentActionPacket
        }
        else if(bleData[currentApIndex].apCurrentType.value == AP_EMPTY)
        {
            //Do nothing, &bleData[1].actionPacket will be replaced by a zero-initialized/empty packet when using RLV_BLE_GetCurrentActionPacket
        }
        else if(bleData[currentApIndex].apCurrentType.value == AP_TXRX)
        {
            memset(bleData[currentApIndex].rxBuffer,0,sizeof(bleData[currentApIndex].rxBuffer));
            memset(bleData[currentApIndex].txBuffer,0,sizeof(bleData[currentApIndex].txBuffer));
            if (RLV_BLE_GetActionTag() & TXRX)
            {
                RLV_BLE_FillPacket(bleData[currentApIndex].txBuffer,
                                   RLV_Parameters_ptr->txHeader,
                                   RLV_Parameters_ptr->txPayload.length + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                                   RLV_Parameters_ptr->txPayload.content);
            }
            else
            {
                RLV_BLE_FillPacket(bleData[currentApIndex].txBuffer,
                               RLV_Parameters_ptr->rxExpectedHeader,
                               RLV_Parameters_ptr->rxExpectedPayload.length + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                               RLV_Parameters_ptr->rxExpectedPayload.content);
            }
            bleData[currentApIndex].actionPacket.StateMachineNo = RLV_Parameters_ptr->apStateMachineId;
            bleData[currentApIndex].actionPacket.ActionTag =  RLV_BLE_GetActionTag();
            bleData[currentApIndex].actionPacket.WakeupTime = RLV_Parameters_ptr->wakeupTime;
            bleData[currentApIndex].actionPacket.ReceiveWindowLength = (RLV_BLE_GetActionTag() & TXRX) ? 0 : RLV_Parameters_ptr->rxReceiveWindow ;
            bleData[currentApIndex].actionPacket.data = (RLV_BLE_GetActionTag() & TXRX) ? bleData[currentApIndex].txBuffer : bleData[currentApIndex].rxBuffer;
            bleData[currentApIndex].actionPacket.condRoutine = RLV_BLE_GetCondRoutine(currentApIndex);
            bleData[currentApIndex].actionPacket.dataRoutine = RLV_BLE_GetDataRoutine(currentApIndex);
        }
        else // AP_UNINITIALIZED
        {
            //do nothing, AP will not be used
        }
    }
}



#endif //RF_LLD_VALIDATION