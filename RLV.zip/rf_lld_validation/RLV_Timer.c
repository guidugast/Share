 /*******************************************************************************
  * @file    RLV_Timer.c
  * @author  MCD Application Team
  * @brief   TODO
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "RLV_TestFramework.h"
#include "stm32wbxx_hal_conf.h"
#include "RLV_Timer.h"

////////////////////////////////////////////////////////////////////////////////
//////////////////                Size Guard                  //////////////////
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//////////////////             Private variables              //////////////////
////////////////////////////////////////////////////////////////////////////////
static TIM_HandleTypeDef htim2;

static volatile uint32_t timeCounter = 0;

////////////////////////////////////////////////////////////////////////////////
//////////////////             Private functions              //////////////////
////////////////////////////////////////////////////////////////////////////////

static void rlv_tim_errorHandler(void)
{
    RLV_LOG_LINE("rlv_tim_errorHandler");
    RLV_PRINT_LOG();
    while(1) 
    {
    }
}


////////////////////////////////////////////////////////////////////////////////
//////////////////             Public functions               //////////////////
////////////////////////////////////////////////////////////////////////////////
void RLV_TIM_Init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();

    HAL_NVIC_SetPriority(TIM2_IRQn, 0, 1U);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);

    htim2.Instance = TIM2;
    htim2.Init.Period            = 0x1F40; 
    htim2.Init.Prescaler         = (uint32_t)(SystemCoreClock / 1000)-1 ;
    htim2.Init.ClockDivision     = 0;
    htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim2.Init.RepetitionCounter = 0;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if(HAL_TIM_Base_Init(&htim2) != HAL_OK)
    {
        rlv_tim_errorHandler();
    }
}


uint32_t RLV_TIM_GetTimeInS(void)
{
    return timeCounter;
}

void RLV_TIM_StartTimer(void)
{
    timeCounter = 0;
    if (HAL_TIM_Base_Start_IT(&htim2) != HAL_OK)
    {
        rlv_tim_errorHandler();
    }
}

void RLV_TIM_StopTimer(void)
{
    timeCounter = (uint32_t)-1;
    if (HAL_TIM_Base_Stop_IT(&htim2) != HAL_OK)
    {
        rlv_tim_errorHandler();
    }
}

void TIM2_IRQHandler(void) 
{
    HAL_TIM_IRQHandler(&htim2);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    static bool probeToggle = false;
    if(htim->Instance == TIM2)
    {
        timeCounter++;
        if(probeToggle)
        {
            GPIOC->BSRR = (uint32_t)GPIO_PIN_2;
        }
        else
        {
            GPIOC->BRR = (uint32_t)GPIO_PIN_2;
        }
        probeToggle = !probeToggle;
    }
}


#endif //RF_LLD_VALIDATION