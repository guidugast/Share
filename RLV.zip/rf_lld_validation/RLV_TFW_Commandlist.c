/*******************************************************************************
* @file    TODO
* @author  MCD Application Team
* @brief   TODO
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the 
* License. You may obtain a copy of the License at:
*                        opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*/
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "RLV_TFW_Types.h"
#include "RLV_TFW_Data.h"
#include "RLV_TestFramework.h"

#include "RLV_TFW_Commandlist.h"
#include "RLV_EnvParameters.h"

////////////////////////////////////////////////////////////////////////////////
//////////////////             Public functions               //////////////////
////////////////////////////////////////////////////////////////////////////////
DEF_command(TFW_Command__HelloWorld,
    RLV_LOG_LINE("Hello World ! (from command)");
)

DEF_command(TFW_Command__SystemReset,
    RLV_TFW__RESET_SYSTEM("Manual reset");
)

DEF_command(TFW_Command__PrintTestEnvParameters,
    RLV_TFW_PrintTestEnvParameters();
)

DEF_command(TFW_Command__ResetTestEnvParametersToDefaultValues,
    RLV_TFW_Init();
)

DEF_command(TFW_Command__SetParam,
    if(2 != argNumber ) 
    { 
        RLV_LOG_ERROR("Only two arguments needed, which are the parameter name and the value to set it to"); 
    } 
    else 
    { 
        RLV_TFW_SetParam(argList[0],argList[1]);
    }
)

DEF_command(TFW_Command__GetParam,   
    if(1 != argNumber ) 
    { 
        RLV_LOG_ERROR("Only one argument needed, which is the parameter name"); 
    } 
    else 
    { 
        RLV_TFW_GetParam(argList[0]);
    }
)

#endif //RF_LLD_VALIDATION