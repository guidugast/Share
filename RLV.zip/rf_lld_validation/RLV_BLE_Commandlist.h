/**
  ******************************************************************************
  * @file    TODO.h
  * @author  MCD Application Team
  * @brief   Header for TODO.c module
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_BLE_COMMANDLIST_H_
#define RLV_BLE_COMMANDLIST_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                   Includes                 //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "RLV_TestFramework.h"
#include "RLV_BLE_Steplist.h"
#include "RLV_TFW_Commandlist.h"


////////////////////////////////////////////////////////////////////////////////
//////////////////               Command list                 //////////////////
////////////////////////////////////////////////////////////////////////////////
#define LIST_BLE_commands(X) \
        X(BLE_Command__PrintTestEnvParameters,              0,          "no arg",                                                                                                                                   "Print full list of BLE test env paramters")\
        X(BLE_Command__FinishAndFreeze,                     0,          "no arg" ,                                                                                                                                  "End of command then while(true) for debugging UATL)") \
        X(BLE_Command__FreezeAndNotFinish,                  0,          "no arg" ,                                                                                                                                  "While(true) for debugging UATL)") \
        X(BLE_Command__DoWithTimeout,                       0,          "stressDurationInS rxStressDeltaBlockingDelayInUs" ,                                                                                        "Test 'wait for' test-env-feature") \
        X(BLE_Command__TimerTest,                           0,          "stressDurationInS rxStressDeltaBlockingDelayInUs",                                                                                         "Test timer") \
        X(BLE_Command__InitBoardWithHal,                    0,          "no arg",                                                                                                                                   "Inits the board using HAL)") \
        X(BLE_Command__InitBoardWithLld,                    5,          "hsStartupTime lowSpeedOsc whitening hotAnaTable:[length]{content[0],...}",                                                                 "Inits the board using LLD") \
        X(BLE_Command__SetNetworkId,                        1,          "networkId",                                                                                                                                "Change network id (HAL)") \
        X(BLE_Command__InitBoardThenSendOnePacket_HAL,      8,          "withAck channel wakeupTime txHeader txPayload:[length]{content[0],...} txAckReceiveWindow txAckExpectedHeader txAckExpectedPayload",       "Init and send only one packet (HAL)") \
        X(BLE_Command__InitBoardThenWaitForAPacket_HAL,     8,          "withAck channel wakeupTime rxHeader txPayload:[length]{content[0],...} rxReceiveWindow rxAckHeader rxAckPayload",                          "Init and wait for one packet (HAL)") \
        X(BLE_Command__SendOnePacket_HAL,                   8,          "withAck channel wakeupTime txHeader txPayload:[length]{content[0],...} txAckReceiveWindow txAckExpectedHeader txAckExpectedPayload",       "Send only one packet (HAL)") \
        X(BLE_Command__WaitForAPacket_HAL,                  8,          "withAck channel wakeupTime rxHeader txPayload:[length]{content[0],...} rxReceiveWindow rxAckHeader rxAckPayload",                          "Wait for one packet (HAL)") \
        X(BLE_Command__TxStress_HAL,                        4,          "withAck stressDurationInS rxStressDeltaBlockingDelayInUs wakeupTime",                                                                      "Send multiple packets as fast as possible (HAL)") \
        X(BLE_Command__RxStress_HAL,                        4,          "withAck stressDurationInS txStressDeltaBlockingDelayInUs wakeupTime" ,                                                                     "Receive fast packets as much as possible(HAL)") \
        X(BLE_Command__PingPongStress_HAL,                  6,          "withAck stressDurationInS txFirstInPingPong rxStressDeltaBlockingDelayInUs txStressDeltaBlockingDelayInUs wakeupTime" ,                    "transmit and receive fast packets as much as possible(HAL)") \
        X(BLE_Command__InitBoardThenSendOnePacket,          4,          "channel wakeupTime txHeader txPayload:[length]{content[0],...}",                                                                           "Init and send only one packet ") \
        X(BLE_Command__InitBoardThenWaitForAPacket,         5,          "channel wakeupTime rxHeader txPayload:[length]{content[0],...} rxReceiveWindow",                                                           "Init and wait for one packet ") \
        X(BLE_Command__SendOnePacket,                       4,          "channel wakeupTime txHeader txPayload:[length]{content[0],...}",                                                                           "Send only one packet ") \
        X(BLE_Command__WaitForAPacket,                      5,          "channel wakeupTime rxHeader txPayload:[length]{content[0],...} rxReceiveWindow",                                                           "Wait for one packet ") \
        X(BLE_Command__GetStatus,                           0,          "no arg",                                                                                                                                   "Return GetStatus and time value") \
        X(BLE_Command__StartTone,                           0,          "no arg",                                                                                                                                   "Start tone") \
        X(BLE_Command__StopTone,                            0,          "no arg",                                                                                                                                   "Stop tone") \
        X(BLE_Command__StopActivity,                        0,          "no arg",                                                                                                                                   "Stop activity") \
        X(BLE_Command__EncryptPlainData,                    0,          "no arg",                                                                                                                                   "Encrypt plain data and check result") \
        X(BLE_Command__BuildActionPacketChainFromBuffer,    0,          "no arg, use set_param, get_param",                                                                                                         "Build action packet chain (set reserved area), to be used after building each packet with BLE_Command__BuildCurrentActionPacketInBuffer") \
        X(BLE_Command__BuildCurrentActionPacketInBuffer,    0,          "no arg, use set_param, get_param",                                                                                                         "Build action packet at index apCurrentStorageIndex  by using apNextIfTrueStorageIndex and apNextIfFalseStorageIndex ") \
        X(BLE_Command__BuildStateMachine,                   0,          "no arg, use set_param, get_param",                                                                                                         "Build state machine at index apStateMachineId") \
        X(BLE_Command__RunActionPacketChain,                0,          "no arg, use set_param, get_param",                                                                                                         "Make action pending by using this entry point for the AP chain : apCurrentStorageIndex  ") \
        X(BLE_Command__RunApChainAndWaitForItToFinish,      0,          "no arg, use set_param, get_param",                                                                                                         "Do as BLE_Command__RunActionPacketChain does and wait for the action to be not pending") \
        X(BLE_Command__CompareReceivedPacket,               0,          "no arg",                                                                                                                                   "Compare packet received from expected, at current index apCurrentStorageIndex") \
        X(BLE_Command__ShowStressResults,                   0,          "no arg",                                                                                                                                   "Show stress results (for PER measurement in chaining)") \
        //name,                                          arg number,     command use                                                                                                                                command purpose (short text)
        //end of list




LIST_BLE_commands(DEC_command);

#endif // RLV_BLE_COMMANDLIST_H_
#endif // RF_LLD_VALIDATION

