/**
  ******************************************************************************
  * @file    RLV_Logger.h
  * @author  MCD Application Team
  * @brief   Header for RLV_Logger.c module
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_LOGGER_H_
#define RLV_LOGGER_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "RLV_TestFramework.h"

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Defines                    //////////////////
////////////////////////////////////////////////////////////////////////////////
///SIZES
#define RLV_MESSAGE_BUFFER_SIZE             8496U 
#define RLV_LOG_SIZE                        8096U
#define RLV_UNDELAYED_PRINT_BUFFER_SIZE     1024U
#define RLV_LOG_CHUNK_SIZE                  128U
#define RLV_LOG_LINE_SIZE                   256U

//STRINGS
#define RLV_PASS_STRING                     " : [OK]"
#define RLV_FAILS_STRING                    " : [FAILED]"
#define RLV_SKIPPED_STRING                  " : [SKIPPED]"

////////////////////////////////////////////////////////////////////////////////
//////////////////              Public Function               //////////////////
////////////////////////////////////////////////////////////////////////////////
 
extern void                     RLV_LOG_Init(void);
extern void                     RLV_PRINT_LOG(void);
extern void                     RLV_APPEND_LOG(const char* format, ...);
#define RLV_LOG_LINE(f_,...)    RLV_APPEND_LOG("\nM0@ "f_, ##__VA_ARGS__)
#define RLV_LOG_ERROR(f_,...)   RLV_APPEND_LOG("\nM0@ Error : "f_, ##__VA_ARGS__)




#endif // RLV_LOGGER_H_
#endif // RF_LLD_VALIDATION

