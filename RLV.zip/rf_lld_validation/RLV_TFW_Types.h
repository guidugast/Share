/**
  ******************************************************************************
  * @file    TODO
  * @author  MCD Application Team
  * @brief   TODO
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_TFW_TYPES_H_
#define RLV_TFW_TYPES_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include <stdint.h>
#include <stdbool.h>
//this file shall not include anything but primitive type definition files

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Defines                    //////////////////
////////////////////////////////////////////////////////////////////////////////
//SIZES
#define RLV_MAX_ARR_BUF_SIZE                                300
#define RLV_MAX_DISPLAYABLE_ARR_SIZE                        24//{"0x1234,0xFFFF,0xFF,0,0x1000,..."}
#define RLV_MAX_INPUTABLE_ARRAY_LENGHT_CHAR_SIZE            5//["12345"]{content[0],...}
#define RLV_MAX_INPUTABLE_ARRAY_CHAR_SIZE                   280//[length]{"0x1234,0xFFFF,0xFF,0,0x1000,..."}
#define RLV_MAX_NUMBER_OF_STORED_DATA                       10

////////////////////////////////////////////////////////////////////////////////
//////////////////                  Macros                    //////////////////
////////////////////////////////////////////////////////////////////////////////
#define DEF_enum_val(enum_val) \
enum_val,
#define DEF_x_e(enum_type) \
typedef enum \
{ \
  LIST_##enum_type(DEF_enum_val) \
}enum_type

#define DEF_x_st(enum_type) \
typedef union \
{ \
    enum_type value;\
}enum_type##_t

#define DEF_array_x_t(type) \
typedef struct \
{ \
    uint16_t length; \
    type content[RLV_MAX_ARR_BUF_SIZE]; \
}array_##type

////////////////////////////////////////////////////////////////////////////////
//////////////////                  Types                     //////////////////
////////////////////////////////////////////////////////////////////////////////
DEF_array_x_t(uint32_t);
DEF_array_x_t(uint16_t);
DEF_array_x_t(uint8_t);



#endif // RLV_TFW_TYPES_H_
#endif // RF_LLD_VALIDATION

