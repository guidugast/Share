 /*******************************************************************************
  * @file    TODO.c
  * @author  MCD Application Team
  * @brief   TODO
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
#if defined(RF_LLD_VALIDATION)
////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#ifdef STM32WB55xx
  #include "stm32wb55xx.h"
#endif
#ifdef STM32WB35xx
  #include "stm32wb35xx.h"
#endif
#ifdef STM32WB15xx
  #include "stm32wb15xx.h"
#endif // TODO : move to RLV_TFW_Types.h


#ifdef USE_PROTOCOL_802154
  #include "ip802154_lld.h"
  #include "ip802154_lld_priv.h"
  #include "ip802154_lld_registers.h"
  #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
  #include "ipBLE_lld.h"
  #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE

#include "RLV_TFW_Data.h"
#include "RLV_TFW_Types.h"
#include "RLV_Logger.h"
#include "RLV_Timer.h"



////////////////////////////////////////////////////////////////////////////////
//////////////////                Private variables           //////////////////
////////////////////////////////////////////////////////////////////////////////
static bool        pendingActions[RLV_MAX_NUMBER_OF_STORED_DATA];
static bool        failedActions[RLV_MAX_NUMBER_OF_STORED_DATA];

////////////////////////////////////////////////////////////////////////////////
//////////////////                Public functions            //////////////////
////////////////////////////////////////////////////////////////////////////////

void RLV_TFW_ClearFlags(void)
{
    for(uint8_t id = 0; id < RLV_MAX_NUMBER_OF_STORED_DATA; id++)
    {
        pendingActions[id] = false;
        failedActions[id] = false;
    }
}

bool RLV_TFW_IsAnActionPending(void)
{
    bool retVal = false;
    for(uint8_t id = 0; id < RLV_MAX_NUMBER_OF_STORED_DATA; id++)
    {
        if(pendingActions[id])
        {
            retVal = true;
            break;
        }
    }
    return retVal;
}

void RLV_TFW_SetPendingAction(uint8_t id, bool status)
{
    if (id < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        pendingActions[id] = status;
    }
    else
    {
        RLV_LOG_ERROR("in RLV_TFW_SetPendingAction, buffer overflow ");
    }
}

bool RLV_TFW_HasAnActionFailed(void)
{
    bool retVal = false;
    for(uint8_t id = 0; id < RLV_MAX_NUMBER_OF_STORED_DATA; id++)
    {
        if(failedActions[id])
        {
            retVal = true;
            break;
        }
    }
    return retVal;
}

void RLV_TFW_SetFailedAction(uint8_t id, bool status)
{
    if (id < RLV_MAX_NUMBER_OF_STORED_DATA)
    {
        failedActions[id] = status;
    }
    else
    {
        RLV_LOG_ERROR("in RLV_TFW_SetFailedAction, buffer overflow ");
    }
}


#endif //RF_LLD_VALIDATION