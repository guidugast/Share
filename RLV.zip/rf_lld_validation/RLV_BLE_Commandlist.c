  /*******************************************************************************
  * @file    TODO.c
  * @author  MCD Application Team
  * @brief   TODO
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#ifdef USE_PROTOCOL_802154
    #include "ip802154_lld.h"
    #include "ip802154_lld_priv.h"
    #include "ip802154_lld_registers.h"
    #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
    #include "ipBLE_lld.h"
    #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE

#include "RLV_TestFramework.h"
#include "RLV_Logger.h"
#include "RLV_BLE_Steplist.h"
#include "RLV_BLE_Commandlist.h"
#include "RLV_TFW_Commandlist.h"
#include "RLV_EnvParameters.h"

////////////////////////////////////////////////////////////////////////////////
//////////////////             Public functions               //////////////////
////////////////////////////////////////////////////////////////////////////////
DEF_command(BLE_Command__PrintTestEnvParameters,
    RLV_BLE_PrintTestEnvParameters();
)

DEF_command(BLE_Command__InitBoardWithHal,
    ///READ PARAM VALUE
    // No arg
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__HalBleInit);
)

DEF_command(BLE_Command__InitBoardWithLld,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(hsStartupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(lowSpeedOsc);
        RLV_TFW__ADD_CMD_ARG_PARAM(whitening);
        RLV_TFW__ADD_CMD_ARG_PARAM(hotAnaTable);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
        
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__LldBleInit); 
)

DEF_command(BLE_Command__SetNetworkId,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(networkId);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__SetNetworkId);
)

DEF_command(BLE_Command__InitBoardThenSendOnePacket_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(txHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(txPayload);
        RLV_TFW__ADD_CMD_ARG_PARAM(txAckReceiveWindow);
        RLV_TFW__ADD_CMD_ARG_PARAM(txAckExpectedHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(txAckExpectedPayload);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__LldBleInit);//TODO change to HAL?
    RLV_TFW__RUN_STEP(BLE_Step__SetNetworkId);
    RLV_TFW__RUN_STEP(BLE_Step__SendOnePacket_HAL);
)

DEF_command(BLE_Command__InitBoardThenWaitForAPacket_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedPayload);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxReceiveWindow);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxAckHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxAckPayload);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__LldBleInit);
    RLV_TFW__RUN_STEP(BLE_Step__SetNetworkId);
    RLV_TFW__RUN_STEP(BLE_Step__ReceiveOnePacket_HAL);
)

DEF_command(BLE_Command__SendOnePacket_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(txHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(txPayload);
        RLV_TFW__ADD_CMD_ARG_PARAM(txAckReceiveWindow);
        RLV_TFW__ADD_CMD_ARG_PARAM(txAckExpectedHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(txAckExpectedPayload);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__SendOnePacket_HAL);
            
)

DEF_command(BLE_Command__WaitForAPacket_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedPayload);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxReceiveWindow);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxAckHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxAckPayload);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__ReceiveOnePacket_HAL);
)

DEF_command(BLE_Command__FinishAndFreeze,
    RLV_LOG_LINE("------------------- End of command"); //simulate a command that finished but freze
    while(RLV_Parameters_ptr->crystalCheckEnabled); //block device (parameter is used to avoid "statement out of reach" warning)
)

DEF_command(BLE_Command__FreezeAndNotFinish,
   //simulate a command that freezes before finishing
    while(RLV_Parameters_ptr->crystalCheckEnabled);//block device (parameter is used to avoid "statement out of reach" warning)
)

DEF_command(BLE_Command__DoWithTimeout,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(stressDurationInS);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxStressDeltaBlockingDelayInUs);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__LldBleInit);
    RLV_TFW__RUN_STEP(RLV_Step__DoWithTimeout);
)

DEF_command(BLE_Command__TimerTest,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(stressDurationInS);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxStressDeltaBlockingDelayInUs);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
 
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__TimerTest);
)

DEF_command(BLE_Command__TxStress_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(stressDurationInS);
        RLV_TFW__ADD_CMD_ARG_PARAM(txStressDeltaBlockingDelayInUs);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__TxStress_HAL);
)

DEF_command(BLE_Command__RxStress_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(stressDurationInS);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxStressDeltaBlockingDelayInUs);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__RxStress_HAL);
)

DEF_command(BLE_Command__PingPongStress_HAL,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(withAck);
        RLV_TFW__ADD_CMD_ARG_PARAM(stressDurationInS);
        RLV_TFW__ADD_CMD_ARG_PARAM(txFirstInPingPong);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxStressDeltaBlockingDelayInUs);
        RLV_TFW__ADD_CMD_ARG_PARAM(txStressDeltaBlockingDelayInUs);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__PingPongStress_HAL);
)

DEF_command(BLE_Command__InitBoardThenSendOnePacket,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(txHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(txPayload);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__LldBleInit);
    RLV_TFW__RUN_STEP(BLE_Step__SendOneSimplePacket);
)

DEF_command(BLE_Command__InitBoardThenWaitForAPacket,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedPayload);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxReceiveWindow);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__LldBleInit);
    RLV_TFW__RUN_STEP(BLE_Step__ReceiveOneSimplePacket);
)

DEF_command(BLE_Command__SendOnePacket,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(txHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(txPayload);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__SendOneSimplePacket);
)

DEF_command(BLE_Command__WaitForAPacket,
    ///READ PARAM VALUE
    if(argNumber != 0)
    {
        RLV_TFW__ADD_CMD_ARG_PARAM(channel);
        RLV_TFW__ADD_CMD_ARG_PARAM(wakeupTime);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedHeader);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxExpectedPayload);
        RLV_TFW__ADD_CMD_ARG_PARAM(rxReceiveWindow);
    }
    else
    {
        //do nothing, use preset value for each parameter
    }
    
    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__ReceiveOneSimplePacket);
)

DEF_command(BLE_Command__GetStatus,
    ///READ PARAM VALUE
    //no arg

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__GetStatus);
)

DEF_command(BLE_Command__StartTone,
    ///READ PARAM VALUE
    //no arg

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__StartTone);
)

DEF_command(BLE_Command__StopTone,
    ///READ PARAM VALUE
    //no arg

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__StopTone);
)

DEF_command(BLE_Command__StopActivity,
    ///READ PARAM VALUE
    //no arg

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__StopActivity);
)

DEF_command(BLE_Command__EncryptPlainData,
    ///READ PARAM VALUE
    //no arg

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__EncryptPlainData);
)

DEF_command(BLE_Command__BuildActionPacketChainFromBuffer,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__BuildActionPacketChainFromBuffer);
)

DEF_command(BLE_Command__BuildCurrentActionPacketInBuffer,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__BuildCurrentActionPacketInBuffer);
)

DEF_command(BLE_Command__BuildStateMachine,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__BuildStateMachine);
)

DEF_command(BLE_Command__RunActionPacketChain,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__RunActionPacketChain);
)

DEF_command(BLE_Command__RunApChainAndWaitForItToFinish,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__RunApChainAndWaitForItToFinish);
)

DEF_command(BLE_Command__CompareReceivedPacket,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__CompareReceivedPacket);
)

DEF_command(BLE_Command__ShowStressResults,
    ///READ PARAM VALUE
    //no arg, use set_param, get_param

    ///RUN STEPS
    RLV_TFW__RUN_STEP(BLE_Step__ShowStressResults);
)

#endif //RF_LLD_VALIDATION