 /*******************************************************************************
  * @file    smps_lld.c
  * @author  MCD Application Team
  * @brief   main functions for SMPS LLD tests
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "common.h"
#include "logging.h"
#include "common_rf_types.h"
#include "common_rf_lld.h"
#include "smps_lld.h"

// Uncomment to have some debug traces
//#define DEBUG_SMPS

/**
 * @brief Set the  SMPS voltage output scaling
 *
 * @param SMPSVOS: output voltage level selection. 1.2V + SMPSVOS x 50mV, in the range 0..F
 *
 * @return COMMON_RF_SUCCESS if the SMPSVOS is in the correct range /  BAD_ARGUMENT if not
 */
uint32_t smps_lld_enableOnHsi(uint32_t smpsvos) {
#ifdef DEBUG_SMPS
  uint32_t smpsStatus;
#endif
  
  //Check for smpsvos values in range 0x00 .. 0x0F
  if (smpsvos > 0x0F) {
    return BAD_ARGUMENT;
  }
  
#ifdef DEBUG_SMPS
  common_rf_M0SendTracePtr("SMPS before enable on HSI");
  smpsStatus = smps_lld_isEnabled();
  if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSE) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSE with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSI) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSI with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == 0xFF) {
    common_rf_M0SendTracePtr("    SMPS disabled");
  } else {
    common_rf_M0SendTracePtr("    SMPS status 0x%08X", smpsStatus);
  }
  us_delay(100000);
#endif
  
  //Start HSI
  LL_RCC_HSI_Enable();
  while (!LL_RCC_HSI_IsReady())   /* Wait HSI ready */;
  
  //Configure the SMPS (HSI, 4MHz, Voltage, BORH..)
  LL_RCC_SetSMPSClockSource(RCC_SMPSCLKSOURCE_HSI);                    /**< SMPS Clock set to HSI */
  LL_RCC_SetSMPSPrescaler(RCC_SMPSCLKDIV_RANGE1);                      /**< SMPS Clock set to 4MHz */
  LL_PWR_SMPS_SetStartupCurrent(LL_PWR_SMPS_STARTUP_CURRENT_200MA);   /**< Set Peak current especially at startup */
  LL_PWR_SetBORConfig(LL_PWR_BOR_SMPS_FORCE_BYPASS);                  /**< Set automatic fall Bypass mode if voltage is too low */
  
  // Set SMPS step down converter output voltage scaling
  LL_PWR_SMPS_SetOutputVoltageLevel(smpsvos);
  
  LL_PWR_SMPS_Enable(); // Enable

  // Folowing check is not possible as if HSE is present, the SMPS will use it
  //while (LL_RCC_GetSMPSClockSource() != LL_RCC_SMPS_CLKSOURCE_STATUS_HSI);
  
  us_delay(20000);    // To be sure we are at the right level
  
#ifdef DEBUG_SMPS
  common_rf_M0SendTracePtr("SMPS after enable on HSI");
  smpsStatus = smps_lld_isEnabled();
  if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSE) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSE with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSI) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSI with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == 0xFF) {
    common_rf_M0SendTracePtr("    SMPS disabled");
  } else {
    common_rf_M0SendTracePtr("    SMPS status 0x%08X", smpsStatus);
  }
  us_delay(100000);
#endif
  
  return COMMON_RF_SUCCESS;
}

/**
 * @brief Set the  SMPS voltage output scaling
 *
 * @param SMPSVOS: output voltage level selection. 1.2V + SMPSVOS x 50mV, in the range 0..F
 *
 * @return COMMON_RF_SUCCESS if the SMPSVOS is in the correct range /  BAD_ARGUMENT if not
 */
uint32_t smps_lld_enableOnHse(uint32_t smpsvos) {
#ifdef DEBUG_SMPS
  uint32_t smpsStatus;
#endif
  
  //Check for smpsvos values in range 0x00 .. 0x0F
  if (smpsvos > 0x0F) {
    return BAD_ARGUMENT;
  }
  
#ifdef DEBUG_SMPS
  common_rf_M0SendTracePtr("SMPS before enable on HSE");
  smpsStatus = smps_lld_isEnabled();
  if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSE) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSE with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSI) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSI with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == 0xFF) {
    common_rf_M0SendTracePtr("    SMPS disabled");
  } else {
    common_rf_M0SendTracePtr("    SMPS status 0x%08X", smpsStatus);
  }
  us_delay(100000);
#endif
  
  // Configure SMPS to use HSE clock and divide it to have an input clock between 2 MHz and 8 MHz
  // Folowing config will set SMPS to HSE (32Mhz) and which will be divided to become 4Mhz
  LL_RCC_SetSMPSPrescaler(LL_RCC_SMPS_DIV_1);
  LL_RCC_SetSMPSClockSource(LL_RCC_SMPS_CLKSOURCE_HSE);
  
  // Set SMPS startup current
  LL_PWR_SMPS_SetStartupCurrent(LL_PWR_SMPS_STARTUP_CURRENT_80MA);
  // Set SMPS step down converter output voltage scaling
  LL_PWR_SMPS_SetOutputVoltageLevel(smpsvos);
  
  // Enable SMPS
  LL_PWR_SMPS_Enable();
  
  while (LL_RCC_GetSMPSClockSource() != LL_RCC_SMPS_CLKSOURCE_STATUS_HSE);
  
  // To be sure we are at the right level
  us_delay(20000);
  
#ifdef DEBUG_SMPS
  common_rf_M0SendTracePtr("SMPS after enable on HSE");
  smpsStatus = smps_lld_isEnabled();
  if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSE) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSE with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == LL_RCC_SMPS_CLKSOURCE_STATUS_HSI) {
    common_rf_M0SendTracePtr("    SMPS enabled on HSI with output set to %u", LL_PWR_SMPS_GetOutputVoltageLevel());
  } else if (smpsStatus == 0xFF) {
    common_rf_M0SendTracePtr("    SMPS disabled");
  } else {
    common_rf_M0SendTracePtr("    SMPS status 0x%08X", smpsStatus);
  }
  us_delay(100000);
#endif
  
  return COMMON_RF_SUCCESS;
}

uint32_t smps_lld_isEnabled(void) {
  uint32_t status = 0xFF;
  
  if (LL_PWR_SMPS_IsEnabled()) {
    status = LL_RCC_GetSMPSClockSource();
  }
  return status;
}

/**
 * @brief Disable SMPS
 *
 * @return COMMON_RF_SUCCESS
 */
uint32_t smps_lld_disable(void) {
  // Disable SMPS
  LL_PWR_SMPS_Disable();
  
  return COMMON_RF_SUCCESS;
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
