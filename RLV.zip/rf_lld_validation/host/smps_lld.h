/**
 ******************************************************************************
 * @file    smps_lld.h
 * @brief   Low level driver for SMPS
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SMPS_LLD_H
#define __SMPS_LLD_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

/* Defines -------------------------------------------------------------------*/

/* Externes ------------------------------------------------------------------*/

/* Types ---------------------------------------------------------------------*/

/* Public functions prototypes -----------------------------------------------*/
/**
 * @brief Set the  SMPS voltage output scaling
 *
 * @param SMPSVOS: output voltage level selection. 1.2V + SMPSVOS x 50mV, in the range 0..F
 *
 * @return COMMON_RF_SUCCESS if the SMPSVOS is in the correct range /  BAD_ARGUMENT if not
 */
uint32_t smps_lld_enableOnHsi(uint32_t smpsvos);
uint32_t smps_lld_enableOnHse(uint32_t smpsvos);

uint32_t smps_lld_isEnabled(void);

/**
 * @brief Disable SMPS
 *
 * @return COMMON_RF_SUCCESS
 */
uint32_t smps_lld_disable(void);

#ifdef __cplusplus
}
#endif

#endif /* __SMPS_LLD_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
