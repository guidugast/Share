 /*******************************************************************************
  * @file    stm32_lpm_if.c
  * @author  MCD Application Team
  * @brief   Low layer function to enter/exit low power modes (stop, sleep)
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/  
#include "stm32_lpm_if.h"
#include "stm32_lpm.h"
/* USER CODE BEGIN include */
#include "app_conf.h"
#if 0
#include "ip802154_lld.h"
#include "ip802154_lld_priv.h"
#include "ip802154_lld_registers.h"
extern uint32_t ip802154_lld_802154Wakeup(void);
#endif

/* USER CODE END include */

/* Exported variables --------------------------------------------------------*/
const struct UTIL_LPM_Driver_s UTIL_PowerDriver = 
{
  PWR_EnterSleepMode,
  PWR_ExitSleepMode,
  
  PWR_EnterStopMode,
  PWR_ExitStopMode, 
  
  PWR_EnterOffMode,
  PWR_ExitOffMode,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN Private_Function_Prototypes */
static void Enter_Low_Power( void );
static void Exit_Low_Power( void );
static void Switch_On_HSI( void );

/* USER CODE END Private_Function_Prototypes */
/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN Private_Typedef */

/* USER CODE END Private_Typedef */
/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Private_Define */

/* USER CODE END Private_Define */
/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Private_Macro */

/* USER CODE END Private_Macro */
/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Private_Variables */
LPM_lowPower_mode_t M0_LPM_mode = LPM_NO_STOP;

/* USER CODE END Private_Variables */

/**
  * @brief Enters Low Power Off Mode
  * @param none
  * @retval none
  */
void PWR_EnterOffMode( void )
{
/* USER CODE BEGIN PWR_EnterOffMode */
  M0_LPM_mode = LPM_STAND_BY;

  Enter_Low_Power();

#if ( CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_RESET( DBG_GPIO_GR1_IDLE );
#endif

  /************************************************************************************
   * ENTER OFF MODE
   ***********************************************************************************/
  LL_C2_PWR_SetPowerMode( LL_PWR_MODE_SHUTDOWN );

  LL_LPM_EnableDeepSleep( ); /**< Set SLEEPDEEP bit of Cortex System Control Register */

  /**
   * This option is used to ensure that store operations are completed
   */
#if defined ( __CC_ARM)
  __force_stores( );
#endif

  __WFI( );

/* USER CODE END PWR_EnterOffMode */
}

/**
  * @brief Exits Low Power Off Mode
  * @param none
  * @retval none
  */
void PWR_ExitOffMode( void )
{
/* USER CODE BEGIN PWR_ExitOffMode */
#if ( CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_SET( DBG_GPIO_GR1_IDLE );
#endif
  M0_LPM_mode = LPM_NO_STOP;

  Exit_Low_Power();

/* USER CODE END PWR_ExitOffMode */
}

/**
  * @brief Enters Low Power Stop Mode
  * @note ARM exists the function when waking up
  * @param none
  * @retval none
  */
void PWR_EnterStopMode( void )
{
/* USER CODE BEGIN PWR_EnterStopMode */
  Enter_Low_Power();

#if ( CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_RESET( DBG_GPIO_GR1_IDLE );
#endif
#ifdef COMMON_RF_DBG_GPIO
  gpio_lld_phy_pb13_up();
#endif

  /************************************************************************************
   * ENTER STOP MODE
   ***********************************************************************************/
  if ((M0_LPM_mode != LPM_STOP_0) && (M0_LPM_mode != LPM_STOP_1) && (M0_LPM_mode != LPM_STOP_2)) {
    M0_LPM_mode = LPM_STOP_2;
  }
  LL_C2_PWR_SetPowerMode( (uint32_t) M0_LPM_mode );

  LL_LPM_EnableDeepSleep( ); /**< Set SLEEPDEEP bit of Cortex System Control Register */

  /**
   * This option is used to ensure that store operations are completed
   */
#if defined ( __CC_ARM)
  __force_stores( );
#endif

  __WFI();

#ifdef COMMON_RF_DBG_GPIO
  gpio_lld_phy_pb13_down();
#endif
/* USER CODE END PWR_EnterStopMode */
}

/**
  * @brief Exits Low Power Stop Mode
  * @param none
  * @retval none
  */
void PWR_ExitStopMode( void )
{
/* USER CODE BEGIN PWR_ExitStopMode */
#if ( CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_SET( DBG_GPIO_GR1_IDLE );
#endif

#ifdef COMMON_RF_DBG_GPIO
  gpio_lld_phy_pb13_up();
#endif

  M0_LPM_mode = LPM_NO_STOP;

  Exit_Low_Power();

#ifdef COMMON_RF_DBG_GPIO
  gpio_lld_phy_pb13_down();
#endif
/* USER CODE END PWR_ExitStopMode */
}

/**
  * @brief Enters Low Power Sleep Mode
  * @note ARM exits the function when waking up
  * @param none
  * @retval none
  */
void PWR_EnterSleepMode( void )
{
/* USER CODE BEGIN PWR_EnterSleepMode */
#if (CFG_RF_POWER_MEASUREMENT != 0)
  LL_RCC_HSE_EnableDiv2();
  LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE2);
#endif

#if ( CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_RESET( DBG_GPIO_GR1_IDLE );
#endif

  M0_LPM_mode = LPM_NO_STOP;

  /************************************************************************************
   * ENTER SLEEP MODE
   ***********************************************************************************/
  LL_LPM_EnableSleep( ); /**< Clear SLEEPDEEP bit of Cortex System Control Register */

  /**
   * This option is used to ensure that store operations are completed
   */
#if defined ( __CC_ARM)
  __force_stores();
#endif

  __WFI( );

/* USER CODE END PWR_EnterSleepMode */
}

/**
  * @brief Exits Low Power Sleep Mode
  * @note ARM exits the function when waking up
  * @param none
  * @retval none
  */
void PWR_ExitSleepMode( void )
{
/* USER CODE BEGIN PWR_ExitSleepMode */
#if ( CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_SET( DBG_GPIO_GR1_IDLE );
#endif
  M0_LPM_mode = LPM_NO_STOP;

#if (CFG_RF_POWER_MEASUREMENT != 0)
  LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE1);
  while(LL_PWR_IsActiveFlag_VOS());
  LL_RCC_HSE_DisableDiv2();
#endif

/* USER CODE END PWR_ExitSleepMode */
}

/* USER CODE BEGIN Private_Functions */
/*************************************************************
 *
 * LOCAL FUNCTIONS
 *
 *************************************************************/
static void Enter_Low_Power( void )
{
  /**
   * This function is called from CRITICAL SECTION
   */

  /**
   * It is required to switch to HSI on Stop Mode entry for two reasons
   *
   * 1/ On Cut2.0, when SMPS is used, there is a HW issue when the HSE is selected as system clock on
   *    any Stop Mode entry
   *
   * 2/ On Cut2.1, when SMPS is used, there is a HW issue when the HSE is selected as system clock on
   *    Stop Mode 0
   *
   * As the switch to HSI does not hurt, it should be kept forever
   */

  while( LL_HSEM_1StepLock( HSEM, CFG_HW_RCC_SEMID ) );

  if ( ! LL_HSEM_1StepLock( HSEM, CFG_HW_ENTRY_STOP_MODE_SEMID ) )
  {
    if( LL_PWR_IsActiveFlag_C1DS() )
    {
      /* Release ENTRY_STOP_MODE semaphore */
      LL_HSEM_ReleaseLock( HSEM, CFG_HW_ENTRY_STOP_MODE_SEMID, 0 );

      Switch_On_HSI();
    }
  }
  else
  {
    Switch_On_HSI();
  }

  /* Release RCC semaphore */
  LL_HSEM_ReleaseLock( HSEM, CFG_HW_RCC_SEMID, 0 );
}

static void Exit_Low_Power( void )
{
  /**
   * This function is called from CRITICAL SECTION
   */

  /* Release ENTRY_STOP_MODE semaphore */
  LL_HSEM_ReleaseLock( HSEM, CFG_HW_ENTRY_STOP_MODE_SEMID, 0 );

  while( LL_HSEM_1StepLock( HSEM, CFG_HW_RCC_SEMID ) );

  if(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_HSE)
  {
    LL_RCC_HSE_Enable();
    while(!LL_RCC_HSE_IsReady());
    LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_HSE);
    while (LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_HSE);
    // Wait a little bit to have time between HSE ready and SF timer register content updated
    us_delay(50);
#if 0
    putInTraceBuff(40);
    gpio_lld_phy_pb13_down();
#if 1
  //pas bon
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
    gpio_lld_phy_pb13_up();
  // bon
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
    gpio_lld_phy_pb13_down();
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
    gpio_lld_phy_pb13_up();
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
#endif
#if 0
    LL_C2_PWR_WakeUp_802_15_4();
    gpio_lld_phy_pb13_up();
    putInTraceBuff(LL_C2_PWR_IsWokenUp_802_15_4());
    gpio_lld_phy_pb13_down();
    putInTraceBuff(LL_C2_PWR_IsWokenUp_802_15_4());
    gpio_lld_phy_pb13_up();
    putInTraceBuff(LL_C2_PWR_IsWokenUp_802_15_4());
    gpio_lld_phy_pb13_down();
    putInTraceBuff(LL_C2_PWR_IsWokenUp_802_15_4());
    gpio_lld_phy_pb13_up();
    putInTraceBuff(LL_C2_PWR_IsWokenUp_802_15_4());
#endif
#if 0
    LL_C2_PWR_WakeUp_802_15_4();
    gpio_lld_phy_pb13_up();
    while(LL_C2_PWR_IsWokenUp_802_15_4());
    gpio_lld_phy_pb13_down();
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
    gpio_lld_phy_pb13_up();
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
    gpio_lld_phy_pb13_down();
    putInTraceBuff(ip802154_lld_getSFTimer()*16);
    gpio_lld_phy_pb13_up();
    putInTraceBuff(LL_C2_PWR_IsWokenUp_802_15_4());
#endif
#endif
  }

  /* Release RCC semaphore */
  LL_HSEM_ReleaseLock( HSEM, CFG_HW_RCC_SEMID, 0 );
}

/**
  * @brief Switch the system clock on HSI
  * @param none
  * @retval none
  */
static void Switch_On_HSI( void )
{
  LL_RCC_HSI_Enable();
  while(!LL_RCC_HSI_IsReady());
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_HSI);
  LL_RCC_SetSMPSClockSource(LL_RCC_SMPS_CLKSOURCE_HSI);
  while (LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_HSI);
}

/* USER CODE END Private_Functions */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

