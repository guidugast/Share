/**
 ******************************************************************************
 * @file    host_rlv.h
 * @author  MCD Application Team
 * @brief   Thread Application
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics International N.V.
 * All rights reserved.</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted, provided that the following conditions are met:
 *
 * 1. Redistribution of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of STMicroelectronics nor the names of other
 *    contributors to this software may be used to endorse or promote products
 *    derived from this software without specific written permission.
 * 4. This software, including modifications and/or derivative works of this
 *    software, must execute solely and exclusively on microcontroller or
 *    microprocessor devices manufactured by or for STMicroelectronics.
 * 5. Redistribution and use of this software other than as permitted under
 *    this license is void and will automatically terminate your rights under
 *    this license.
 *
 * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
 * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT
 * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HOST_RLV_H
#define __HOST_RLV_H

#ifdef __cplusplus
extern "C" {
#endif

  /* Includes ------------------------------------------------------------------*/
#include "common.h"
#include "tl.h"

typedef struct {
  uint32_t revId;        // Cut version : content of DBGMCU.REVID which is only accessible by M4
  uint32_t devId;        // device ID : content of DBGMCU.DEVID which is only accessible by M4 should be 0x06495 for STM32WB5
  uint8_t  packageInfo;  // pakage info which should be in Flash engineering options at address 0x1FFF7500
  uint32_t uid64[2];     // UID64 info which should be in Flash at address 0x1FFF7580
} HwInfoStruct;
extern HwInfoStruct common_hwInfo;

/**
 * @brief Dump RF IPs registers
 * @param regType is a bit field : 
 *                bit 0 for 802.15.4 IP registers, 
 *                bit 1 for RF IP SPI registers, 
 *                bit 2 for RF IP registers...
 */
extern void HOST_LldTests_dumpRFRegs(uint32_t regType);

/**
 * @brief Print info related to :
 *          - FW embeded in M0
 *          - RF LLDs used
 *          - HW under test
 * @param output 0 to send data to trace log system
 *               other value to send data to CLI command UART
 */
extern void HOST_LldTests_PrintInfo(uint32_t output);

#ifdef RF_LLD_VALIDATION
/**
 * @brief  HOST RLV Initialization
 *
 * @param  pParam : pointer with devId and RevId given by M4 to M0
 * @retval None
 */
extern void HOST_RLV_Init( uint32_t * pParam);
#endif //RF_LLD_VALIDATION

/**
 * @brief  HOST LLD tests Initialization
 *
 * @param  pParam : pointer with devId and RevId given by M4 to M0
 * @retval None
 */
extern void HOST_LldTests_Init( uint32_t * pParam);

/* *
 * @brief  API to send traces through IPCC trace channel
 *
 * @param  Str  : pointer to a buffer with a string conntaining the chars to send
 * @param  Size : size of the string
 * @retval None
*/
extern void HOST_LldTestsSendTrace(char * Str, uint16_t Size);

/**
 * @brief API to send a command from M0 to M4 using CLI response channel
 *
 * @param  cmd : pointer to a buffer with a string conntaining the command (decoded on M4 side)
 * @retval None
 */
extern void HOST_LldTestsSendM0CmdToM4(const char * cmd);

/**
 * @brief API to send a command response from M0 to M4
 *
 * @param  aBuf       : pointer to a buffer with a string conntaining the command (decoded on M4 side)
 * @param  aBufLength : size of the string
 * @retval None
 */
extern void HOST_LldTestsSendCliRspToM4(const char * aBuf, uint16_t aBufLength);

#ifdef __cplusplus
}
#endif

#endif /*__HOST_RLV_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
