/**
 ******************************************************************************
 * @file    config_rlv.h
 * @author  MCD Application Team
 * @version V1.0.0
 * @date    17-May-2016
 * @brief   Application configuration file
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright c 2016 STMicroelectronics International N.V.
 * All rights reserved.</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted, provided that the following conditions are met:
 *
 * 1. Redistribution of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of STMicroelectronics nor the names of other 
 *    contributors to this software may be used to endorse or promote products 
 *    derived from this software without specific written permission.
 * 4. This software, including modifications and/or derivative works of this 
 *    software, must execute solely and exclusively on microcontroller or
 *    microprocessor devices manufactured by or for STMicroelectronics.
 * 5. Redistribution and use of this software other than as permitted under 
 *    this license is void and will automatically terminate your rights under 
 *    this license. 
 *
 * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
 * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
 * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __RLV_CONFIG_H
#define __RLV_CONFIG_H

/* Includes ------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

/* ------------------------------------------------------------------------- *
 * Semaphores                                                                *
 * ------------------------------------------------------------------------- */

//* Includes ------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

/******************************************************************************
 * Low power management
 *****************************************************************************/
// Do not activate LPM here in LLD tests. It will be enabled in some specific tests
// when needed using UTIL_LPM functions
#define CFG_LPM_SUPPORTED       0

/******************************************************************************
 * Semaphores
 *****************************************************************************/

/* Index of the semaphore used to access the RCC */
#define CFG_HW_FLASH_SEMID                          ( 2 )

/* Index of the semaphore used to access the RCC */
#define CFG_HW_RCC_SEMID                            ( 3 )

/* Index of the semaphore used to manage the entry Stop Mode procedure */
#define CFG_HW_ENTRY_STOP_MODE_SEMID                ( 4 )

/* Index of the semaphore used to manage the CLK48 clock configuration */
#define CFG_HW_CLK48_CONFIG_SEMID                   ( 5 )

/* Index of the semaphore to use by CPU1 to prevent the CPU2 to either write or erase data in flash */
#define CFG_HW_BLOCK_FLASH_REQ_BY_CPU1_SEMID        ( 6 )

/* Index of the semaphore to use by CPU2 to prevent the CPU1 to either write or erase data in flash */
#define CFG_HW_BLOCK_FLASH_REQ_BY_CPU2_SEMID        ( 7 )

/* Index of the semaphore used to access the BLE NVM SRAM shared with the CPU1 */
#define CFG_HW_BLE_NVM_SRAM_SEMID                   ( 8 )

/* Index of the semaphore used to access the OT NVM SRAM shared with the CPU1 */
#define CFG_HW_THREAD_NVM_SRAM_SEMID                    ( 9 )

/******************************************************************************
 * Sequencer
 ******************************************************************************/

/**
 * This is the list of task id required by the application
 * Each Id shall be in the range 0..31
 */

typedef enum
{
  /* SYSTEM TASKS */
  CFG__NVMProcess,
  CFG__NVMSramBleProcess,
  CFG__NVMSramOtProcess,
  CFG__SysReinit,
  CFG__RngProcessReq,
  CFG__SysCmdProcessReq,

  /* LLD TESTS TASKS */
  CFG_GetCliCmdReq,
  CFG_ProcessCliCmdReq,
  CFG_ProcessRxFrames,

  CFG_TASK_NBR  /**< Shall be last in the list */
} CFG_IdleTask_Id_t;

/**
 * This is the list of priority required by the application
 * Each Id shall be in the range 0..31
 */
typedef enum
{
  CFG_SEQ_Prio_0,
  CFG_SEQ_Prio_1,
  CFG_PRIO_NBR,
} CFG_SEQ_Prio_Id_t;

/**
* This is a bit mapping over 32bits listing all events id supported in the application
*/
typedef enum
{
  CFG_ReceiveCliRspAckEvt,
  CFG_ReceiveM0CmdAckEvt,
  CFG_IDLEEVT_FLASH_ACTIVITY_ALLOWED_BY_CPU1,
  CFG_IDLEEVT_FLASH_ACTIVITY_ALLOWED_BY_CPU2,
} CFG_IdleEvt_Id_t;

/******************************************************************************
 * LOW POWER
 ******************************************************************************/
/**
 * Supported requester to the MCU Low Power Manager - can be increased up  to 32
 * It lits a bit mapping of all user of the Low Power Manager
 */
typedef enum
{
  CFG_LPM_App_LldTests,
} CFG_LPM_Id_t;
#endif  /*__RLV_CONFIG_H */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
