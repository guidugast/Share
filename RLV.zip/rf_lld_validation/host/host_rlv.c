/**
 ******************************************************************************
 * @file    host_rlv.c
 * @author  MCD Application Team
 * @brief   RF LLD tests Application
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics International N.V.
 * All rights reserved.</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted, provided that the following conditions are met:
 *
 * 1. Redistribution of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of STMicroelectronics nor the names of other
 *    contributors to this software may be used to endorse or promote products
 *    derived from this software without specific written permission.
 * 4. This software, including modifications and/or derivative works of this
 *    software, must execute solely and exclusively on microcontroller or
 *    microprocessor devices manufactured by or for STMicroelectronics.
 * 5. Redistribution and use of this software other than as permitted under
 *    this license is void and will automatically terminate your rights under
 *    this license.
 *
 * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
 * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT
 * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "common.h"
#include "logging.h"
#include "host_sys.h"
#include "stm32_seq.h"
#include "stm32_lpm.h"
#include "memory_manager.h"
#include "mbox_def.h"
#include "shci.h"
#include "common_rf_types.h"
#include "common_rf_lld.h"
#include "radio_lld.h"
#include "radio_spi.h"
#ifdef USE_PROTOCOL_802154
    #include "ip802154_lld.h"
    #include "ip802154_lld_priv.h"
    #include "ip802154_lld_registers.h"
#else
    #include "ipBLE_lld.h"
    #include "ipBLE_lld_priv.h"
#endif

#include "host_rlv.h"

#include "RLV_TestFramework.h"
#include "RLV_CommandParser.h"
#include "RLV_EnvParameters.h"
#include "RLV_TFW_Data.h"
#include "RLV_TFW_Types.h"
#include "RLV_Logger.h"

/* Private typedef -----------------------------------------------------------*/

/* Private defines -----------------------------------------------------------*/
#define HOST_LLDTESTS_EVTCODE                 (0xFF)
#define HOST_LLDTESTS_TRACES_SUBEVTCODE_BASE  (0xC100)

#define HOST_LLDTESTS_CLI_CMD_BUFFER_SIZE     1024

/* Private macros ------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
/* Pointer shared with M4 to tranfert CLI command or CLI response info
   Its size is limited to 255 bytes so, it must contain only the buffer adress if bigger size is needed.
   Note that this packet is also used for CLI response (or CLI printf) so, content must be used to copy 
   the command before any CLI printf */
static TL_CmdPacket_t *  pCliCmdRspPacket;
/* Local buffer to copy the entire command given by M4 */
static char              cliCmdBuffer[HOST_LLDTESTS_CLI_CMD_BUFFER_SIZE];
/* Number of CLI commands arived in M0 : if higher than 1 (i.e. M0 is already under command treatment), command is lost */
static volatile uint16_t cliCmdReceivedNb = 0;
/* Pointer to the current CLI response buffer */
static const char *      pCliRspBuf = NULL;
static uint16_t          cliRspLength = 0;
/* Pointer to the current M0 command to M4 buffer */
static const char *      pM0CmdToM4Buf = NULL;
static uint16_t          m0CmdToM4Length = 0;
/* Pointer to the packet used to send commands from M0 to M4 throught API HOST_LldTestsSendM0CmdToM4()) */
static TL_CmdPacket_t *  pM0CmdToM4Packet;

// Default DTB bus init
uint8_t cliDbtCfg = 0xff;
//uint8_t cliDbtCfg = 0x7;

/* Global variables ----------------------------------------------------------*/
HwInfoStruct  common_hwInfo;

/* External variables --------------------------------------------------------*/
extern MB_WirelessFwInfoTable_t FW_Version;

/* Private function prototypes -----------------------------------------------*/

static void HOST_LldTests_Start(void);
static void HOST_LldTests_HandleRadioTrap(void);
static void HOST_LldTests_GetCliCmd(void);
static void HOST_LldTests_ProcessCliCmd(void);

/* Private functions Definition ----------------------------------------------*/


static void HOST_LldTests_Start(void)
{
  ltPlatLogSys("RF_LLD_VALIDATION: HOST_RLV_Start begins");

  /* Initialize M0 trace mechanism functions used by RF LLD */
  common_rf_m0Trace_init(ltPlatTraceDriver, HOST_LldTests_HandleRadioTrap);

  //answers M0 'info' request
  HOST_LldTests_PrintInfo(0);
 
  RLV_TFW_Init();

  // DTB bus init if required
  if (cliDbtCfg != 0xff)
  {
        radio_lld_enable_dbt(cliDbtCfg);
  }
  
  ltPlatLogSys("RF_LLD_VALIDATION: HOST_RLV_Start ends");
}

/**
 * @brief This function is the Application level handling of Radio Traps.
 *
 * Usually, for a developpement/debug version a while(TRUE) is used to be able to attach debugger.
 * For a deployment version, curativedecision nneds to be taken, in a case of a trap, a reset might be needed.
 */
static void HOST_LldTests_HandleRadioTrap(void)
{
  HOST_SYS_Error(ERR_THREAD_LLD_FATAL_ERROR);
  
  while(1);
}

/**
 * @brief  Get of CLI cmd from M4
 * @param  None
 * @retval None
 */
static void HOST_LldTests_GetCliCmd(void)
{
  TL_CmdPacket_t* p_cli = pCliCmdRspPacket;

  /* Copy to local string , TBD check if we can pass directly pointer to the M4 packet */
  //memcpy(cliCmdBuffer, p_cli->cmdserial.cmd.payload, p_cli->cmdserial.cmd.plen);
  char * sourceBuf = (char *)*(uint32_t *)p_cli->cmdserial.cmd.payload;
  uint32_t length = *(uint32_t *)&p_cli->cmdserial.cmd.payload[4];
  memcpy(cliCmdBuffer, sourceBuf, length);

  cliCmdReceivedNb++;

  /* CLI command process task scheduling*/
  UTIL_SEQ_SetTask( 1<< CFG_ProcessCliCmdReq, CFG_SEQ_Prio_0 );
}

/**
* @brief  Process the CLI command
* @param  None
* @retval None
*/
static void HOST_LldTests_ProcessCliCmd(void)
{
  /* If Command received is user defined command */
  if (cliCmdReceivedNb == 1)
  {
    // Send a trace with the command
    ltPlatLogSys("M0 received command : (%s)", cliCmdBuffer);
    
    // Parse the CLI command
    RLV_ParseCommandArgsAndRunCommand(cliCmdBuffer, strlen(cliCmdBuffer));

    // Clear receive buffer, character counter and command complete
    cliCmdReceivedNb = 0;
    memset(cliCmdBuffer, 0, HOST_LLDTESTS_CLI_CMD_BUFFER_SIZE);
    
    // Send the string "CLI_Resp end" to indicate that current command is ended
    HOST_LldTestsSendCliRspToM4("CLI_Resp end\0", 13);
  }
  else if (cliCmdReceivedNb > 1)
  {
    // Send a trace with the command
    ltPlatLogSys("ERROR : M0 can only manage one command !!");
  }
}

/* Public functions Definition -----------------------------------------------*/
/**
 * @brief Print info related to :
 *          - FW embeded in M0
 *          - RF LLDs used
 *          - HW under test
 * @param output 0 to send data to trace log system
 *               other value to send data to CLI command UART
 */
void HOST_LldTests_PrintInfo(uint32_t output)
{
  char     traceBuff[150] = "= M0 FW Type : Unknown !! ";
  uint32_t cliDriverVersion = 0;
  
  // Print test FW type and version of the loaded binary
  switch(FW_Version.InfoStack & INFO_STACK_TYPE_MASK)

  {
  case INFO_STACK_TYPE_802154_LLD_TESTS :
    sprintf(traceBuff,"M0@ = Firmware: 154 LLDs tests CLI (v%u.%u.%u) ", CFG_FW_MAJOR_VERSION, CFG_FW_MINOR_VERSION, CFG_FW_SUBVERSION);
    break;
    
  case INFO_STACK_TYPE_BLE_LLD_TESTS :
    sprintf(traceBuff, "M0@ = Firmware: BLE LLDs tests CLI (v%u.%u.%u) ", CFG_FW_MAJOR_VERSION, CFG_FW_MINOR_VERSION, CFG_FW_SUBVERSION);
    break;
  
  case INFO_STACK_TYPE_802154_PHY_VALID :
    sprintf(traceBuff, "M0@ = Firmware: 154 PHY validation (v%u.%u.%u)", CFG_FW_MAJOR_VERSION, CFG_FW_MINOR_VERSION, CFG_FW_SUBVERSION);
    break;
  
  case INFO_STACK_TYPE_BLE_PHY_VALID :
    sprintf(traceBuff, "M0@ = Firmware: BLE PHY validation (v%u.%u.%u)", CFG_FW_MAJOR_VERSION, CFG_FW_MINOR_VERSION, CFG_FW_SUBVERSION);
    break;
    
  case INFO_STACK_TYPE_RLV :
    sprintf(traceBuff, "M0@ = Firmware: RLV TestEngine (v%u.%u.%u) ", CFG_FW_MAJOR_VERSION, CFG_FW_MINOR_VERSION, CFG_FW_SUBVERSION);
    break;
  default :
    break;
  }
    ltPlatUartPrintf("M0@ ================================");
#ifdef STM32WB35xx
    ltPlatUartPrintf("M0@ = Target : WB35");
#elif STM32WB55xx
    ltPlatUartPrintf("M0@ = Target : WB55");
#else 
    ltPlatUartPrintf("M0@ = Internal Error: Target Unknown !");
    while(1U);
#endif
  
    if (output == 0)
        ltPlatLogSys(traceBuff);
    else
    {
        ltPlatUartPrintf(traceBuff);
    }
  
// Print 802.15.4 IP LLD version of the loaded binary
#if defined(USE_PROTOCOL_802154) // LLD tests CLI for 802.15.4
sprintf(traceBuff, "M0@ = 802.15.4 driver version : ");
cliDriverVersion = ip802154_lld_getVersion();
#endif
#if defined(USE_PROTOCOL_BLE)// LLD tests CLI for BLE
  sprintf(traceBuff, "M0@ = BLE driver version : ");
  cliDriverVersion = IPBLE_LLD_GetVersion();
#endif
  // Don't care of the higher digit, print only the 3 lowers
  sprintf(traceBuff, "%sv%u.%u.%u", traceBuff, (cliDriverVersion >> 16) & 0xFF, (cliDriverVersion >> 8) & 0xFF, (cliDriverVersion & 0xFF));
  if (output == 0)
    ltPlatLogSys(traceBuff);
  else
    ltPlatUartPrintf(traceBuff);
  
  // Print HW info to check if the loaded binary is appropriate
  sprintf(traceBuff, "M0@ = HW/system info :");
  if (common_hwInfo.revId == 0x1000)
    sprintf(traceBuff, "%s CUT 1.0", traceBuff);
  else if (common_hwInfo.revId == 0x1001)
    sprintf(traceBuff, "%s CUT 1.1", traceBuff);
  else if (common_hwInfo.revId == 0x2000)
    sprintf(traceBuff, "%s CUT 2.0", traceBuff);
  else if (common_hwInfo.revId == 0x2001)
    sprintf(traceBuff, "%s CUT 2.1", traceBuff);
  else
    sprintf(traceBuff, "%s !! unknown CUT !!", traceBuff);
  sprintf(traceBuff, "%s - Dev ID 0x%08X", traceBuff, common_hwInfo.devId);
  sprintf(traceBuff, "%s - Package info 0x%02X", traceBuff, common_hwInfo.packageInfo);
  sprintf(traceBuff, "%s - UID64 0x%08X 0x%08X", traceBuff, common_hwInfo.uid64[0], common_hwInfo.uid64[1]);
  if (output == 0)
    ltPlatLogSys(traceBuff);
  else
  {
    ltPlatUartPrintf(traceBuff);
    ltPlatUartPrintf("M0@ ================================");
  }
}

/**
 * @brief Dump RF IPs registers
 * @param regType is a bit field : 
 *                bit 0 for 802.15.4 IP registers, 
 *                bit 1 for RF IP SPI registers, 
 *                bit 2 for RF IP registers...
 */
void HOST_LldTests_dumpRFRegs(uint32_t regType)
{
 
}

/**
 * @brief  HOST LLD tests Initialization
 *
 * @param  pParam : pointer with devId and RevId given by M4 to M0
 * @retval None
 */
void HOST_LldTests_Init(uint32_t * pParam)
{
  common_hwInfo.devId       = pParam[0];
  common_hwInfo.revId       = pParam[1];
  common_hwInfo.packageInfo = *(volatile uint8_t *)0x1FFF7500;
  common_hwInfo.uid64[0]    = *(volatile uint32_t *)0x1FFF7580;
  common_hwInfo.uid64[1]    = *(volatile uint32_t *)0x1FFF7584;
  
  TL_LLDTESTS_Init(&pM0CmdToM4Packet);
  TL_TRACES_Init( );
  
  /* Enable HSEM clock */
  //LL_C2_AHB3_GRP1_EnableClock( LL_C2_AHB3_GRP1_PERIPH_HSEM );
  
  /* Creation of the tasks                                 */
  /* Note : Each task is associated to a flag which is set */
  /*        usually under interrupt                        */
  UTIL_SEQ_RegTask(1<<CFG_GetCliCmdReq, UTIL_SEQ_RFU, HOST_LldTests_GetCliCmd);
  UTIL_SEQ_RegTask(1<<CFG_ProcessCliCmdReq, UTIL_SEQ_RFU, HOST_LldTests_ProcessCliCmd);
   
  HOST_LldTests_Start();
  
  return;
}

/* *
 * @brief  Functions needed by transport layer module
 *
 * @param  pParam : pointer to command packet
 * @retval None
*/
void TL_LLDTESTS_ReceiveCliCmd( TL_CmdPacket_t * pcmd )
{
  pCliCmdRspPacket = pcmd;
  UTIL_SEQ_SetTask( 1<< CFG_GetCliCmdReq, CFG_SEQ_Prio_0 );
  
  return;
}

void TL_LLDTESTS_ReceiveCliRspAck( TL_CmdPacket_t * pcmd )
{
  UTIL_SEQ_SetEvt(1<< CFG_ReceiveCliRspAckEvt);
}

void TL_LLDTESTS_ReceiveM0CmdAck( TL_CmdPacket_t * pcmd )
{
  UTIL_SEQ_SetEvt(1<< CFG_ReceiveM0CmdAckEvt);
}

/* *
 * @brief  API to send traces through IPCC trace channel
 *
 * @param  Str  : pointer to a buffer with a string conntaining the chars to send
 * @param  Size : size of the string
 * @retval None
*/
void HOST_LldTestsSendTrace(char * Str, uint16_t Size)
{
  static TL_EvtPacket_t *p_evt;
  TL_AsynchEvt_t *p_asynchevt;
  uint16_t l_current_size = 0;
  uint16_t l_start_address_to_transfer = 0;
  uint16_t l_nbr_of_buffer_cnt = 0;

  /* Check string size if string size > 253 bytes (maximum size payload size for Vendor specific HCI Packet Event)
     In this case ask split in multiple request */
  uint16_t l_nbr_of_buffers_total = Size/253;

  /* If String buffer > 253 bytes, split it multiple post operations */
  /* If String buffer < 253 bytes, can be done in one single operation */
  for (l_nbr_of_buffer_cnt = 0; l_nbr_of_buffer_cnt <= l_nbr_of_buffers_total; l_nbr_of_buffer_cnt++)
  {
    if (l_nbr_of_buffers_total != l_nbr_of_buffer_cnt)
    {
      l_current_size = 253;
    }else{
      l_current_size = Size - (l_nbr_of_buffers_total*253);
    }

    if (l_nbr_of_buffers_total == 0){
      l_start_address_to_transfer = 0;
    }else{
      l_start_address_to_transfer = l_nbr_of_buffer_cnt*253;
    }

    /** Get one free buffer from Memory Manager **/
    /* Note : size parameter is not taken into account with current MM implementation */
    p_evt = (TL_EvtPacket_t *)MM_GetBuffer(l_current_size+2, 0);

    /* When p_evt = NULL -> Memory Manager cannot provide free buffer */
    /* -> skip the traces */
    if (p_evt != NULL)
    {
      p_evt->evtserial.evt.evtcode = HOST_LLDTESTS_EVTCODE;
      //p_evt->evtserial.evt.plen = Size + TL_EVT_SUBEVTCODE_SIZE;
      p_evt->evtserial.evt.plen = l_current_size + 2 ;
      p_asynchevt = (TL_AsynchEvt_t *)(p_evt->evtserial.evt.payload);

      p_asynchevt->subevtcode = HOST_LLDTESTS_TRACES_SUBEVTCODE_BASE;
      memcpy(p_asynchevt->payload, &Str[l_start_address_to_transfer], l_current_size);

      TL_TRACES_PostEvt(p_evt);
    }
  }
  return;
}

/**
 * @brief API to send a command from M0 to M4 using CLI response channel
 *
 * @param  cmd : pointer to a buffer with a string conntaining the command (decoded on M4 side)
 * @retval None
 */
void HOST_LldTestsSendM0CmdToM4(const char* cmd)
{
  //char cmdToSend[C_SIZE_CMD_STRING];
  //uint16_t cmdToSendSize;
  
  //sprintf(cmdToSend, "CLI_Cmd %s\0", cmd);
  //cmdToSendSize = strlen(cmdToSend);
  
  // Send the M0 command to M4 using the CLI response channel
  //HOST_LldTestsSendCliRspToM4(cmdToSend, cmdToSendSize);

  uint8_t newBuf = 0;
  
  if (cmd == NULL)
  {
    ltPlatLogSys("M0 command to M4 buffer NULL !!");
    return;
  }
  
  m0CmdToM4Length = strlen(cmd);
  if (m0CmdToM4Length > 255)
  {
    ltPlatLogSys("M0 command to M4 too long !!");
    m0CmdToM4Length = 0;
    return;
  }
  
  // Wait for last transmission ended
  do {
    CRITICAL_BEGIN();
    if (pM0CmdToM4Buf == NULL) {
      pM0CmdToM4Buf = cmd;
      newBuf = 1;
    }
    CRITICAL_END();
  }
  while (newBuf == 0);
  
  memset(pM0CmdToM4Packet->cmdserial.cmd.payload, 0x0U, 255U);
  memcpy(pM0CmdToM4Packet->cmdserial.cmd.payload, pM0CmdToM4Buf, m0CmdToM4Length);
  pM0CmdToM4Packet->cmdserial.cmd.plen = m0CmdToM4Length;
  pM0CmdToM4Packet->cmdserial.cmd.cmdcode = 0x0;
  
  TL_LLDTESTS_SendM0Cmd();
  
  /* Here wait for Ack from M4 before to go further */
  UTIL_SEQ_WaitEvt(1<< CFG_ReceiveM0CmdAckEvt);
  
  pM0CmdToM4Buf   = NULL;
  m0CmdToM4Length = 0;

}

/**
 * @brief API to send a command response from M0 to M4
 *
 * @param  aBuf       : pointer to a buffer with a string conntaining the command (decoded on M4 side)
 * @param  aBufLength : size of the string
 * @retval None
 */
void HOST_LldTestsSendCliRspToM4(const char *aBuf, uint16_t aBufLength)
{
  uint8_t newBuf = 0;
  
  if ((aBuf == NULL) || (aBufLength == 0))
  {
    ltPlatLogSys("CLI response buffer NULL or no length !!");
    return;
  }
  
  // Wait for last transmission ended
  do {
    CRITICAL_BEGIN();
    if (pCliRspBuf == NULL) {
      pCliRspBuf = aBuf;
      newBuf = 1;
    }
    CRITICAL_END();
  }
  while (newBuf == 0);
  
  cliRspLength = aBufLength;
  
  memset(pCliCmdRspPacket->cmdserial.cmd.payload, 0x0U, 255U);
  *(uint32_t *)pCliCmdRspPacket->cmdserial.cmd.payload = (uint32_t)pCliRspBuf;
  *(uint32_t *)&pCliCmdRspPacket->cmdserial.cmd.payload[4] = cliRspLength;
  pCliCmdRspPacket->cmdserial.cmd.plen = 8;
  pCliCmdRspPacket->cmdserial.cmd.cmdcode = 0x0;
  
  TL_LLDTESTS_SendCliRsp();
  
  /* Here wait for Ack from M4 before to go further */
  UTIL_SEQ_WaitEvt(1<< CFG_ReceiveCliRspAckEvt);
  
  pCliRspBuf   = NULL;
  cliRspLength = 0;
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
