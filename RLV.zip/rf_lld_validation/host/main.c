/**
  ******************************************************************************
  * @file    main.c
  * @author  MCD Application Team
  * @brief   Main program managing the Thread stack
  ******************************************************************************
  * @attention
  *
  *
  * <h2><center>&copy; Copyright c 2017 STMicroelectronics International N.V.
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice,
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other
  *    contributors to this software may be used to endorse or promote products
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under
  *    this license is void and will automatically terminate your rights under
  *    this license.
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
 */

#include "common.h"
#include "stm32_seq.h"
#include "stm32_lpm.h"
#include "tl.h"
#include "host_sys.h"
#include "hw_conf.h"
#include "nvm_arbiter.h"
#include "common_rf_lld.h"
#include "common_rf_types.h"
#include "common_rf_registers.h"
#ifdef RF_LLD_VALIDATION
#include "RLV_EnvParameters.h"
#endif //RF_LLD_VALIDATION
/* External variable ----------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
static void Init_Debug( void );
static void SystemPower_Config( void );
static void Device_Init( void );

/* Private variables---------- -------------------------------------------------*/


/* Private user code ---------------------------------------------------------*/
/**
  * @brief  Main function
  * @param  None
  * @retval 0
  */
int main()
{
  /* Initialize the sequencer */
  UTIL_SEQ_Init();
  
  /* Initialize the HAL drivers */
  HAL_Init();
  
  /* Initialize low power manager */
  UTIL_LPM_Init();
  
  /* Initialize the device */
  Device_Init( );
  
  /* Initialize the system */
  HOST_SYS_Init();

  /* Main loop */
  while (1U)
  {
    UTIL_SEQ_Run(UTIL_SEQ_DEFAULT);
  }
}

/**
  * @brief  Idle task.
  *         All the tasks are trigerred by an interrupt unless the openthread tasklets
  *         and the task used to generate random values.
  *         When, there is a tasklet pending, the process associated to the tasklet is
  *         automatically triggered (refer to  otTaskletsSignalPending).
  *         When the task idle is called, the system check if there are some random
  *         values to generate otherwise, it enter in low power mode.
  * @param  None
  * @retval None
  */

#define PATCH_LP_WAKEUP 1

void UTIL_SEQ_Idle( void )
{
  /* Note that WFI (i.e. SLEEP mode) is required for SF timer tests but STOP or OFF mode will be managed by low-power test it self */
#ifdef PATCH_LP_WAKEUP
    if (LL_PWR_IsActiveFlag_CRP())
    {
       /**
        * SLEEP mode is required
        */
       //LPM_EnterSleepMode();
       //HW_LPM_SleepMode(); This line was uncommented before porting (CARNAL)
       //LPM_ExitSleepMode();
       return;
    }
    
    #ifdef RF_LLD_VALIDATION
    if(RLV_Parameters_ptr->lowPowerEnabled)
    {
        UTIL_LPM_EnterLowPower();
    }
    #else  //RF_LLD_VALIDATION
        UTIL_LPM_EnterLowPower();
    #endif //RF_LLD_VALIDATION

#else

    #ifdef RF_LLD_VALIDATION
    if(RLV_Parameters_ptr->lowPowerEnabled)
    {
        UTIL_LPM_EnterLowPower();
    }
    #else  //RF_LLD_VALIDATION
        UTIL_LPM_EnterLowPower();
    #endif //RF_LLD_VALIDATION
#endif /* PATCH_LP_WAKEUP */
}

/**
  * @brief  This function is called by the sequencer each time an event
  *         is pending.
  *
  * @param  evt_waited_bm : Event pending.
  * @retval None
  */
void UTIL_SEQ_EvtIdle( uint32_t UTIL_SEQ_bm_t, uint32_t evt_waited_bm )
{
  switch(evt_waited_bm)
  {
    default :
      /* default case : schedule all tasks */
      UTIL_SEQ_Run( UTIL_SEQ_DEFAULT );
      break;
  }
}

/**
  * @brief  This function is used to configure the low power mode.
  *
  * @param  None
  * @retval None
  */
static void SystemPower_Config( void )
{
  /* Disable all wakeup interrupt on CPU2  except IPCC(37), HSEM(39), BLE(45), Thread(46), Debugger(48) */
  LL_C2_EXTI_DisableIT_0_31(~0U);
  LL_C2_EXTI_DisableIT_32_63( (~0U) & (~(LL_EXTI_LINE_37 | LL_EXTI_LINE_39 | LL_EXTI_LINE_45 | LL_EXTI_LINE_46 | LL_EXTI_LINE_48)) );
  
  /* Due to our system constraints, it is forbidden to enter in 'off mode'
   */
  UTIL_LPM_SetOffMode(1U << CFG_LPM_App_LldTests, UTIL_LPM_DISABLE);
  
  /* Due to our system constraints, it is forbidden to enter in stop mode.
   */
  UTIL_LPM_SetStopMode(1U << CFG_LPM_App_LldTests, UTIL_LPM_DISABLE);
}

static void Init_Debug( void )
{
  /* Hardware signals trace activation */
#ifdef DTB_CFG
  HW_GPIO_DtbOn( DTB_CFG );
#endif /* DTB_CFG */

  /***************** ENABLE DEBUGGER *************************************/
  // EXTI for debugger managed by CPU1
  //LL_EXTI_EnableIT_32_63(LL_EXTI_LINE_48);
  //LL_C2_EXTI_EnableIT_32_63(LL_EXTI_LINE_48);

  return;
}

static void Device_Init( void )
{
  /* Enable the Clock for the SRAM1 */
  LL_C2_AHB1_GRP1_EnableClock(RCC_C2AHB1ENR_SRAM1EN);

  /* Enable HSEM clock */
  //__HAL_RCC_C2HSEM_CLK_ENABLE( );

  /* Enable only used interrupt */
  LL_C2_SYSCFG_GRP1_DisableIT( ~0U );
  LL_C2_SYSCFG_GRP2_DisableIT( ~0U );
  //LL_C2_SYSCFG_GRP1_EnableIT( LL_C2_SYSCFG_GRP1_RNG | LL_C2_SYSCFG_GRP1_PKA | LL_C2_SYSCFG_GRP1_FLASH );

  SystemPower_Config( );

  Init_Debug();

  return;
}

/*************************************************************
 *
 * WRAP FUNCTIONS USED FOR SYSTICK MANAGEMENT
 *
 *************************************************************/

/**
 * This function must not use the SysTick Timer which is not used (the WEAK one from HAL must be over-writen).
 */
void HAL_Delay(__IO uint32_t Delay)
{
  us_delay(Delay*1000);
  return;
}

/**
 * @brief Declare here an empty function to over-write the default one as it declared as WEAK in HAL.
 * This is the way to avoid systick use.
 *
 * @param None
 */
HAL_StatusTypeDef HAL_InitTick( uint32_t TickPriority )
{
  return (HAL_OK);
}

