/*****************************************************************************
 * @file    general_config.h
 * @author  MCD Application Team
 * @version -
 * @date    -
 * @brief   This file contains definitions that can be changed to configure
 *          some modules of the STM32 firmware application.
 *****************************************************************************
 * @attention
 *
 * <h2><center>&copy; COPYRIGHT(c) 2018 STMicroelectronics</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of STMicroelectronics nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 */

#ifndef GENERAL_CONFIG_H__
#define GENERAL_CONFIG_H__

/* ------------------------------------------------------------------------- *
 *  WIRELESS FIRMWARE INFORMATION                                            *
 * ------------------------------------------------------------------------- */
/* Version : identification of the M0 FW
 */
#define CFG_FW_MAJOR_VERSION      (2)
#define CFG_FW_MINOR_VERSION      (0)
#define CFG_FW_SUBVERSION         (0)

#define CFG_FW_VERSION_TYPE       (0)
#define CFG_FW_BRANCH             (0)

/* Memory size : unused in LLD tests
 */
#define CFG_FLASH_SIZE            (0)
#define CFG_SRAM2A_SIZE           (0)
#define CFG_SRAM2B_SIZE           (0)

/*Stack Type */
#define CFG_FW_STACK_TYPE         INFO_STACK_TYPE_RLV

/* ------------------------------------------------------------------------- *
 * Traces(logging) configuration                                             *
 * ------------------------------------------------------------------------- */
#define CFG_LOG_LEVEL 1

/* ------------------------------------------------------------------------- *
 * HW configuration                                                      *
 * ------------------------------------------------------------------------- */

/* Offset of the error numbers reported by HW */
#define CFG_HW_ERROR_OFFSET                          0x1000

/* Low speed oscillator choice: 0=LSE 1=LSI2 */
#define CFG_HW_INIT_USE_LSI2                              1

/* ------------------------------------------------------------------------- *
 * HW_AES configuration                                                      *
 * ------------------------------------------------------------------------- */

/* Index of the AES H/W instance (1 or 2) used by M0 firmware */
#define CFG_HW_AES_INSTANCE                               2

/* ------------------------------------------------------------------------- *
 * HW_RNG configuration                                                      *
 * ------------------------------------------------------------------------- */

/* Index of the semaphore used to protect access to RNG */
#define CFG_HW_RNG_SEMID                                  0

/* Number of 32-bit random values stored in internal pool */
#define CFG_HW_RNG_POOL_SIZE                             16

/* ------------------------------------------------------------------------- *
 * HW_PKA configuration                                                      *
 * ------------------------------------------------------------------------- */

/* Index of the semaphore used to protect access to PKA */
#define CFG_HW_PKA_SEMID                                  1

/* ------------------------------------------------------------------------- *
 * HW_IPCC configuration                                                     *
 * ------------------------------------------------------------------------- */

/* Mode BLE only (0 or 1): if 1, use only channels 1 & 3 */
#if defined BLE_WB || defined THREAD_WB
#define CFG_HW_IPCC_BLE_ONLY                              0
#else
#define CFG_HW_IPCC_BLE_ONLY                              1
#endif

/* ------------------------------------------------------------------------- *
 * HW_UART configuration                                                     *
 * ------------------------------------------------------------------------- */

/* Enables the UART IOs and clock configuration when set to 1
   (otherwise, this configuration should be done on M4 side) */
#define CFG_HW_UART_IO_CONFIG                             1

/* Selects the UART: 0 = USART1, 1 = LPUART1 */
#define CFG_HW_UART_USE_LPUART                            0

/* Baudrate */
#define CFG_HW_UART_BAUDRATE                         921600

/* DMAMUX channel index used for UART (0..13) */
#define CFG_HW_UART_DMA_CHANNEL_IDX                       0

/* ------------------------------------------------------------------------- *
 * HW_GPIO configuration                                                     *
 * ------------------------------------------------------------------------- */

#define CFG_HW_GPIO_LPO_OUT                               1
#define CFG_HW_GPIO_MCO_OUT                               1

/* ------------------------------------------------------------------------- *
 * BAES configuration                                                        *
 * ------------------------------------------------------------------------- */

/* For cut 2, use of AES S/W implementation instead of H/W when set to 1 */
#define CFG_BAES_SW                                       0

/* ------------------------------------------------------------------------- *
 * TRACE configuration                                                       *
 * ------------------------------------------------------------------------- */

/* Total trace buffer size in bytes */
#define CFG_TRACE_BUF_SIZE                             2048

/* ------------------------------------------------------------------------- *
 * NVM configuration                                                         *
 * ------------------------------------------------------------------------- */

/**
 * Do not enable ALIGN mode
 * Used only by BLE Test Fw
 */
#define CFG_NVM_ALIGN                             (0)

#define  INTERMEDIATE_STORAGE_BUF_SIZE            (4096 - 32)  //Should be equal to TMP_STORAGE_BUF_SIZE

/* Enables the RAM emulation when set to 1 */
#define CFG_NVM_EMUL                                      1

  /**
   * This is the max size of data the BLE Stack needs to write in NVM
   * This is different to the size allocated in the EEPROM emulator
   * The BLE Stack shall write all data at an address in the range of [0 : (x-1)]
   * The size is a number of 32bits values
   * NOTE:
   * THIS VALUE SHALL BE IN LINE WITH THE BLOCK DEFINE IN THE SCATTER FILE BLOCK_STACKLIB_FLASH_DATA
   * There are 8x32bits = 32 Bytes header in the EEPROM for each sector.
   * a page is a collection of 1 or more sectors
   */
#define CFG_NVM_BLE_MAX_SIZE                           ((4096 - 32 - 4)/2/4)

  /**
   * This is the max size of data the THREAD Stack needs to write in NVM
   * This is different to the size allocated in the EEPROM emulator
   * The THREAD Stack shall write all data at an address in the range of [0 : (y-1)]
   * The size is a number of 32bits values
   */
#define CFG_NVMA_THREAD_NVM_SIZE               ( INTERMEDIATE_STORAGE_BUF_SIZE/4 )

  /**
   * This is the offset from the vector table where the NVM has been located
   * it shall be identical to the value set for __NVM_OFFSET__ in the scatter file
   */
#define CFG_NVM_BASE_ADDRESS                    ( 0x1000 )
/* ------------------------------------------------------------------------- *
 * EE configuration                                                         *
 * ------------------------------------------------------------------------- */

/* Size of the first bank in bytes (must be greater than 0).
   It must be a multiple of twice the page size. */
#define CFG_EE_BANK0_SIZE          (10 * HW_FLASH_PAGE_SIZE)

/* Maximum number of 32-bit data that can be stored in the first bank. */
#define CFG_EE_BANK0_MAX_NB        (CFG_NVM_BLE_MAX_SIZE + CFG_NVMA_THREAD_NVM_SIZE)

/* Size of the second bank in bytes (can be 0 if the bank is not used).
   It must be a multiple of twice the page size. */
#define CFG_EE_BANK1_SIZE          ( 0 )

/* Maximum number of 32-bit data that can be stored in the second bank. */
#define CFG_EE_BANK1_MAX_NB                             224

/* -------------------------------- *
 *  Compiler                         *
 * -------------------------------- */
#define PLACE_IN_SECTION( __x__ )  __attribute__((section (__x__)))

#endif /* ! GENERAL_CONFIG_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE***/


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE***/
