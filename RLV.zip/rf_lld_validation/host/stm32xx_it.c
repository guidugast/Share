/**
 ******************************************************************************
 * @file    stm32xx_it.c
 * @author  MCD Application Team
 * @brief   Main Interrupt Service Routines.
 *          This file provides template for all exceptions handler and
 *          peripherals interrupt service routine.
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; COPYRIGHT(c) 2017 STMicroelectronics</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *      may be used to endorse or promote products derived from this software
 *      without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "common.h"
#include "stm32_seq.h"
#include "common_rf_types.h"
#include "common_rf_lld.h"
#include "radio_lld.h"
#ifdef USE_PROTOCOL_802154
#include "ip802154_lld.h"
#else
#include "hal_BLE.h"
#endif
#include "dbg_gpio.h"
#include "gpio_lld.h"
#include "stm32xx_it.h"

/* External variables  -------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/


__irq void TSC_802_0_IRQHandler( void )
{
#ifdef USE_PROTOCOL_802154
  ip802154_lld_isr_0();
#endif
}

#ifdef STM32WB35xx
__irq void _802_1_IRQHandler( void )
#else
__irq void LCD_802_1_IRQHandler( void )
#endif
{
#ifdef USE_PROTOCOL_802154
  ip802154_lld_isr_1();
#endif
}

__irq void _802_2_HOST_WKUP_IRQHandler( void )
{
#ifdef USE_PROTOCOL_802154
  ip802154_lld_isr_WU();
  ip802154_lld_isr_2();
#endif
}

__irq void BLE_IRQHandler( void )
{
  radio_lld_irq_handler();
#if (defined USE_PROTOCOL_BLE) || (defined USE_PROTOCOL_ANT)
  //ipBLE_lld_IRQHandler(); // ipBLE_lld.c 
  LLD_BLE_IRQHandler();
#endif
}

/**
 * @brief  This function handles NMI exception.
 * @param  None
 * @retval None
 */
void NMI_Handler(void)
{
}

/**
 * @brief  This function handles Hard Fault exception.
 * @param  None
 * @retval None
 */
void HardFault_Handler( void )
{
  __ASM(  "MOVS   R0, #4  \n"
      "MOV    R1, LR  \n"
      "TST    R0, R1  \n"
      "BEQ    _MSP    \n"
      "MRS    R0, PSP \n"
      "B      HardFault_Handler_c      \n"
      "_MSP:  \n"
      "MRS    R0, MSP \n"
      "B      HardFault_Handler_c      \n" ) ;
}

void SysTick_Handler(void)
{
  /* The SysTick should never be called ! */
  while(1 == 1);
}
/**
 * @brief  This function handles SVCall exception.
 * @param  None
 * @retval None
 */
void SVC_Handler(void)
{
}

/**
 * @brief  This function handles PendSVC exception.
 * @param  None
 * @retval None
 */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles IPCC RX occupied global interrupt request.
  * @param  None
  * @retval None
  */
void IPCC_C2_RX_C2_TX_HSEM_IRQHandler( void )
{
  DBG_GPIO_Gr1Set( DBG_GPIO_GR1_IPCC_GENERAL );

  /* IPCC handler */
  HW_IPCC_Handler();

  /* HSEM handler */
  if(LL_HSEM_IsActiveFlag_C2MISR(HSEM, 1<<CFG_HW_FLASH_SEMID) != 0)
  {
    /**
     * Disable the interrupt
     */
    LL_HSEM_DisableIT_C2IER(HSEM, 1<<CFG_HW_FLASH_SEMID);
    LL_HSEM_ClearFlag_C2ICR(HSEM, 1<<CFG_HW_FLASH_SEMID);
    UTIL_SEQ_SetTask(1<<CFG__NVMProcess , CFG_SEQ_Prio_0);
  }
  else if(LL_HSEM_IsActiveFlag_C2MISR(HSEM, 1<<CFG_HW_BLOCK_FLASH_REQ_BY_CPU1_SEMID) != 0)
  {
    /**
     * Disable the interrupt
     */
    LL_HSEM_DisableIT_C2IER(HSEM, 1<<CFG_HW_BLOCK_FLASH_REQ_BY_CPU1_SEMID);
    LL_HSEM_ClearFlag_C2ICR(HSEM, 1<<CFG_HW_BLOCK_FLASH_REQ_BY_CPU1_SEMID);
    UTIL_SEQ_SetEvt(1<<CFG_IDLEEVT_FLASH_ACTIVITY_ALLOWED_BY_CPU1);
  }

  DBG_GPIO_Gr1Reset( DBG_GPIO_GR1_IPCC_GENERAL );

  return;
}

/**
 * @brief
 * C implementation of hard fault handler, to retrieve register values
 */
void HardFault_Handler_c( uint32_t *pulFaultStackAddress )
{
#if 0
  /* These are volatile to try and prevent the compiler/linker optimising them
    away as the variables never actually get used.  If the debugger won't show the
    values of the variables, make them global my moving their declaration outside
    of this function. */
  volatile uint32_t r0;
  volatile uint32_t r1;
  volatile uint32_t r2;
  volatile uint32_t r3;
  volatile uint32_t r12;
  volatile uint32_t lr; /* Link register. */
  volatile uint32_t pc; /* Program counter. */
  volatile uint32_t psr;/* Program status register. */

  r0 = pulFaultStackAddress[ 0 ];
  r1 = pulFaultStackAddress[ 1 ];
  r2 = pulFaultStackAddress[ 2 ];
  r3 = pulFaultStackAddress[ 3 ];

  r12 = pulFaultStackAddress[ 4 ];
  lr = pulFaultStackAddress[ 5 ];
  pc = pulFaultStackAddress[ 6 ];
  psr = pulFaultStackAddress[ 7 ];
#endif

  /**
   * Do not store in non secure SRAM ARM registers that may content secret
   */
  *(uint32_t*)(SRAM2A_BASE) = WB_HARD_FAULT_KEYWORD;
  *(uint32_t*)(SRAM2A_BASE+4) = pulFaultStackAddress[ 6 ];    /* pc - Hold the instruction that generated the hardfault */
  *(uint32_t*)(SRAM2A_BASE+8) = pulFaultStackAddress[ 5 ];    /* lr - Hold the lr value when the instruction that generated the hardfault has been executed*/
  *(uint32_t*)(SRAM2A_BASE+12) = (uint32_t)pulFaultStackAddress + 0x20;  /* sp - Hold the sp value when the instruction that generated the hardfault has been executed*/

  /* When the following line is hit, the variables contain the register values. */
#if !(CFG_DBG_IDLE != 0)
  DBG_GPIO_GR1_SET( DBG_GPIO_GR1_HARD_FAULT );
#endif
  gpio_lld_phy_gpioHardFault_up();

  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
