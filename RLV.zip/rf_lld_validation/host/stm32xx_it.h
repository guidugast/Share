/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32wbxx_it.h
  * @author  MCD Application Team
  * @brief   This file contains the headers of the interrupt handlers.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license 
  * SLA0044, the "License"; You may not use this file except in compliance with 
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32xx_IT_H
#define __STM32xx_IT_H

#ifdef __cplusplus
 extern "C" {
#endif 

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
__irq void TSC_802_0_IRQHandler(void);
#ifdef STM32WB35xx
__irq void _802_1_IRQHandler(void);
#else
__irq void LCD_802_1_IRQHandler(void);
#endif
__irq void _802_2_HOST_WKUP_IRQHandler(void);
__irq void BLE_IRQHandler(void);
void RCC_FLASH_C1SEV_IRQHandler(void);
void NMI_Handler(void);
void HardFault_Handler(void);
void SysTick_Handler(void);
void SVC_Handler(void);
void PendSV_Handler(void);
void IPCC_C2_RX_C2_TX_HSEM_IRQHandler(void);
void HardFault_Handler_c(uint32_t *pulFaultStackAddress);

#ifdef __cplusplus
}
#endif

#endif /* __STM32xx_IT_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
