/*
 *  Copyright (c) 2016, The OpenThread Authors.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of the copyright holder nor the
 *     names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * @brief
 *   This file includes the platform abstraction for the debug log service.
 */

#ifndef LLD_TESSTS_LOGGING_H_
#define LLD_TESSTS_LOGGING_H_

#include <stdarg.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup plat-logging
 *
 * @brief
 *   This module includes the platform abstraction for the debug log service.
 *
 * @{
 *
 */

/**
 * Log level None.
 *
 * @note Log Levels are defines so that embedded implementations can eliminate code at compile time via
 * #if/#else/#endif.
 *
 */
#define LT_LOG_LEVEL_NONE 0

/**
 * Log level Critical.
 *
 * @note Log Levels are defines so that embedded implementations can eliminate code at compile time via
 * #if/#else/#endif.
 *
 */
#define LT_LOG_LEVEL_CRIT 1

/**
 * Log level Warning.
 *
 * @note Log Levels are defines so that embedded implementations can eliminate code at compile time via
 * #if/#else/#endif.
 *
 */
#define LT_LOG_LEVEL_WARN 2

/**
 * Log level Notice.
 *
 * @note Log Levels are defines so that embedded implementations can eliminate code at compile time via
 * #if/#else/#endif.
 *
 */
#define LT_LOG_LEVEL_NOTE 3

/**
 * Log level Informational.
 *
 * @note Log Levels are defines so that embedded implementations can eliminate code at compile time via
 * #if/#else/#endif.
 *
 */
#define LT_LOG_LEVEL_INFO 4

/**
 * Log level Debug.
 *
 * @note Log Levels are defines so that embedded implementations can eliminate code at compile time via
 * #if/#else/#endif.
 *
 */
#define LT_LOG_LEVEL_DEBG 5

/**
 * This type represents the log level.
 *
 */
typedef uint8_t ltLogLevel;

/**
 * This enumeration represents log regions.
 *
 */
typedef enum ltLogRegion {
    LT_LOG_REGION_M0         = 1, // M0 system traces
    LT_LOG_REGION_TEST       = 2, // Traces in in tests functions
    LT_LOG_REGION_DRIVER     = 3, // RF drivers
} ltLogRegion;

#define ltPlatLogSys(...) ltPlatLog(LT_LOG_LEVEL_NONE, LT_LOG_REGION_M0, __VA_ARGS__)
#define ltPlatLogTest(...) ltPlatLog(LT_LOG_LEVEL_NONE, LT_LOG_REGION_TEST, __VA_ARGS__)
#define ltPlatLogDriver(...) ltPlatLog(LT_LOG_LEVEL_NONE, LT_LOG_REGION_DRIVER, __VA_ARGS__)

/**
 * @brief Trace/Log functions to be used to send traces or logs for debug purposes to debug trace UART
 *        (a \r\n will be added at the end before sending)
 * 
 * @param(s) 3 kind of input parameter(s) is proposed here (last one is to be used by RF LLDs)
 */
void ltPlatLog(ltLogLevel aLogLevel, ltLogRegion aLogRegion, const char *aFormat, ...);
void ltPlatTrace(ltLogLevel aLogLevel, ltLogRegion aLogRegion, const char * Str, uint16_t Size);
// Not possible to use macro in driver as we need to use a function pointer to the RF drivers
void ltPlatTraceDriver(const char* format, ...);

/**
 * @brief Printf function to be used to send data to print on CLI command UART
 *        (a \r\n will be added at the end before sending)
 * 
 * @param(s) use standart printf formating
 */
void ltPlatUartPrintf(const char* format, ...);

/**
 * @}
 *
 */

#ifdef __cplusplus
} // extern "C"
#endif

#endif // OPENTHREAD_PLATFORM_LOGGING_H_
