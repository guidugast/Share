/**
 ******************************************************************************
  * File Name          : hw_conf.h
  * Description        : Hardware configuration file for the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef HW_CONF_H
#define HW_CONF_H

/******************************************************************************
 * HW UART
 *****************************************************************************/
/* if CFG_TRACE_M0_TO_M4_ENABLED is set to 1, USUART setup must be done on M4 side */
#define CFG_TRACE_M0_TO_M4_ENABLED              1


#endif /*HW_CONF_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
