/**
 ******************************************************************************
  * File Name          : app_conf.h
  * Description        : Application configuration file for STM32WPAN Middleware.
  *
 ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef APP_CONF_H
#define APP_CONF_H

#include "common.h"
#include "common_rf_lld.h"
#include "stm32wbxx_ll_pwr.h"

/******************************************************************************
 * Low power manager
 ******************************************************************************/
typedef enum {
  LPM_NO_STOP   = 0xFF,
  LPM_STOP_0    = LL_PWR_MODE_STOP0,
  LPM_STOP_1    = LL_PWR_MODE_STOP1,
  LPM_STOP_2    = LL_PWR_MODE_STOP2,
  LPM_STAND_BY  = LL_PWR_MODE_STANDBY,
  LPM_SHUT_DOWN = LL_PWR_MODE_SHUTDOWN
} LPM_lowPower_mode_t;

extern LPM_lowPower_mode_t M0_LPM_mode;

#endif /*APP_CONF_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
