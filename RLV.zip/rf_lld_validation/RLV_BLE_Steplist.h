/**
  ******************************************************************************
  * @file    TODO.h
  * @author  MCD Application Team
  * @brief   HeTODO.c module
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_BLE_STEPLIST_H_
#define RLV_BLE_STEPLIST_H_

#include "RLV_TestFramework.h"
////////////////////////////////////////////////////////////////////////////////
//////////////////              List steps here               //////////////////
////////////////////////////////////////////////////////////////////////////////

extern void BLE_Step__LldBleInit(void);
extern void BLE_Step__HalBleInit(void);
extern void BLE_Step__SetNetworkId(void);
extern void BLE_Step__SendOnePacket_HAL(void);
extern void BLE_Step__ReceiveOnePacket_HAL(void);
extern void BLE_Step__TxStress_HAL(void);
extern void BLE_Step__RxStress_HAL(void);
extern void BLE_Step__PingPongStress_HAL(void);
extern void BLE_Step__SendOneSimplePacket(void);
extern void BLE_Step__ReceiveOneSimplePacket(void);
extern void RLV_Step__DoWithTimeout(void);
extern void BLE_Step__TimerTest(void);
extern void BLE_Step__GetStatus(void);
extern void BLE_Step__StartTone(void);
extern void BLE_Step__StopTone(void);
extern void BLE_Step__StopActivity(void);
extern void BLE_Step__EncryptPlainData(void);
extern void BLE_Step__BuildActionPacketChainFromBuffer(void);
extern void BLE_Step__BuildCurrentActionPacketInBuffer(void);
extern void BLE_Step__BuildStateMachine(void);
extern void BLE_Step__RunActionPacketChain(void);
extern void BLE_Step__RunApChainAndWaitForItToFinish(void);
extern void BLE_Step__CompareReceivedPacket(void);
extern void BLE_Step__ShowStressResults(void);
#endif // RLV_BLE_STEPLIST_H_
#endif // RF_LLD_VALIDATION

