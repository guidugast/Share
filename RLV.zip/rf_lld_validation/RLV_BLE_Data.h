/*******************************************************************************
* @file    TODO.c
* @author  MCD Application Team
* @brief   TODO
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the 
* License. You may obtain a copy of the License at:
*                        opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*/
  
#if defined(RF_LLD_VALIDATION)
#ifndef RLV_BLE_DATA_H_
#define RLV_BLE_DATA_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#ifdef USE_PROTOCOL_802154
  #include "ip802154_lld.h"
  #include "ip802154_lld_priv.h"
  #include "ip802154_lld_registers.h"
  #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
  #include "ipBLE_lld.h"
  #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE

#include "RLV_BLE_Commandlist.h"
#include "RLV_Logger.h"
#include "RLV_BLE_Types.h"
#include "RLV_TestFramework.h"


////////////////////////////////////////////////////////////////////////////////
//////////////////                  Lists                     //////////////////
////////////////////////////////////////////////////////////////////////////////
#define LIST_BLE_param(X) \
    LIST_BLE_param__test_application_parameters(X) \
    LIST_BLE_param__test_application_counters(X) \
    LIST_BLE_param__ble_init(X) \
    LIST_BLE_param__connexion(X) \
    LIST_BLE_param__action_packet_storage(X) \
    LIST_BLE_param__action_packet(X) \
    LIST_BLE_param__hal_action_packet(X) \
    LIST_BLE_param__hal_first_packet_to_send(X) \
    LIST_BLE_param__hal_packet_to_send_as_a_reply(X) \
    LIST_BLE_param__hal_first_packet_to_receive(X) \
    LIST_BLE_param__hal_packet_to_receive_as_a_reply(X) \
    LIST_BLE_param__tx_attributes(X) \
    LIST_BLE_param__tx_rx_phy(X) \
    LIST_BLE_param__encryption(X) \
    LIST_BLE_param__action_packet_action_tag(X) \
    LIST_BLE_param__blocking_commands_helpers(X)\
    //end of list

#define LIST_BLE_param__test_application_parameters(X) \
    X(bool,                 crystalCheckEnabled,                RLV_BLE_DEFAULT_CRYSTAL_CHECK) \
    X(bool,                 withAck,                            RLV_BLE_DEFAULT_ACK) \
    X(bool,                 showRssi,                           false) \
    X(uint32_t,             stressDurationInS,                  RLV_BLE_DEFAULT_STRESS_DURATION) \
    X(uint32_t,             rxStressDeltaBlockingDelayInUs,     RLV_BLE_DEFAULT_DELTA_BLOCKING_DELAY) \
    X(uint32_t,             txStressDeltaBlockingDelayInUs,     RLV_BLE_DEFAULT_DELTA_BLOCKING_DELAY) \
    X(uint32_t,             txFirstInPingPong,                  RLV_BLE_DEFAULT_TX_FIRST_IN_PINGPONG) \
    X(uint32_t,             requestTimeoutInS,                  RLV_BLE_DEFAULT_REQUEST_TIMEOUT) \
    //end of list
      
#define LIST_BLE_param__test_application_counters(X) \
    X(bool,                 shouldTxNotRx,                      false) \
    X(uint32_t,             rxCounter,                          0) \
    X(uint32_t,             rxSuccessCounter,                   0) \
    X(uint32_t,             rxCrcErrorCounter,                  0) \
    X(uint32_t,             rxTimeoutErrorCounter,              0) \
    X(uint32_t,             rxUnkownErrorCounter,               0) \
    X(uint32_t,             txSuccessCounter,                   0) \
    //end of list

#define LIST_BLE_param__ble_init(X) \
    X(uint16_t,             hsStartupTime,                      RLV_BLE_DEFAULT_STARTUP_TIME) \
    X(uint8_t,              lowSpeedOsc,                        RLV_BLE_DEFAULT_LOW_SPEED_OSC) \
    X(FunctionalState_t,    whitening,                          RLV_BLE_DEFAULT_WHITENING_ENABLED) \
    X(array_uint32_t,       hotAnaTable,                        RLV_BLE_DEFAULT_HOT_ANA_TABLE) \
    //end of list

#define LIST_BLE_param__connexion(X) \
    X(uint32_t,             networkId,                          RLV_BLE_DEFAULT_NETWORK_ID) \
    X(array_uint8_t,        channelMap,                         RLV_BLE_DEFAULT_CHANNEL_MAP) \
    X(uint8_t,              channelIncrement,                   RLV_BLE_DEFAULT_CHANNEL_INCREMENT) \
    X(uint32_t,             backToBackTime,                     RLV_BLE_DEFAULT_B2B_TIME) \
    X(uint8_t,              txPower,                            RLV_BLE_DEFAULT_TX_POWER) \
    //end of list

#define LIST_BLE_param__action_packet_storage(X) \
    X(uint8_t,              apCurrentStorageIndex,              1) \
    X(uint8_t,              apNextIfTrueStorageIndex,           0) \
    X(uint8_t,              apNextIfFalseStorageIndex,          0) \
    //end of list

#define LIST_BLE_param__action_packet(X) \
    X(uint8_t,              apStateMachineId,                   RLV_BLE_DEFAULT_STATE_MACHINE_ID) \
    X(actionPacket_e_t,     apCurrentType,                      RLV_BLE_DEFAULT_AP_CURRENT) \
    X(apCondRoutine_e_t,    apCondRoutineType,                  RLV_BLE_DEFAULT_COND_ROUTINE) \
    X(apDataRoutine_e_t,    apDataRoutineType,                  RLV_BLE_DEFAULT_DATA_ROUTINE) \
    //end of list

#define LIST_BLE_param__hal_action_packet(X) \
    X(uint8_t,              channel,                            RLV_BLE_DEFAULT_CHANNEL) \
    X(uint32_t,             wakeupTime,                         RLV_BLE_DEFAULT_WAKEUPTIME) \
    //end of list
        
#define LIST_BLE_param__hal_first_packet_to_send(X) \
    X(uint8_t,              txHeader,                           RLV_BLE_DEFAULT_HEADER) \
    X(array_uint8_t,        txPayload,                          RLV_BLE_DEFAULT_PACKET_PAYLOAD) \
    X(apDataRoutine_e_t,    txDataRoutineId,                    RLV_BLE_DEFAULT_DATA_ROUTINE) \
    X(apCondRoutine_e_t,    txCondRoutineId,                    RLV_BLE_DEFAULT_COND_ROUTINE) \
    //end of list
        
#define LIST_BLE_param__hal_packet_to_send_as_a_reply(X) \
    X(uint32_t,             txAckReceiveWindow,                 RLV_BLE_DEFAULT_WINDOW) \
    X(uint8_t,              txAckExpectedHeader,                RLV_BLE_DEFAULT_HEADER) \
    X(array_uint8_t,        txAckExpectedPayload,               RLV_BLE_DEFAULT_PACKET_PAYLOAD) \
    //end of list 

#define LIST_BLE_param__hal_first_packet_to_receive(X) \
    X(uint32_t,             rxReceiveWindow,                    RLV_BLE_DEFAULT_WINDOW) \
    X(uint8_t,              rxExpectedHeader,                   RLV_BLE_DEFAULT_HEADER) \
    X(array_uint8_t,        rxExpectedPayload,                  RLV_BLE_DEFAULT_PACKET_PAYLOAD) \
    X(apDataRoutine_e_t,    rxDataRoutineId,                    RLV_BLE_DEFAULT_DATA_ROUTINE) \
    //end of list
 
#define LIST_BLE_param__hal_packet_to_receive_as_a_reply(X) \
    X(uint8_t,              rxAckHeader,                        RLV_BLE_DEFAULT_HEADER) \
    X(array_uint8_t,        rxAckPayload,                       RLV_BLE_DEFAULT_PACKET_PAYLOAD) \
    //end of list

#define LIST_BLE_param__tx_attributes(X) \
    X(uint32_t,             crcInit,                            RLV_BLE_DEFAULT_CRC_INIT) \
    X(uint32_t,             sca,                                RLV_BLE_DEFAULT_SCA) \
    //end of list

#define LIST_BLE_param__tx_rx_phy(X) \
    X(uint32_t,             rxPhy,                              RLV_BLE_DEFAULT_RX_PHY) \
    X(uint32_t,             txPhy,                              RLV_BLE_DEFAULT_TX_PHY) \
    //end of list

#define LIST_BLE_param__encryption(X) \
    X(FunctionalState_t,    encryptStatus,                      RLV_BLE_DEFAULT_ENCRYPT_STATUS_AND_FLAG) \
    X(array_uint8_t,        encryptRxCounter,                   RLV_BLE_DEFAULT_ENCRYPT_COUNTER_ARRAY) \
    X(array_uint8_t,        encryptTxCounter,                   RLV_BLE_DEFAULT_ENCRYPT_COUNTER_ARRAY) \
    X(array_uint8_t,        encryptInitVector,                  RLV_BLE_DEFAULT_ENCRYPT_INIT_VECTOR) \
    X(array_uint8_t,        encryptKey,                         RLV_BLE_DEFAULT_ENCRYPT_KEY) \
    X(array_uint8_t,        encryptPlainData,                   RLV_BLE_DEFAULT_ENCRYPT_PLAIN_DATA) \
    X(array_uint8_t,        encryptExpectedData,                RLV_BLE_DEFAULT_ENCRYPT_EXPECTED_DATA) \
    //end of list

#define LIST_BLE_param__action_packet_action_tag(X) \
    X(bool,                 radioFrequencyCalibrationEnabled,   RLV_BLE_DEFAULT_AT_PLL_TRIG) \
    X(bool,                 actionIsTxNotRx,                    RLV_BLE_DEFAULT_AT_TXRX) \
    X(bool,                 timerWakeupBasedOnWakeupTimeNotB2B, RLV_BLE_DEFAULT_AT_TIMER_WAKEUP) \
    X(bool,                 nsEn,                               RLV_BLE_DEFAULT_AT_NS_EN) \
    X(bool,                 channelAutoIncrementEnabled,        RLV_BLE_DEFAULT_AT_INC_CHAN) \
    X(bool,                 wakeupTimeIsRelativeNotAbsolute,    RLV_BLE_DEFAULT_AT_RELATIVE) \
    X(bool,                 timestampFromPacketStartNotEnd,     RLV_BLE_DEFAULT_AT_TIMESTAMP_POSITION) \
    //end of list
      
#define LIST_BLE_param__blocking_commands_helpers(X) \
    X(bool,                 isGetStatusWhileBlockingCommandEnabled,         false) \
    X(bool,                 isStopToneWhileBlockingCommandEnabled,          false) \
    X(bool,                 isStopActivityWhileBlockingCommandEnabled,      false) \
    X(uint32_t,             delayBeforeCallingFlashCommand,                 0) \
    //end of list

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Defines                    //////////////////
////////////////////////////////////////////////////////////////////////////////
///SIZES
#define MAX_CHANNEL_NUMBER                        40
#define ENCRYPTION_DATA_SIZE                      16
#define RLV_MAX_PACKET_SIZE                       (255+2)
                                                  
//DEFAULT PARAM VALUE                             
#define RLV_BLE_DEFAULT_CRYSTAL_CHECK             true
#define RLV_BLE_DEFAULT_ACK                       false
#define RLV_BLE_DEFAULT_STRESS_DURATION           60//in s
#define RLV_BLE_DEFAULT_DELTA_BLOCKING_DELAY      0//in us
#define RLV_BLE_DEFAULT_TX_FIRST_IN_PINGPONG      false
#define RLV_BLE_DEFAULT_STARTUP_TIME              0x001A  //(64 us)
#define RLV_BLE_DEFAULT_LOW_SPEED_OSC             1
#define RLV_BLE_DEFAULT_WHITENING_ENABLED         {ENABLE}
#define RLV_BLE_DEFAULT_HOT_ANA_TABLE             {15,{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
#define RLV_BLE_DEFAULT_NETWORK_ID                0x5A964129
#define RLV_BLE_DEFAULT_WAKEUPTIME                4000 //In us
#define RLV_BLE_DEFAULT_HEADER                    0x95
#define RLV_BLE_DEFAULT_PACKET_PAYLOAD            {8,{0x54,0x45,0x53,0x54,0x5f,0x42,0x4c,0x45}}//{'T','E','S','T','_','B','L','E'}
#define RLV_BLE_DEFAULT_STATE_MACHINE_ID          0
#define RLV_BLE_DEFAULT_CHANNEL                   22//channel 22 is the one that has less interferences due to WiFi 
#define RLV_BLE_DEFAULT_CHANNEL_MAP               {5,{0xFF,0xFF,0xFF,0xFF,0xFF}}
#define RLV_BLE_DEFAULT_CHANNEL_INCREMENT         1
#define RLV_BLE_DEFAULT_WINDOW                    4000000//In us
#define RLV_BLE_DEFAULT_AP_CURRENT                {AP_TXRX}
#define RLV_BLE_DEFAULT_AP_NEXT_TRUE              {AP_END}
#define RLV_BLE_DEFAULT_AP_NEXT_FALSE             {AP_END}
#define RLV_BLE_DEFAULT_DATA_ROUTINE              {APDR_SIMPLE_RET_TRUE}
#define RLV_BLE_DEFAULT_COND_ROUTINE              {APCR_SIMPLE_RET_TRUE}
#define RLV_BLE_DEFAULT_B2B_TIME                  10000 // or use BACK2BACK_TIME
#define RLV_BLE_DEFAULT_TX_POWER                  7
#define RLV_BLE_DEFAULT_AT_PLL_TRIG               true  // Radio frequency calibration (0:  disabled.1: enabled). User should set this bit only if TIMER_WAKEUP is set to 1.
#define RLV_BLE_DEFAULT_AT_TXRX                   true  // Action (1: TX,  0: RX)
#define RLV_BLE_DEFAULT_AT_TIMER_WAKEUP           true  // Based on the(0:back-to-back time (default 150 �s), 1: WakeupTime)
#define RLV_BLE_DEFAULT_AT_NS_EN                  false // Enables SN/NESN, see hw spec �12.1 and �10.7
#define RLV_BLE_DEFAULT_AT_INC_CHAN               false // Increment (0: no, 1 : auto)
#define RLV_BLE_DEFAULT_AT_RELATIVE               true  // WakeupTime field time (0:absolute, 1: relative to current time)
#define RLV_BLE_DEFAULT_AT_TIMESTAMP_POSITION     false // position where timestamp is taken relative to packet(0: end, 1:start). RX only
#define RLV_BLE_DEFAULT_CRC_INIT                  0x555555//TODO: answer "why 0x555555?"
#define RLV_BLE_DEFAULT_SCA                       0//TODO: use SCA_DEFAULTVALUE?
#define RLV_BLE_DEFAULT_TX_PHY                    TX_PHY_2MBPS
#define RLV_BLE_DEFAULT_RX_PHY                    RX_PHY_2MBPS
#define RLV_BLE_DEFAULT_ENCRYPT_STATUS_AND_FLAG   {DISABLE}
#define RLV_BLE_DEFAULT_ENCRYPT_COUNTER_ARRAY     {5,{0,0,0,0,0}}
#define RLV_BLE_DEFAULT_ENCRYPT_INIT_VECTOR       {8,{0,0,0,0,0,0,0,0}}
#define RLV_BLE_DEFAULT_ENCRYPT_KEY               {16,{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0xFF,0xFF}}
#define RLV_BLE_DEFAULT_ENCRYPT_PLAIN_DATA        {16,{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
#define RLV_BLE_DEFAULT_ENCRYPT_EXPECTED_DATA     {16,{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
#define RLV_BLE_DEFAULT_REQUEST_TIMEOUT           10// In s
                                                  
//RETURN CODES                                    
#define RLV_ACTION_PACKET_RETURN_VALUE_SUCCESS    TRUE
                                                  
//BLE Specific                                    
#define RLV_HEADER_SN_BIT_MASK                    0x10
#define RLV_HEADER_NESN_BIT_MASK                  0x20

////////////////////////////////////////////////////////////////////////////////
//////////////////                Public functions            //////////////////
////////////////////////////////////////////////////////////////////////////////
extern void                 RLV_BLE_InitData(void);
extern void                 RLV_BLE_PrintTestEnvParameters(void);
extern void                 RLV_BLE_ResetBuffersAndCounters(void);

extern uint32_t             RLV_BLE_GetActionTag(void);
extern void                 RLV_BLE_FillPacket(uint8_t * array,uint8_t header,uint8_t length,uint8_t * payload);
extern bool                 RLV_BLE_ExpectPacketsEqual(bool precondition, uint8_t * array,uint8_t header,uint8_t length,uint8_t * payload, bool show);

extern int32_t              RLV_BLE_GetLastRssiInDbm(void);
extern void                 RLV_BLE_UpdateRssiInDbm(int32_t lastRssi);
      
extern uint8_t*             RLV_BLE_GetRxPacketBuffer(uint8_t currentApIndex);
extern uint8_t              RLV_BLE_GetExpectedHeader(uint8_t currentApIndex);
extern uint8_t              RLV_BLE_GetExpectedLength(uint8_t currentApIndex);
extern uint8_t*             RLV_BLE_GetExpectedPayload(uint8_t currentApIndex);
extern void                 RLV_BLE_SetDataRoutine(uint8_t currentApIndex, apDataRoutine_e_t id);
extern apDataRoutine_t      RLV_BLE_GetDataRoutine(uint8_t currentApIndex);
extern void                 RLV_BLE_SetCondRoutine(uint8_t currentApIndex, apCondRoutine_e_t id);
extern apCondRoutine_t      RLV_BLE_GetCondRoutine(uint8_t currentApIndex);
extern void                 RLV_BLE_SetNextIfTrueActionPacketIndex(uint8_t currentApIndex, uint8_t nextIfTrueApIndex);
extern ActionPacket*        RLV_BLE_GetNextIfTrueActionPacket(uint8_t currentApIndex);
extern void                 RLV_BLE_SetNextIfFalseActionPacketIndex(uint8_t currentApIndex, uint8_t nextIfFalseApIndex);
extern ActionPacket*        RLV_BLE_GetNextIfFalseActionPacket(uint8_t currentApIndex);
extern void                 RLV_BLE_SetCurrentActionPacketType(uint8_t currentApIndex, actionPacket_e_t id);
extern void                 RLV_BLE_SetNextActionPacketPointers(uint8_t currentApIndex);
extern void                 RLV_BLE_BuildCurrentActionPacket(uint8_t currentApIndex);
extern ActionPacket*        RLV_BLE_GetActionPacket(uint8_t index);


////////////////////////////////////////////////////////////////////////////////
//////////////////                Print generation            //////////////////
////////////////////////////////////////////////////////////////////////////////
static inline void print_FunctionalState_t(FunctionalState_t* val, char * dummy)
{
    (void)dummy; \
    RLV_APPEND_LOG(" = ");
    switch(val->value)
    {
        case ENABLE: RLV_APPEND_LOG("ENABLE"); break;
        case DISABLE: RLV_APPEND_LOG("DISABLE"); break;
        default: RLV_LOG_ERROR("unknown value for FunctionalState"); break;
    }
}

#define DEF_print_enum(enum_val) \
case enum_val: RLV_APPEND_LOG(#enum_val); break;
#define DEF_print_x_e(enum_type) \
static inline void print_##enum_type##_t(enum_type##_t* val, char * dummy) \
{ \
    (void)dummy; \
    RLV_APPEND_LOG(" = "); \
    switch(val->value) \
    { \
         LIST_##enum_type(DEF_print_enum) \
         default: RLV_LOG_ERROR("unknown value for "#enum_type"_t"); break; \
    } \
    RLV_APPEND_LOG(";"); \
}
DEF_print_x_e(apDataRoutine_e);
DEF_print_x_e(apCondRoutine_e);
DEF_print_x_e(actionPacket_e);

////////////////////////////////////////////////////////////////////////////////
//////////////////              Add Param generation          //////////////////
////////////////////////////////////////////////////////////////////////////////
#define DEF_add_param(enum_val) \
else if(!strcmp(gen_current_cli_arg_,#enum_val)) param->value = enum_val;
#define DEF_add_from_arg_e_x_(enum_type) \
static inline void add_from_arg_##enum_type##_t(enum_type##_t* param, char* gen_current_cli_arg_) \
{ \
    if(false){} \
    LIST_##enum_type(DEF_add_param) \
    else RLV_LOG_ERROR("unknown value for "#enum_type); \
} 
DEF_add_from_arg_e_x_(FunctionalState)
DEF_add_from_arg_e_x_(apDataRoutine_e)
DEF_add_from_arg_e_x_(apCondRoutine_e)
DEF_add_from_arg_e_x_(actionPacket_e)

////////////////////////////////////////////////////////////////////////////////
//////////////////                   Helpers                  //////////////////
////////////////////////////////////////////////////////////////////////////////
#define RLV_BLE__EXPECT_PACKETS_EQUAL(precondition, rxPacket,header,length,payload) do { \
    RLV_LOG_LINE("Checking that "#rxPacket" is the same as expected packet:"); \
    RLV_BLE_ExpectPacketsEqual(precondition, rxPacket ,header,length,payload, true); \
}while(0)

#endif //RLV_BLE_DATA_H_
#endif //RF_LLD_VALIDATION