 /*******************************************************************************
  * @file    TODO
  * @author  MCD Application Team
  * @brief   TODO
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "RLV_TestFramework.h"
#include "RLV_EnvParameters.h"
#include "RLV_Logger.h"
#include "host_rlv.h"


////////////////////////////////////////////////////////////////////////////////
//////////////////                Size Guard                  //////////////////
////////////////////////////////////////////////////////////////////////////////
#if (RLV_MESSAGE_BUFFER_SIZE <= (RLV_LOG_SIZE + 300))
#error "RLV_MESSAGE_BUFFER_SIZE should be greater than RLV_LOG_SIZE plus a safety margin"
#endif

////////////////////////////////////////////////////////////////////////////////
//////////////////             Private variables              //////////////////
////////////////////////////////////////////////////////////////////////////////
static char messageBuffer[RLV_MESSAGE_BUFFER_SIZE] = {0};
static uint16_t messageBufferLength = 0;


////////////////////////////////////////////////////////////////////////////////
//////////////////             Public functions               //////////////////
////////////////////////////////////////////////////////////////////////////////
void RLV_LOG_Init(void)
{
    memset(messageBuffer,0,RLV_MESSAGE_BUFFER_SIZE);
    messageBufferLength = 0;
}



void RLV_APPEND_LOG(const char* format, ...)
{
    if(RLV_Parameters_ptr->delayedPrint)
    {
        va_list paramList;
        va_start(paramList, format);
        messageBufferLength += vsnprintf(&messageBuffer[messageBufferLength], (RLV_MESSAGE_BUFFER_SIZE - messageBufferLength), format, paramList);
        va_end(paramList);
        // Overflow protection
        if (messageBufferLength > RLV_LOG_SIZE)
        {
            sprintf(messageBuffer, "\nM0@ Error: could not display message because too long (buffer size is %u), please check the code\nM0@ [...]", RLV_LOG_SIZE);
            messageBufferLength = 110;
        }
    }
    else
    {
        uint16_t length = 0;
        char     printString[RLV_UNDELAYED_PRINT_BUFFER_SIZE + 300];
        va_list paramList;
        va_start(paramList, format);
        length += vsnprintf(&printString[length], (RLV_UNDELAYED_PRINT_BUFFER_SIZE - length), format, paramList);
        va_end(paramList);
        printString[length++] = 0U;
        // Send the printf to CLI response channel
        HOST_LldTestsSendCliRspToM4(printString, length);
    }
}

void RLV_PRINT_LOG(void)
{
    //split messageBuffer into smaller chunks
    for(uint8_t chunkId= 0; chunkId < messageBufferLength/(RLV_LOG_CHUNK_SIZE-1)+1; chunkId++)
    {
        char messageBufferChunk[(RLV_LOG_CHUNK_SIZE-1)] = {0};
        uint16_t offset  = chunkId*(RLV_LOG_CHUNK_SIZE-1);
        uint16_t chunkSize = (chunkId <= messageBufferLength/(RLV_LOG_CHUNK_SIZE-1))? (RLV_LOG_CHUNK_SIZE-1):(messageBufferLength % (RLV_LOG_CHUNK_SIZE-1));
        
        memcpy((char*)(messageBufferChunk),(char*)(messageBuffer + offset), chunkSize);
        messageBufferChunk[chunkSize++]=0;
        // Send the printf to CLI response channel 
        HOST_LldTestsSendCliRspToM4((char*)(messageBufferChunk), chunkSize);
        //do not flood the rsp/uart buffers
        //us_delay(50); 
    }
    
    memset(messageBuffer,0, messageBufferLength);
    messageBufferLength = 0;
}

#endif //RF_LLD_VALIDATION