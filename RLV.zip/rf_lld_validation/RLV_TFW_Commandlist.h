/**
  ******************************************************************************
  * @file    TODO
  * @author  MCD Application Team
  * @brief   TODO
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_TFW_COMMANDLIST_H_
#define RLV_TFW_COMMANDLIST_H_
////////////////////////////////////////////////////////////////////////////////
//////////////////                    Macros                  //////////////////
////////////////////////////////////////////////////////////////////////////////
#define DEC_command(command_name, ...) \
extern void command_name(char ** argList, uint8_t argNumber);

#define INIT_command(command_name, ...) \
{ #command_name, & command_name, __VA_ARGS__ },

#define DEF_command(command_name,code) \
void command_name(char ** argList, uint8_t argNumber) \
{ \
   uint8_t argListIndex_= 0; \
   (void)argListIndex_; \
   code; \
   if((argListIndex_ != argNumber) && (argListIndex_ != 0)) \
   { \
       RLV_LOG_ERROR("Number of arg (%u) read differs from predefined number of args (%u) , please check LIST_TFW_commands in the code.",argListIndex_,argNumber); \
   } \
}

////////////////////////////////////////////////////////////////////////////////
//////////////////               Command list                 //////////////////
////////////////////////////////////////////////////////////////////////////////
#define LIST_TFW_commands(X) \
        X(TFW_Command__HelloWorld,                              0,          "<no arg>",                       "Prints 'hello world'") \
        X(TFW_Command__SystemReset,                             0,          "<no arg>",                       "Resets the board") \
        X(TFW_Command__PrintTestEnvParameters,                  0,          "<no arg>",                       "Prints all test environment parameters ") \
        X(TFW_Command__ResetTestEnvParametersToDefaultValues,   0,          "<no arg>",                       "Resets all test environment parameters to their default value") \
        X(TFW_Command__SetParam,                                2,          "<param_name> <param_value>",     "Sets a test environment parameter to a specified value") \
        X(TFW_Command__GetParam,                                1,          "<param_name>",                   "Gets a test environment parameter's value") \
        //name,                                          arg number,     command use                      command purpose (short text)
        //end of list
          
LIST_TFW_commands(DEC_command);

#endif // RLV_TFW_COMMANDLIST_H_
#endif // RF_LLD_VALIDATION

