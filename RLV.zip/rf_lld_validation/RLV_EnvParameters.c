/*******************************************************************************
* @file    TODO
* @author  MCD Application Team
* @brief   TODO
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the 
* License. You may obtain a copy of the License at:
*                        opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*/
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#ifdef USE_PROTOCOL_BLE
    #include "RLV_BLE_Data.h"
    #include "RLV_BLE_Types.h"
#endif
#ifdef USE_PROTOCOL_802154
    #include "RLV_154_Data.h"
    #include "RLV_154_Types.h"
#endif
#include "RLV_TFW_Data.h"
#include "RLV_TFW_Types.h"
#include "RLV_BLE_Data.h"
#include "RLV_BLE_Types.h"
#include "RLV_EnvParameters.h"
////////////////////////////////////////////////////////////////////////////////
//////////////////               Private variable             //////////////////
////////////////////////////////////////////////////////////////////////////////
static volatile RLV_Parameters_t          parametersPrivate        = {0};
static volatile const RLV_Parameters_t    defaultParametersPrivate =
{
    LIST_TFW_param(INIT_param)
#ifdef USE_PROTOCOL_BLE
    LIST_BLE_param(INIT_param)
#endif
#ifdef USE_PROTOCOL_802154
    LIST_154_param(INIT_param)
#endif
};

////////////////////////////////////////////////////////////////////////////////
//////////////////               Public variable             ///////////////////
////////////////////////////////////////////////////////////////////////////////
RLV_Parameters_t* RLV_Parameters_ptr = (RLV_Parameters_t*) &parametersPrivate;
RLV_Parameters_t* RLV_DefaultParameters_ptr = (RLV_Parameters_t*) &defaultParametersPrivate;

////////////////////////////////////////////////////////////////////////////////
//////////////////                Public functions            //////////////////
////////////////////////////////////////////////////////////////////////////////
void RLV_TFW_Init(void)
{
    memcpy(RLV_Parameters_ptr,RLV_DefaultParameters_ptr,sizeof(RLV_Parameters_t));
    RLV_BLE_InitData();
    RLV_TFW_ClearFlags();
}

void RLV_TFW_PrintTestEnvParameters(void)
{
    LIST_TFW_param(SHOW_param)
}

#define FIND_AND_SetParam(param_type, param_name,default_value) \
else if(!strcmp(#param_name,paramName)) {add_param_from_arg_with_default_and_preset(param_name,paramValue);}

#define FIND_AND_GetParam(param_type, param_name,default_value) \
else if(!strcmp(#param_name,paramName)) {RLV_SHOW_PARAM(param_name);}

#define DEF_FindAndDo(macro) \
static void FindAnd##macro(char * paramName,char * paramValue) \
{ \
    if(false){} \
    LIST_TFW_param(FIND_AND_##macro) \
    LIST_BLE_param(FIND_AND_##macro) \
    else { RLV_LOG_ERROR("unknown parameter");} \
}
DEF_FindAndDo(SetParam);
DEF_FindAndDo(GetParam);

void RLV_TFW_SetParam(char * paramName,char * paramValue)
{
    FindAndSetParam(paramName,paramValue);
}

void RLV_TFW_GetParam(char * paramName)
{
    FindAndGetParam(paramName,NULL);
}


#endif //RF_LLD_VALIDATION