/*******************************************************************************
* @file    TODO
* @author  MCD Application Team
* @brief   TODO
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the 
* License. You may obtain a copy of the License at:
*                        opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*/
  
#if defined(RF_LLD_VALIDATION)
#ifndef RLV_TFW_DATA_H_
#define RLV_TFW_DATA_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////

#ifdef USE_PROTOCOL_802154
  #include "ip802154_lld.h"
  #include "ip802154_lld_priv.h"
  #include "ip802154_lld_registers.h"
  #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
  #include "ipBLE_lld.h"
  #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE

#include "RLV_TestFramework.h"
#include "RLV_Logger.h"
#include "RLV_TFW_Types.h"

#ifdef USE_PROTOCOL_BLE
    #include "RLV_BLE_Data.h"
    #include "RLV_BLE_Types.h"
#endif
#ifdef USE_PROTOCOL_802154
    #include "RLV_154_Data.h"
    #include "RLV_154_Types.h"
#endif


////////////////////////////////////////////////////////////////////////////////
//////////////////                 Actions                    //////////////////
////////////////////////////////////////////////////////////////////////////////
#define INIT_param(param_type, param_name,default_value) \
.param_name = default_value,

#define DEF_param(param_type, param_name,default_value) \
param_type param_name;

#define SHOW_param(param_type, param_name,default_value) \
RLV_SHOW_PARAM(param_name);

////////////////////////////////////////////////////////////////////////////////
//////////////////                  Lists                     //////////////////
////////////////////////////////////////////////////////////////////////////////

#define LIST_TFW_param(X) \
        LIST_TFW_config(X) \
        LIST_TFW_event(X) \
        LIST_TFW_tools(X) \
        //end of list

#define LIST_TFW_config(X) \
        X(bool,             displayArrayWithChar,           false) \
        X(bool,             displayFullArrayIfCheckFails,   true) \
        X(bool,             delayedPrint,                   true) \
        //type             param_name            default value
        //end of list

#define LIST_TFW_event(X) \
        X(uint8_t,          actionId,                       0) \
        X(bool,             lowPowerEnabled,                true) \
        //type             param_name            default value
        //end of list

#define LIST_TFW_tools(X) \
        X(uint32_t,         param1,                         8) \
        X(uint32_t,         param2,                         12) \
        X(uint32_t,         param3,                         42) \
        //type             param_name            default value
        //end of list

////////////////////////////////////////////////////////////////////////////////
//////////////////                String handlers             //////////////////
////////////////////////////////////////////////////////////////////////////////
static inline uint16_t StringPosition(char *haystack, char *needle)
{
   char *p = strstr(haystack, needle);
   return (p ? p - haystack : (uint16_t)-1);
}

static inline bool IsComposedOfAtLeastOneOfCharInList(char *str, char* list)
{
    return (str[strcspn(str,list)] != '\0');
}

static inline bool DoesContainOnlySomeOrAllCharInList(char *str, char* list)
{
    return (str[strspn(str,list)] == '\0');
}

static inline bool DoesContainAllCharInList(char *str, char* list)
{
    bool retVal = true;
    for(uint8_t index = 0; index < strlen(list); index++)
    {
        retVal = retVal && strchr(str,list[index]);
        if (!retVal) break;
    }
    return retVal;
}

static inline bool DoesContainString(char *str, char* strInStr)
{
    return (strstr(str,strInStr) != NULL);
}

////////////////////////////////////////////////////////////////////////////////
//////////////////              Application helpers           //////////////////
////////////////////////////////////////////////////////////////////////////////
extern void                 RLV_TFW_ClearFlags(void);
extern bool                 RLV_TFW_IsAnActionPending(void);
extern void                 RLV_TFW_SetPendingAction(uint8_t id, bool status);
extern bool                 RLV_TFW_HasAnActionFailed(void);
extern void                 RLV_TFW_SetFailedAction(uint8_t id, bool status);

////////////////////////////////////////////////////////////////////////////////
//////////////////                Print generation            //////////////////
////////////////////////////////////////////////////////////////////////////////
#define DEF_print_x_t(int_type) \
static inline void print_##int_type(int_type* val, char * dummy) \
{ \
    (void)dummy; \
    RLV_APPEND_LOG(" = %u (0x%08x)",(int_type)*val,(int_type)*val); \
} 
DEF_print_x_t(uint32_t)
DEF_print_x_t(uint16_t)
DEF_print_x_t(uint8_t)

#define DEF_print_array_x_t(type) \
static inline void print_array_##type(array_##type* val, char * dummy) \
{ \
    (void)dummy; \
    RLV_APPEND_LOG("[%u] = {",val->length); \
    uint16_t i; \
    for(i = 0; (i < RLV_MAX_DISPLAYABLE_ARR_SIZE)&&(i < val->length); i++) \
    { \
        RLV_APPEND_LOG(dummy,val->content[i],val->content[i]); \
        if((i +1 < RLV_MAX_DISPLAYABLE_ARR_SIZE) && (i + 1 < val->length)) {RLV_APPEND_LOG(",");} \
    } \
    if(i == val->length) \
    { \
        RLV_APPEND_LOG("}"); \
    } \
    else \
    { \
        RLV_APPEND_LOG(",...}"); \
    } \
} 
DEF_print_array_x_t(uint32_t)
DEF_print_array_x_t(uint16_t)
DEF_print_array_x_t(uint8_t)

static inline void print__Bool(_Bool* val, char * dummy)
{
    (void)dummy;
    RLV_APPEND_LOG(" = %s",(*val?"TRUE":"FALSE"));
}

////////////////////////////////////////////////////////////////////////////////
//////////////////              Add Param  generation          //////////////////
////////////////////////////////////////////////////////////////////////////////
#define add_from_arg_int_x_(param,gen_current_cli_arg_) \
do{ \
    if((((gen_current_cli_arg_[0]=='T')       || \
       !strcmp(gen_current_cli_arg_,"True")  || \
       !strcmp(gen_current_cli_arg_,"TRUE")  || \
       !strcmp(gen_current_cli_arg_,"true")) && \
       (DoesContainOnlySomeOrAllCharInList(gen_current_cli_arg_, "TRUEtrue"))) ||  \
       (((gen_current_cli_arg_[0]=='F')        || \
       !strcmp(gen_current_cli_arg_,"False") || \
       !strcmp(gen_current_cli_arg_,"FALSE") || \
       !strcmp(gen_current_cli_arg_,"false")) && \
       (DoesContainOnlySomeOrAllCharInList(gen_current_cli_arg_, "FALSEfalse"))))  \
    { \
        *(param) = ((gen_current_cli_arg_[0] == 'T' || gen_current_cli_arg_[0] == 't') ? 1 : 0);   \
    } \
    else if((gen_current_cli_arg_[0]=='0') && \
            (gen_current_cli_arg_[1]=='x') && \
            (DoesContainOnlySomeOrAllCharInList(gen_current_cli_arg_, "xabcdefABCDEF0123456789")))   \
    {     \
        *(param) = strtol(gen_current_cli_arg_,NULL,16);   \
    }   \
    else if(DoesContainOnlySomeOrAllCharInList(gen_current_cli_arg_, "0123456789")) \
    { \
        *(param) = (uint32_t)strtol(gen_current_cli_arg_,NULL,10); \
    } \
    else \
    { \
        RLV_LOG_ERROR("wrong format for bool or integer, use for instance 'T','False','0','33','0xFFF'"); \
    } \
}while(0)

#define DEF_add_from_arg_int_x_(integer_type) \
static inline void add_from_arg_##integer_type(integer_type* param, char* gen_current_cli_arg_) \
{ \
    add_from_arg_int_x_(param,gen_current_cli_arg_); \
} 
DEF_add_from_arg_int_x_(_Bool);
DEF_add_from_arg_int_x_(uint8_t);
DEF_add_from_arg_int_x_(uint16_t);
DEF_add_from_arg_int_x_(uint32_t);

#define add_from_arg_arr_x_(param,gen_current_cli_arg_,type)  \
do{ \
    bool isInError = true; \
    type bufArray[RLV_MAX_ARR_BUF_SIZE] = {0}; \
    if(DoesContainOnlySomeOrAllCharInList(gen_current_cli_arg_, "[]{}x0123456789abcdefABCDEF*,") && \
    DoesContainAllCharInList(gen_current_cli_arg_, "[]{}") && \
    DoesContainString(gen_current_cli_arg_, "]{") && \
    (gen_current_cli_arg_[0]=='[') && \
    (gen_current_cli_arg_[strlen(gen_current_cli_arg_)-1] == '}'))  \
    {  \
        char clen[RLV_MAX_INPUTABLE_ARRAY_LENGHT_CHAR_SIZE]; \
        uint16_t ulen=0; \
        char * gen_array_arg; \
        char current_arg[RLV_MAX_INPUTABLE_ARRAY_CHAR_SIZE] ; \
        char * current_arg_ptr = current_arg; \
        strcpy(current_arg_ptr,gen_current_cli_arg_); \
        gen_array_arg = strtok(strpbrk (current_arg_ptr, "{")+1, ","); \
        uint32_t ulen_pos =(uint32_t)(StringPosition(current_arg_ptr, "]")-1); \
        bool isAutoFilled = (ulen_pos == 0); \
        strxfrm(clen, (char*)(current_arg_ptr+1), (uint32_t)((size_t)current_arg_ptr+1U+(size_t)ulen_pos)); \
        do \
        {  \
            if((gen_array_arg[0]=='0') && (gen_array_arg[1]=='x')) \
            { \
                if(DoesContainOnlySomeOrAllCharInList(gen_array_arg, "x0123456789abcdefABCDEF}*")) \
                { \
                    if(DoesContainAllCharInList(gen_array_arg, "0x}*") && \
                        (ulen == 0) && \
                        (isAutoFilled == false)) \
                    { \
                        memset(bufArray, (type)strtol (gen_array_arg, NULL, 16), strtol (clen, NULL, 10)); \
                        isInError = false; \
                    } \
                    else if(DoesContainAllCharInList(gen_array_arg, "*") == false) \
                    { \
                        bufArray[ulen++] = (type)strtol (gen_array_arg, NULL, 16); \
                        isInError = !DoesContainAllCharInList(gen_array_arg, "x0}"); \
                    } \
                    else \
                    { \
                        isInError = true; \
                    } \
                } \
                else \
                { \
                    isInError = true; \
                } \
            } \
            else \
            { \
                isInError = true; \
            } \
            gen_array_arg = strtok(NULL, ","); \
        }while(gen_array_arg != NULL); \
        if (false == isInError) \
        { \
            param->length = isAutoFilled ? ulen : strtol (clen, NULL, 10); \
            memcpy(param->content, bufArray, RLV_MAX_ARR_BUF_SIZE-1); \
        } \
        else \
        { \
            RLV_LOG_ERROR("wrong format for array element (%u), use hexa, for instance '[]{0xA,0x10,0x0,0xA1FC}'\n",ulen-1); \
            RLV_LOG_ERROR("or wrong format for auto filled array, use this '[3]{0xAA*}' to get '[3]{0xAA,0xAA,0xAA}'\n"); \
        } \
    } \
    else \
    { \
        RLV_LOG_ERROR("wrong format for array, use for instance '[8]{0xA,0x0,0xA1FC}', '[0]{}', or '[]{0xFF}'\n"); \
    } \
}while(0)  
    
#define DEF_add_from_arg_arr_x_(type) \
static inline void add_from_arg_array_##type(array_##type* param, char* gen_current_cli_arg_) \
{ \
    add_from_arg_arr_x_(param,gen_current_cli_arg_,type); \
} 
DEF_add_from_arg_arr_x_(uint8_t)
DEF_add_from_arg_arr_x_(uint16_t)
DEF_add_from_arg_arr_x_(uint32_t)


#endif //RLV_TFW_DATA_H_
#endif //RF_LLD_VALIDATION