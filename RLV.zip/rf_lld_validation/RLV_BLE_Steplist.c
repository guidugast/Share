 /*******************************************************************************
  * @file    TODO.c
  * @author  MCD Application Team
  * @brief   TODO
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the 
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "common_rf_lld.h"
#include "common.h"

#ifdef USE_PROTOCOL_802154
    #include "ip802154_lld.h"
    #include "ip802154_lld_priv.h"
    #include "ip802154_lld_registers.h"
    #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
    #include "ipBLE_lld.h"
    #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE

#include <stdlib.h>

#include "RLV_TestFramework.h"
#include "RLV_TFW_Data.h"
#include "RLV_TFW_Types.h"
#include "RLV_BLE_Data.h"
#include "RLV_BLE_Types.h"
#include "RLV_Logger.h"
#include "RLV_EnvParameters.h"
#include "RLV_Timer.h"


#include "RLV_BLE_Steplist.h"

////////////////////////////////////////////////////////////////////////////////
//////////////////             Public functions               //////////////////
////////////////////////////////////////////////////////////////////////////////

void RLV_Step__DoWithTimeout(void)//testing purposes
{
    RLV_LOG_LINE("starting iterating");
    RLV_PRINT_LOG();
    RLV_TIM__DO_WITH_TIMEOUT(RLV_Parameters_ptr->stressDurationInS ,
        us_delay(RLV_Parameters_ptr->rxStressDeltaBlockingDelayInUs);
    );
    RLV_LOG_LINE("iteration success");
    RLV_PRINT_LOG();
}

void BLE_Step__TimerTest(void)
{
    RLV_LOG_LINE("starting iterating");
    RLV_TIM_Init();
    RLV_TIM_StartTimer();

    while (RLV_TIM_GetTimeInS() < RLV_Parameters_ptr->stressDurationInS )
    {
        RLV_LOG_LINE("RLV_TIM_GetTimeInS() = %d",RLV_TIM_GetTimeInS());
        RLV_PRINT_LOG();
        us_delay(RLV_Parameters_ptr->rxStressDeltaBlockingDelayInUs);
    }

    if(RLV_TIM_GetTimeInS() != (uint32_t)-1) 
    {
        RLV_LOG_LINE("iteration success");
    }
    else
    {
        RLV_LOG_LINE("timer did not stop");
    }
    RLV_PRINT_LOG();
}

void BLE_Step__LldBleInit(void)
{
    ///PREPARE DATA
    uint32_t hotAnaTable[RLV_Parameters_ptr->hotAnaTable.length];
    memset(hotAnaTable, 0, sizeof(hotAnaTable));
    memcpy(hotAnaTable, RLV_Parameters_ptr->hotAnaTable.content, RLV_Parameters_ptr->hotAnaTable.length);
    
    ///CALL API & CHECK RESULTS
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_Init(RLV_Parameters_ptr->hsStartupTime,
                                             RLV_Parameters_ptr->lowSpeedOsc,
                                             hotAnaTable,
                                             RLV_Parameters_ptr->whitening.value),
                                "LLD_BLE_Init");
}

void BLE_Step__HalBleInit(void)
{
    ///PREPARE DATA
    ipBLE_lld_mode_t bleIpMode = IPBLE_LLD_MODE_BLE_5_0;//TODO use parameter
    
    ///CALL API & CHECK RESULTS
    RLV_TFW__CALL_DID_NOT_CRASH(HAL_BLE_Init(bleIpMode),
                                "HAL_BLE_Init");
}

void BLE_Step__SetNetworkId(void)
{
    ///CALL API
    RLV_TFW__CALL_DID_NOT_CRASH(HAL_BLE_SetNetworkID(RLV_Parameters_ptr->networkId),"HAL_BLE_SetNetworkID");
}

void BLE_Step__SendOnePacket_HAL(void)
{
    ///PREPARE DATA 
    uint32_t returnValue;
    
    uint8_t txBuffer[RLV_Parameters_ptr->txPayload.length + 2 + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0)];
    RLV_BLE_FillPacket(txBuffer,
                       RLV_Parameters_ptr->txHeader,
                       RLV_Parameters_ptr->txPayload.length  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                       RLV_Parameters_ptr->txPayload.content);

    uint8_t txAckPacket[RLV_MAX_PACKET_SIZE];
    memset(txAckPacket, 0, sizeof(txAckPacket));
    
    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_IRQ_DONE});

    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
    
    ///CALL API & CHECK RESULTS
    RLV_TFW_ClearFlags();
    RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
    
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_TFW__CALL_DID_NOT_CRASH(returnValue=HAL_BLE_SendPacketWithAck(RLV_Parameters_ptr->channel,
                                                        RLV_Parameters_ptr->wakeupTime,
                                                        txBuffer,
                                                        txAckPacket,
                                                        RLV_Parameters_ptr->txAckReceiveWindow,
                                                        RLV_BLE_GetDataRoutine(2)),
                                                        "HAL_BLE_SendPacketWithAck");
        RLV_LOG_LINE("returnValue for 'HAL_BLE_SendPacketWithAck' = 0x%02x, possibles returns are:",returnValue);
    }
    else
    {
        RLV_TFW__CALL_DID_NOT_CRASH(returnValue=HAL_BLE_SendPacket(RLV_Parameters_ptr->channel,
                                                       RLV_Parameters_ptr->wakeupTime,
                                                       txBuffer,
                                                       RLV_BLE_GetDataRoutine(2)),
                                                       "HAL_BLE_SendPacket");
        RLV_LOG_LINE("returnValue for 'HAL_BLE_SendPacket' = 0x%02x, possibles returns are:",returnValue);
    }

    RLV_LOG_LINE("  - SUCCESS_0 (0x%02x)",SUCCESS_0);
    RLV_LOG_LINE("  - INVALID_PARAMETER_C0 (0x%02x)",INVALID_PARAMETER_C0);
    
    if(RLV_Parameters_ptr->crystalCheckEnabled)
    {
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_CrystalCheck(),"LLD_BLE_CrystalCheck");
    }
    
    if(RLV_Parameters_ptr->isGetStatusWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__GetStatus();
    }
    if(RLV_Parameters_ptr->isStopToneWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopTone();
    }
    
    if(RLV_Parameters_ptr->isStopActivityWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopActivity();
    }
  
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_LOG_LINE("Waiting for packet to be sent and the ack to be received...");
        for(uint16_t i = 0;RLV_TFW_IsAnActionPending() && (i < 10000);i++) us_delay(RLV_Parameters_ptr->txAckReceiveWindow/10000+5);
    }
    else
    {
        RLV_LOG_LINE("Waiting for the packet to be sent...");
        for(uint16_t i = 0;RLV_TFW_IsAnActionPending() && (i < 10000);i++) us_delay(50);
    }
    
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_IsAnActionPending(),false);
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_HasAnActionFailed(),false);
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_BLE__EXPECT_PACKETS_EQUAL(!RLV_TFW_HasAnActionFailed(), txAckPacket, RLV_Parameters_ptr->txAckExpectedHeader, RLV_Parameters_ptr->txAckExpectedPayload.length, RLV_Parameters_ptr->txAckExpectedPayload.content);
    }
}

void BLE_Step__ReceiveOnePacket_HAL(void)
{
    ///PREPARE DATA 
    uint8_t returnValue;
    
    uint8_t rxReceivedPacket[RLV_MAX_PACKET_SIZE];
    memset(rxReceivedPacket, 0, sizeof(rxReceivedPacket));
    
    uint8_t rxAckBuffer[RLV_Parameters_ptr->rxAckPayload.length + 2  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0)];
    RLV_BLE_FillPacket(rxAckBuffer,
                       RLV_Parameters_ptr->rxAckHeader,
                       RLV_Parameters_ptr->rxAckPayload.length  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                       RLV_Parameters_ptr->rxAckPayload.content);

  
    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_IRQ_DONE});
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
    
    ///CALL API & CHECK RESULTS
    RLV_TFW_ClearFlags();
    RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
    
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_TFW__CALL_DID_NOT_CRASH(returnValue=HAL_BLE_ReceivePacketWithAck(RLV_Parameters_ptr->channel,
                                                                  RLV_Parameters_ptr->wakeupTime, 
                                                                  rxReceivedPacket,
                                                                  rxAckBuffer,
                                                                  RLV_Parameters_ptr->rxReceiveWindow,
                                                                  RLV_BLE_GetDataRoutine(2)),
                                                                  "HAL_BLE_ReceivePacketWithAck");
        RLV_LOG_LINE("returnValue for 'HAL_BLE_ReceivePacketWithAck' = 0x%02x, possibles returns are:",returnValue);
    }
    else
    {
        RLV_TFW__CALL_DID_NOT_CRASH(returnValue=HAL_BLE_ReceivePacket(RLV_Parameters_ptr->channel,
                                                                  RLV_Parameters_ptr->wakeupTime, 
                                                                  rxReceivedPacket,
                                                                  RLV_Parameters_ptr->rxReceiveWindow,
                                                                  RLV_BLE_GetDataRoutine(2)),
                                                                  "HAL_BLE_ReceivePacket");
        RLV_LOG_LINE("returnValue for 'HAL_BLE_ReceivePacket' = 0x%02x, possibles returns are:",returnValue);
    }
    RLV_LOG_LINE("  - SUCCESS_0 (0x%02x)",SUCCESS_0);
    RLV_LOG_LINE("  - INVALID_PARAMETER_C0 (0x%02x)",INVALID_PARAMETER_C0);
    
    if(RLV_Parameters_ptr->crystalCheckEnabled)
    {
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_CrystalCheck(),"LLD_BLE_CrystalCheck");
    }
    
    if(RLV_Parameters_ptr->isGetStatusWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__GetStatus();
    }
    if(RLV_Parameters_ptr->isStopToneWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopTone();
    }
    
    if(RLV_Parameters_ptr->isStopActivityWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopActivity();
    }
  
    RLV_LOG_LINE("Waiting for a packet to be received ");
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_APPEND_LOG("to send ack...");
    }
    else
    {
        RLV_APPEND_LOG("...");
    }
    //TODO : shall the Xtal check be in this while loop? (or schedule while waiting for the packet to be received?)
    
    for(uint16_t i = 0;RLV_TFW_IsAnActionPending() && (i < 10000);i++) us_delay(RLV_Parameters_ptr->rxReceiveWindow/10000+5);

    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_IsAnActionPending(),false);
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_HasAnActionFailed(),false);
    
    RLV_BLE__EXPECT_PACKETS_EQUAL(!RLV_TFW_HasAnActionFailed(), rxReceivedPacket, RLV_Parameters_ptr->rxExpectedHeader, RLV_Parameters_ptr->rxExpectedPayload.length, RLV_Parameters_ptr->rxExpectedPayload.content);

    if(RLV_Parameters_ptr->showRssi)
    {
      RLV_LOG_LINE("RSSI : [%d]",RLV_BLE_GetLastRssiInDbm());
    }
}

void BLE_Step__TxStress_HAL(void)
{
    ///PREPARE DATA
    uint8_t txBuffer[RLV_Parameters_ptr->txPayload.length +2  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0)];
    RLV_BLE_FillPacket(txBuffer,
                       RLV_Parameters_ptr->txHeader,
                       RLV_Parameters_ptr->txPayload.length  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                       RLV_Parameters_ptr->txPayload.content);

    uint8_t txAckPacket[RLV_MAX_PACKET_SIZE];
    memset(txAckPacket, 0, sizeof(txAckPacket));
    
    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_TXRX_ACTION_DONE});//called during the tx ack, first data routine for tx is null
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
    
    uint32_t sendCounter = 0;
    uint32_t ackEqualCounter = 0;
    RLV_Parameters_ptr->txSuccessCounter = 0;
    RLV_Parameters_ptr->rxSuccessCounter = 0;
    RLV_Parameters_ptr->rxCrcErrorCounter = 0;
    RLV_Parameters_ptr->rxTimeoutErrorCounter = 0;
    RLV_Parameters_ptr->rxUnkownErrorCounter = 0;
    RLV_Parameters_ptr->shouldTxNotRx = true;
    
    ///CALL API & CHECK RESULTS
    RLV_LOG_LINE("Please wait during stress procedure...");
    RLV_PRINT_LOG();
    RLV_TIM__DO_WITH_TIMEOUT(RLV_Parameters_ptr->stressDurationInS,
        RLV_TFW_ClearFlags();
        RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
        RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
        
        if(RLV_Parameters_ptr->withAck)
        {
            HAL_BLE_SendPacketWithAck(RLV_Parameters_ptr->channel,
                                      RLV_Parameters_ptr->wakeupTime,
                                      txBuffer,
                                      txAckPacket,
                                      RLV_Parameters_ptr->txAckReceiveWindow,
                                      RLV_BLE_GetDataRoutine(2));
        }
        else
        {
            HAL_BLE_SendPacket(RLV_Parameters_ptr->channel,
                               RLV_Parameters_ptr->wakeupTime,
                               txBuffer,
                               RLV_BLE_GetDataRoutine(2));
        }
        if(RLV_Parameters_ptr->crystalCheckEnabled)
        {
            LLD_BLE_CrystalCheck();
        }
        
        while(RLV_TFW_IsAnActionPending());
        if(RLV_Parameters_ptr->withAck)
        {
            if (RLV_BLE_ExpectPacketsEqual(!RLV_TFW_HasAnActionFailed(),
                                           txAckPacket, 
                                           RLV_Parameters_ptr->txAckExpectedHeader,
                                           RLV_Parameters_ptr->txAckExpectedPayload.length,
                                           RLV_Parameters_ptr->txAckExpectedPayload.content, 
                                           false))
            {
                ackEqualCounter++;
            }
        }
        sendCounter++;

        us_delay(RLV_Parameters_ptr->txStressDeltaBlockingDelayInUs);
    );
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_LOG_LINE("ackEqualCounter %d / sendCounter %d (txSuccessCounter %d rxCrcErrorCounter %d rxTimeoutErrorCounter %d rxUnkownErrorCounter %d)",
                     ackEqualCounter,
                     sendCounter,
                     RLV_Parameters_ptr->txSuccessCounter,
                     RLV_Parameters_ptr->rxCrcErrorCounter,
                     RLV_Parameters_ptr->rxTimeoutErrorCounter,
                     RLV_Parameters_ptr->rxUnkownErrorCounter);
    }
    else
    {
        RLV_LOG_LINE(" txSuccessCounter %d / sendCounter %d ",
                     RLV_Parameters_ptr->txSuccessCounter,
                     sendCounter);
    }
}

void BLE_Step__RxStress_HAL(void)
{
    ///PREPARE DATA
    RLV_LOG_LINE("Please wait during stress procedure...");
    RLV_PRINT_LOG();
    uint8_t rxReceivedPacket[RLV_MAX_PACKET_SIZE];
    
    uint8_t rxAckBuffer[RLV_Parameters_ptr->rxAckPayload.length + 2  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0)];
    RLV_BLE_FillPacket(rxAckBuffer,
                       RLV_Parameters_ptr->rxAckHeader,
                       RLV_Parameters_ptr->rxAckPayload.length  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                       RLV_Parameters_ptr->rxAckPayload.content);

    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_TXRX_ACTION_DONE});
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
    
    uint32_t receiveCounter = 0;
    uint32_t packetEqualCounter = 0;
    RLV_Parameters_ptr->txSuccessCounter = 0;
    RLV_Parameters_ptr->rxSuccessCounter = 0;
    RLV_Parameters_ptr->rxCrcErrorCounter = 0;
    RLV_Parameters_ptr->rxTimeoutErrorCounter = 0;
    RLV_Parameters_ptr->rxUnkownErrorCounter = 0;
    RLV_Parameters_ptr->shouldTxNotRx = false;

    ///CALL API & CHECK RESULTS
    RLV_TIM__DO_WITH_TIMEOUT(RLV_Parameters_ptr->stressDurationInS,
        memset(rxReceivedPacket, 0, sizeof(rxReceivedPacket));
        RLV_TFW_ClearFlags();
        RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
        RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
        
        if(RLV_Parameters_ptr->withAck)
        {
            HAL_BLE_ReceivePacketWithAck(RLV_Parameters_ptr->channel,
                                         RLV_Parameters_ptr->wakeupTime, 
                                         rxReceivedPacket,
                                         rxAckBuffer,
                                         RLV_Parameters_ptr->rxReceiveWindow,
                                         RLV_BLE_GetDataRoutine(2));
        }
        else
        {
            HAL_BLE_ReceivePacket(RLV_Parameters_ptr->channel,
                                  RLV_Parameters_ptr->wakeupTime, 
                                  rxReceivedPacket,
                                  RLV_Parameters_ptr->rxReceiveWindow,
                                  RLV_BLE_GetDataRoutine(2));
        }

        if(RLV_Parameters_ptr->crystalCheckEnabled)
        {
            LLD_BLE_CrystalCheck();
        }

        while(RLV_TFW_IsAnActionPending())
        {
            if(RLV_TIM_GetTimeInS() >= RLV_Parameters_ptr->stressDurationInS) break;
        }
        bool rxSuccess = false;

        rxSuccess = RLV_BLE_ExpectPacketsEqual(!RLV_TFW_HasAnActionFailed(),
                                               rxReceivedPacket,
                                               RLV_Parameters_ptr->rxExpectedHeader,
                                               RLV_Parameters_ptr->rxExpectedPayload.length,
                                               RLV_Parameters_ptr->rxExpectedPayload.content, 
                                               false);

        us_delay(RLV_Parameters_ptr->rxStressDeltaBlockingDelayInUs);
        
        if(rxSuccess)
        {
            packetEqualCounter++;
        }
        receiveCounter++; 
    );
    if(RLV_Parameters_ptr->withAck)
    {
        RLV_LOG_LINE("txSuccessCounter %d / receiveCounter %d (packetEqualCounter %d rxCrcErrorCounter %d rxTimeoutErrorCounter %d rxUnkownErrorCounter %d)",
                     RLV_Parameters_ptr->txSuccessCounter,
                     receiveCounter,
                     packetEqualCounter,
                     RLV_Parameters_ptr->rxCrcErrorCounter,
                     RLV_Parameters_ptr->rxTimeoutErrorCounter,
                     RLV_Parameters_ptr->rxUnkownErrorCounter);
    }
    else
    {
        RLV_LOG_LINE("packetEqualCounter %d / receiveCounter %d (rxCrcErrorCounter %d rxTimeoutErrorCounter %d rxUnkownErrorCounter %d)",
                     packetEqualCounter,
                     receiveCounter,
                     RLV_Parameters_ptr->rxCrcErrorCounter,
                     RLV_Parameters_ptr->rxTimeoutErrorCounter,
                     RLV_Parameters_ptr->rxUnkownErrorCounter);
    }
}

void BLE_Step__PingPongStress_HAL(void)
{
    ///PREPARE DATA
    uint8_t txBuffer[RLV_Parameters_ptr->txPayload.length + 2  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0)];
    RLV_BLE_FillPacket(txBuffer,
                       RLV_Parameters_ptr->txHeader,
                       RLV_Parameters_ptr->txPayload.length + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                       RLV_Parameters_ptr->txPayload.content);

    uint8_t txAckPacket[RLV_MAX_PACKET_SIZE];
    memset(txAckPacket, 0, sizeof(txAckPacket));
    
    uint8_t rxReceivedPacket[RLV_MAX_PACKET_SIZE];
    
    uint8_t rxAckBuffer[RLV_Parameters_ptr->rxAckPayload.length + 2  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0)];
    RLV_BLE_FillPacket(rxAckBuffer,
                       RLV_Parameters_ptr->rxAckHeader,
                       RLV_Parameters_ptr->rxAckPayload.length  + ((RLV_Parameters_ptr->encryptStatus.value == ENABLE)?4:0),
                       RLV_Parameters_ptr->rxAckPayload.content);    
    
    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_TXRX_ACTION_DONE});//called during the tx ack, first data routine for tx is null, and called for first and last dataroutine for rx
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
    
    uint32_t sendCounter = 0;
    uint32_t receiveCounter = 0;
    uint32_t packetEqualCounter = 0;
    RLV_Parameters_ptr->txSuccessCounter = 0;
    RLV_Parameters_ptr->rxSuccessCounter = 0;
    RLV_Parameters_ptr->rxCrcErrorCounter = 0;
    RLV_Parameters_ptr->rxTimeoutErrorCounter = 0;
    RLV_Parameters_ptr->rxUnkownErrorCounter = 0;
    RLV_Parameters_ptr->shouldTxNotRx = RLV_Parameters_ptr->txFirstInPingPong;

    ///CALL API & CHECK RESULTS
    RLV_LOG_LINE("Please wait during stress procedure...");
    RLV_PRINT_LOG();
    RLV_TIM__DO_WITH_TIMEOUT(RLV_Parameters_ptr->stressDurationInS,

                         
        if(RLV_Parameters_ptr->shouldTxNotRx)
        {
            RLV_TFW_ClearFlags();
            RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
            RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
            
            HAL_BLE_SendPacket(RLV_Parameters_ptr->channel,
                               RLV_Parameters_ptr->wakeupTime,
                               txBuffer,
                               RLV_BLE_GetDataRoutine(2));

        
            if(RLV_Parameters_ptr->crystalCheckEnabled)
            {
                LLD_BLE_CrystalCheck();
            }
            while(RLV_TFW_IsAnActionPending())
            {
                if(RLV_TIM_GetTimeInS() >= RLV_Parameters_ptr->stressDurationInS) break;
            }

            sendCounter++; \
        }
        else
        {
            memset(rxReceivedPacket, 0, sizeof(rxReceivedPacket));
            RLV_TFW_ClearFlags();
            RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
            RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
            
            HAL_BLE_ReceivePacket(RLV_Parameters_ptr->channel,
                                  RLV_Parameters_ptr->wakeupTime, 
                                  rxReceivedPacket,
                                  rand() % RLV_Parameters_ptr->rxReceiveWindow,
                                  RLV_BLE_GetDataRoutine(2));
            
            if(RLV_Parameters_ptr->crystalCheckEnabled)
            {
                LLD_BLE_CrystalCheck();
            }
            bool rxSuccess = false;

            while(RLV_TFW_IsAnActionPending())
            {
                if(RLV_TIM_GetTimeInS() >= RLV_Parameters_ptr->stressDurationInS) break;
            }

            rxSuccess = RLV_BLE_ExpectPacketsEqual(!RLV_TFW_HasAnActionFailed(),
                                                   rxReceivedPacket,
                                                   RLV_Parameters_ptr->rxExpectedHeader,
                                                   RLV_Parameters_ptr->rxExpectedPayload.length,
                                                   RLV_Parameters_ptr->rxExpectedPayload.content,
                                                   false); 
            us_delay(RLV_Parameters_ptr->rxStressDeltaBlockingDelayInUs);
            if(rxSuccess)
            {
                packetEqualCounter++;
            }
            receiveCounter++; 
        }

        RLV_Parameters_ptr->shouldTxNotRx = !RLV_Parameters_ptr->shouldTxNotRx;
    );

    RLV_LOG_LINE("packetEqualCounter %d / receiveCounter %d (rxCrcErrorCounter %d rxTimeoutErrorCounter %d rxUnkownErrorCounter %d)",
                 packetEqualCounter,
                 receiveCounter,
                 RLV_Parameters_ptr->rxCrcErrorCounter,
                 RLV_Parameters_ptr->rxTimeoutErrorCounter,
                 RLV_Parameters_ptr->rxUnkownErrorCounter);
    RLV_LOG_LINE(" txSuccessCounter %d / sendCounter %d ",
                 RLV_Parameters_ptr->txSuccessCounter,
                 sendCounter);

}

void BLE_Step__SendOneSimplePacket(void)
{
    uint8_t returnValue;
    ///PREPARE DATA
    RLV_Parameters_ptr->actionIsTxNotRx = true;
    
    RLV_BLE_SetCurrentActionPacketType(2,(actionPacket_e_t){AP_TXRX});
    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_IRQ_DONE});
    RLV_BLE_SetCondRoutine(2,(apCondRoutine_e_t){APCR_SIMPLE_RET_TRUE});
    RLV_BLE_SetNextIfTrueActionPacketIndex(2,0);
    RLV_BLE_SetNextIfFalseActionPacketIndex(2,0);
    RLV_BLE_BuildCurrentActionPacket(2);
    
    RLV_TFW_ClearFlags();
    RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
    
    ///CALL API & CHECK RESULTS 
    uint8_t channelMap[RLV_Parameters_ptr->channelMap.length];
    memcpy(channelMap, RLV_Parameters_ptr->channelMap.content, sizeof(channelMap));
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetChannelMap(RLV_Parameters_ptr->apStateMachineId,
                                                    channelMap),
                                                    "LLD_BLE_SetChannelMap");
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetChannel(RLV_Parameters_ptr->apStateMachineId,
                                                RLV_Parameters_ptr->channel,
                                                RLV_Parameters_ptr->channelIncrement),
                                                "LLD_BLE_SetChannel");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTxAttributes(RLV_Parameters_ptr->apStateMachineId,
                                                    RLV_Parameters_ptr->networkId,
                                                    RLV_Parameters_ptr->crcInit,
                                                    RLV_Parameters_ptr->sca),
                                                    "LLD_BLE_SetTxAttributes");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTx_Rx_Phy(RLV_Parameters_ptr->apStateMachineId,
                                                    RLV_Parameters_ptr->txPhy,
                                                    RLV_Parameters_ptr->rxPhy),
                                                    "LLD_BLE_SetTx_Rx_Phy");
    
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetBackToBackTime(RLV_Parameters_ptr->backToBackTime),"LLD_BLE_SetBackToBackTime");
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTxPower(RLV_Parameters_ptr->txPower),"LLD_BLE_SetTxPower");
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
   
    //TODO: LLD_BLE_SetReservedArea/LLD_BLE_MakeActionPacketPending. how to use it? can we call several LLD_BLE_SetReservedArea with different action packet? as, in ap1, ap2, ap3.... if yes, before making the make action packet pending? after?
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetReservedArea(RLV_BLE_GetActionPacket(2)),"LLD_BLE_SetReservedArea");
    RLV_TFW__CALL_DID_NOT_CRASH(returnValue = LLD_BLE_MakeActionPacketPending(RLV_BLE_GetActionPacket(2)),"LLD_BLE_MakeActionPacketPending");
    
    RLV_LOG_LINE("returnValue for 'LLD_BLE_MakeActionPacketPending' = 0x%02x, possibles returns are:",returnValue);
    RLV_LOG_LINE("  - SUCCESS_0 (0x%02x)",SUCCESS_0);
    
    
    if(RLV_Parameters_ptr->crystalCheckEnabled)
    {
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_CrystalCheck(),"LLD_BLE_CrystalCheck");
    }
    
    if(RLV_Parameters_ptr->isGetStatusWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__GetStatus();
    }
    if(RLV_Parameters_ptr->isStopToneWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopTone();
    }
    
    if(RLV_Parameters_ptr->isStopActivityWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopActivity();
    }
  
    RLV_LOG_LINE("Waiting for the packet to be sent...");
    for(uint16_t i = 0;RLV_TFW_IsAnActionPending() && (i < 10000);i++) us_delay(50);
    
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_IsAnActionPending(),false);
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_HasAnActionFailed(),false);
}

void BLE_Step__ReceiveOneSimplePacket(void)
{
    ///PREPARE DATA
    uint8_t returnValue;
    
    RLV_Parameters_ptr->actionIsTxNotRx = false;

    RLV_BLE_SetCurrentActionPacketType(2,(actionPacket_e_t){AP_TXRX});
    RLV_BLE_SetDataRoutine(2,(apDataRoutine_e_t){APDR_CLEAR_FLAG_IF_IRQ_DONE});
    RLV_BLE_SetCondRoutine(2,(apCondRoutine_e_t){APCR_SIMPLE_RET_TRUE});
    RLV_BLE_SetNextIfTrueActionPacketIndex(2,0);
    RLV_BLE_SetNextIfFalseActionPacketIndex(2,0);
    RLV_BLE_BuildCurrentActionPacket(2);
    
    RLV_TFW_ClearFlags();
    RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback to be called)
    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
    
    ///CALL API & CHECK RESULTS
    
    uint8_t channelMap[RLV_Parameters_ptr->channelMap.length];
    memcpy(channelMap, RLV_Parameters_ptr->channelMap.content, sizeof(channelMap));
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetChannelMap(RLV_Parameters_ptr->apStateMachineId,
                                                    channelMap),
                                                    "LLD_BLE_SetChannelMap");
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetChannel(RLV_Parameters_ptr->apStateMachineId,
                                                RLV_Parameters_ptr->channel,
                                                RLV_Parameters_ptr->channelIncrement),
                                                "LLD_BLE_SetChannel");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTxAttributes(RLV_Parameters_ptr->apStateMachineId,
                                                    RLV_Parameters_ptr->networkId,
                                                    RLV_Parameters_ptr->crcInit,
                                                    RLV_Parameters_ptr->sca),
                                                    "LLD_BLE_SetTxAttributes");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTx_Rx_Phy(RLV_Parameters_ptr->apStateMachineId,
                                                    RLV_Parameters_ptr->txPhy,
                                                    RLV_Parameters_ptr->rxPhy),
                                                    "LLD_BLE_SetTx_Rx_Phy");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetBackToBackTime(RLV_Parameters_ptr->backToBackTime),"LLD_BLE_SetBackToBackTime");
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTxPower(RLV_Parameters_ptr->txPower),"LLD_BLE_SetTxPower");
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
    //TODO: LLD_BLE_SetReservedArea/LLD_BLE_MakeActionPacketPending. how to use it? can we call several LLD_BLE_SetReservedArea with different action packet? as, in ap1, ap2, ap3.... if yes, before making the make action packet pending? after?
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetReservedArea(RLV_BLE_GetActionPacket(2)),"LLD_BLE_SetReservedArea");
    RLV_TFW__CALL_DID_NOT_CRASH(returnValue = LLD_BLE_MakeActionPacketPending(RLV_BLE_GetActionPacket(2)),"LLD_BLE_MakeActionPacketPending");
    RLV_LOG_LINE("returnValue for 'LLD_BLE_MakeActionPacketPending' = 0x%02x, possibles returns are:",returnValue);
    RLV_LOG_LINE("  - SUCCESS_0 (0x%02x)",SUCCESS_0);

    if(RLV_Parameters_ptr->crystalCheckEnabled)
    {
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_CrystalCheck(),"LLD_BLE_CrystalCheck");
    }
    
    if(RLV_Parameters_ptr->isGetStatusWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__GetStatus();
    }
    if(RLV_Parameters_ptr->isStopToneWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopTone();
    }
    if(RLV_Parameters_ptr->isStopActivityWhileBlockingCommandEnabled)
    {
        us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
        BLE_Step__StopActivity();
    }
  
    RLV_LOG_LINE("Waiting for a packet to be received...");//TODO : shall the Xtal check be in this while loop? (or schedule while waiting for the packet to be received?)
    for(uint16_t i = 0;RLV_TFW_IsAnActionPending() && (i < 10000);i++) us_delay(RLV_Parameters_ptr->rxReceiveWindow/10000+5);

    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_IsAnActionPending(),false);
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_HasAnActionFailed(),false);
    

    RLV_BLE__EXPECT_PACKETS_EQUAL(!RLV_TFW_HasAnActionFailed(), RLV_BLE_GetRxPacketBuffer(2), RLV_Parameters_ptr->rxExpectedHeader, RLV_Parameters_ptr->rxExpectedPayload.length, RLV_Parameters_ptr->rxExpectedPayload.content);

        
    if(RLV_Parameters_ptr->showRssi)
    {
        RLV_LOG_LINE("RSSI : [%d]",RLV_BLE_GetLastRssiInDbm());
    }
}

void BLE_Step__BuildActionPacketChainFromBuffer(void)
{    
    for (uint8_t storageIndex = 0; storageIndex < RLV_MAX_NUMBER_OF_STORED_DATA; storageIndex++)
    {
        RLV_BLE_SetNextActionPacketPointers(storageIndex);
        LLD_BLE_SetReservedArea(RLV_BLE_GetActionPacket(storageIndex));
    }
     RLV_LOG_LINE("Call to LLD_BLE_SetReservedArea did not crash"RLV_PASS_STRING);
}

void BLE_Step__BuildCurrentActionPacketInBuffer(void)
{
    RLV_BLE_SetDataRoutine(RLV_Parameters_ptr->apCurrentStorageIndex,RLV_Parameters_ptr->apDataRoutineType);
    RLV_BLE_SetCondRoutine(RLV_Parameters_ptr->apCurrentStorageIndex,RLV_Parameters_ptr->apCondRoutineType);
    RLV_BLE_SetNextIfTrueActionPacketIndex(RLV_Parameters_ptr->apCurrentStorageIndex,RLV_Parameters_ptr->apNextIfTrueStorageIndex);
    RLV_BLE_SetNextIfFalseActionPacketIndex(RLV_Parameters_ptr->apCurrentStorageIndex,RLV_Parameters_ptr->apNextIfFalseStorageIndex);
    RLV_BLE_SetCurrentActionPacketType(RLV_Parameters_ptr->apCurrentStorageIndex,RLV_Parameters_ptr->apCurrentType);
    RLV_BLE_BuildCurrentActionPacket(RLV_Parameters_ptr->apCurrentStorageIndex);
    RLV_LOG_LINE("Current packet built");
}

void BLE_Step__BuildStateMachine(void)
{
    uint8_t channelMap[RLV_Parameters_ptr->channelMap.length];
    memcpy(channelMap, RLV_Parameters_ptr->channelMap.content, sizeof(channelMap));
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetChannelMap(RLV_Parameters_ptr->apStateMachineId,
                                                    channelMap),
                                                    "LLD_BLE_SetChannelMap");
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetChannel(RLV_Parameters_ptr->apStateMachineId,
                                                RLV_Parameters_ptr->channel,
                                                RLV_Parameters_ptr->channelIncrement),
                                                "LLD_BLE_SetChannel");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTxAttributes(RLV_Parameters_ptr->apStateMachineId,
                                                    RLV_Parameters_ptr->networkId,
                                                    RLV_Parameters_ptr->crcInit,
                                                    RLV_Parameters_ptr->sca),
                                                    "LLD_BLE_SetTxAttributes");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTx_Rx_Phy(RLV_Parameters_ptr->apStateMachineId,
                                                    RLV_Parameters_ptr->txPhy,
                                                    RLV_Parameters_ptr->rxPhy),
                                                    "LLD_BLE_SetTx_Rx_Phy");

    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetBackToBackTime(RLV_Parameters_ptr->backToBackTime),"LLD_BLE_SetBackToBackTime");
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetTxPower(RLV_Parameters_ptr->txPower),"LLD_BLE_SetTxPower");
    
    if(RLV_Parameters_ptr->encryptStatus.value == ENABLE)
    {
        uint8_t txCounter[RLV_Parameters_ptr->encryptTxCounter.length];
        memcpy(txCounter, RLV_Parameters_ptr->encryptTxCounter.content, sizeof(txCounter));
        uint8_t rxCounter[RLV_Parameters_ptr->encryptRxCounter.length];
        memcpy(rxCounter, RLV_Parameters_ptr->encryptRxCounter.content, sizeof(rxCounter));
        uint8_t encInitVector[RLV_Parameters_ptr->encryptInitVector.length];
        memcpy(encInitVector, RLV_Parameters_ptr->encryptInitVector.content, sizeof(encInitVector));
        uint8_t encKey[RLV_Parameters_ptr->encryptKey.length];
        memcpy(encKey, RLV_Parameters_ptr->encryptKey.content, sizeof(encKey));
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionCount(RLV_Parameters_ptr->apStateMachineId,
                                                            txCounter,
                                                            rxCounter),
                                                            "LLD_BLE_SetEncryptionCount");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptionAttributes(RLV_Parameters_ptr->apStateMachineId, 
                                                            encInitVector,
                                                            encKey),
                                                            "LLD_BLE_SetEncryptionAttributes");
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_SetEncryptFlags(RLV_Parameters_ptr->apStateMachineId, 
                                                            RLV_Parameters_ptr->encryptStatus.value,
                                                            RLV_Parameters_ptr->encryptStatus.value),
                                                            "LLD_BLE_SetEncryptFlags");
    }
}

void BLE_Step__RunActionPacketChain(void)
{
    RLV_BLE_ResetBuffersAndCounters();
    RLV_TFW_SetPendingAction(RLV_Parameters_ptr->actionId,true);//set pending action (waiting for the callback of the end-of-chain to be called)
    RLV_TFW_SetFailedAction(RLV_Parameters_ptr->actionId,true); //action is failed until it is done with success
    uint8_t returnValue = 0;
    RLV_TFW__CALL_DID_NOT_CRASH(returnValue = LLD_BLE_MakeActionPacketPending(RLV_BLE_GetActionPacket(RLV_Parameters_ptr->apCurrentStorageIndex)),"LLD_BLE_MakeActionPacketPending");
    RLV_LOG_LINE("returnValue for 'LLD_BLE_MakeActionPacketPending' = 0x%02x, possibles returns are:",returnValue);
    RLV_LOG_LINE("  - SUCCESS_0 (0x%02x)",SUCCESS_0);
    RLV_LOG_LINE("  - RADIO_BUSY_C4 (0x%02x)",RADIO_BUSY_C4);
}

void BLE_Step__WaitForRadioToBeInIdle(void)
{
    uint32_t dummy;
    RLV_TIM__DO_WITH_TIMEOUT(RLV_Parameters_ptr->requestTimeoutInS/10,
        if(LLD_BLE_GetStatus(&dummy) != BLUE_IDLE_0) break;
    );
}

void BLE_Step__RunApChainAndWaitForItToFinish(void)
{
    BLE_Step__WaitForRadioToBeInIdle();
    BLE_Step__RunActionPacketChain();
    RLV_LOG_LINE("Waiting for action to be completed...");
    RLV_TIM__DO_WITH_TIMEOUT(RLV_Parameters_ptr->requestTimeoutInS,
        if(RLV_Parameters_ptr->isGetStatusWhileBlockingCommandEnabled)
        {
            us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
            BLE_Step__GetStatus();
        }
        if(RLV_Parameters_ptr->isStopToneWhileBlockingCommandEnabled)
        {
            us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
            BLE_Step__StopTone();
        }
        
        if(RLV_Parameters_ptr->isStopActivityWhileBlockingCommandEnabled)
        {
            us_delay(RLV_Parameters_ptr->delayBeforeCallingFlashCommand);//waiting for window to be set
            BLE_Step__StopActivity();
        }
        if(!RLV_TFW_IsAnActionPending()) break;
    );
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_IsAnActionPending(),false);
    RLV_TFW__EXPECT_INT_EQUAL(RLV_TFW_HasAnActionFailed(),false);
}

    
void BLE_Step__GetStatus(void)
{
    uint32_t time;
    uint8_t returnValue;
    RLV_TFW__CALL_DID_NOT_CRASH(returnValue = LLD_BLE_GetStatus(&time),
                                                    "LLD_BLE_GetStatus");
    RLV_LOG_LINE("returnValue for 'LLD_BLE_GetStatus' = 0x%02x, possibles returns are:",returnValue);
    RLV_LOG_LINE("  - BLUE_IDLE_0 (0x%02x)",BLUE_IDLE_0);
    RLV_LOG_LINE("  - BLUE_BUSY_NOWAKEUP_T1 (0x%02x)",BLUE_BUSY_NOWAKEUP_T1);
    RLV_LOG_LINE("  - BLUE_BUSY_NOWAKEUP_T2 (0x%02x)",BLUE_BUSY_NOWAKEUP_T2);
    RLV_LOG_LINE("  - BLUE_BUSY_WAKEUP (0x%02x)",BLUE_BUSY_WAKEUP);
    RLV_LOG_LINE("time modified by 'LLD_BLE_GetStatus' = 0x%02x",time);
}

void BLE_Step__StartTone(void)
{
    uint8_t returnValue;
    RLV_TFW__CALL_DID_NOT_CRASH(returnValue = LLD_BLE_StartTone(RLV_Parameters_ptr->channel,RLV_Parameters_ptr->txPower),
                                "LLD_BLE_StartTone");
    RLV_LOG_LINE("returnValue for 'LLD_BLE_StartTone' = 0x%02x, possibles returns are:",returnValue);
    RLV_LOG_LINE("  - SUCCESS_0 (0x%02x)",SUCCESS_0);
}

void BLE_Step__StopTone(void)
{
    RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_StopTone(),
                                "LLD_BLE_StopTone");
}

void BLE_Step__StopActivity(void)
{
    uint8_t returnValue;
    RLV_TFW__CALL_DID_NOT_CRASH(returnValue = LLD_BLE_StopActivity(),
                                "LLD_BLE_StopActivity");
    RLV_LOG_LINE("returnValue for 'LLD_BLE_StopActivity' = 0x%02x, possibles returns are:",returnValue);
    RLV_LOG_LINE("  - TRUE (0x%02x)",TRUE);
}

void BLE_Step__EncryptPlainData(void)
{
    if((RLV_Parameters_ptr->encryptPlainData.length != ENCRYPTION_DATA_SIZE) ||
       (RLV_Parameters_ptr->encryptExpectedData.length != ENCRYPTION_DATA_SIZE))
    {
        RLV_LOG_ERROR("encryptPlainData and encryptExpectedData shall have a size of 128 bits, thus 16 bytes");
    }
    else
    {
        RLV_PRINT_LOG();
        bool encryptedPacketAsExpected = true;
        uint8_t encryptedData[ENCRYPTION_DATA_SIZE];
        
        RLV_TFW__CALL_DID_NOT_CRASH(LLD_BLE_EncryptPlainData(RLV_Parameters_ptr->encryptKey.content, 
                                                             RLV_Parameters_ptr->encryptPlainData.content,
                                                             encryptedData),
                                    "LLD_BLE_EncryptPlainData");
            
        for (uint8_t byteIndex = 0; byteIndex < ENCRYPTION_DATA_SIZE; byteIndex++) //for each 16 bytes in block
        {
            if(encryptedData[byteIndex] != RLV_Parameters_ptr->encryptExpectedData.content[byteIndex])
            {
                encryptedPacketAsExpected = false;
                break;
            }
        }

        RLV_LOG_LINE("Checking plain data encryption");
        if(encryptedPacketAsExpected)
        {
            RLV_APPEND_LOG(RLV_PASS_STRING);
        }
        else
        {
            RLV_APPEND_LOG(RLV_FAILS_STRING);
            RLV_SHOW_ARRAY(RLV_Parameters_ptr->encryptExpectedData.content,RLV_Parameters_ptr->encryptExpectedData.length);
            RLV_SHOW_ARRAY(encryptedData,RLV_Parameters_ptr->encryptExpectedData.length);
        }
        RLV_PRINT_LOG();
    }
}


void BLE_Step__CompareReceivedPacket(void)
{
    RLV_BLE__EXPECT_PACKETS_EQUAL(!RLV_TFW_HasAnActionFailed(),
                                  RLV_BLE_GetRxPacketBuffer(RLV_Parameters_ptr->apCurrentStorageIndex),
                                  RLV_BLE_GetExpectedHeader(RLV_Parameters_ptr->apCurrentStorageIndex),
                                  RLV_BLE_GetExpectedLength(RLV_Parameters_ptr->apCurrentStorageIndex), 
                                  RLV_BLE_GetExpectedPayload(RLV_Parameters_ptr->apCurrentStorageIndex));
    
    RLV_SHOW_ARRAY((uint8_t*)(RLV_BLE_GetRxPacketBuffer(RLV_Parameters_ptr->apCurrentStorageIndex) + 2),(uint8_t)*(RLV_BLE_GetRxPacketBuffer(RLV_Parameters_ptr->apCurrentStorageIndex)+1));
    RLV_SHOW_ARRAY(RLV_BLE_GetExpectedPayload(RLV_Parameters_ptr->apCurrentStorageIndex),RLV_BLE_GetExpectedLength(RLV_Parameters_ptr->apCurrentStorageIndex));
    if(RLV_Parameters_ptr->showRssi)
    {
        RLV_LOG_LINE("RSSI : [%d]",RLV_BLE_GetLastRssiInDbm());
    }
}

void BLE_Step__ShowStressResults(void)
{
    RLV_LOG_LINE("Stress results:");
    RLV_LOG_LINE("- rxCounter %u",RLV_Parameters_ptr->rxCounter);
    RLV_LOG_LINE("- txSuccessCounter %u",RLV_Parameters_ptr->txSuccessCounter);
    RLV_LOG_LINE("- rxSuccessCounter %u",RLV_Parameters_ptr->rxSuccessCounter);
}




#endif //RF_LLD_VALIDATION