/**
  ******************************************************************************
  * @file    RLV_TestFramework.h
  * @author  MCD Application Team
  * @brief   TODO
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_TEST_FRAMEWORK_H_
#define RLV_TEST_FRAMEWORK_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include "RLV_Logger.h"
    
#include "RLV_TFW_Data.h"
#include "RLV_TFW_Types.h"
    
#ifdef USE_PROTOCOL_BLE
    #include "RLV_BLE_Data.h"
    #include "RLV_BLE_Types.h"
#endif
#ifdef USE_PROTOCOL_802154
    #include "RLV_154_Data.h"
    #include "RLV_154_Types.h"
#endif

////////////////////////////////////////////////////////////////////////////////
//////////////////                Special Macros              //////////////////
////////////////////////////////////////////////////////////////////////////////
#define RLV_TFW__RESET_SYSTEM(msg)                                             \
do{                                                                            \
    RLV_LOG_LINE("%s, reseting M0 & M4",msg);                                  \
    RLV_PRINT_LOG();                                                           \
    us_delay(50000);                                                           \
    HAL_NVIC_SystemReset();                                                    \
}while(0)

#define RLV_TFW__RESET_WITH_FATAL_ERROR(msg)                                   \
RLV_TFW__RESET_SYSTEM("FATAL ERROR! %s",msg)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Test Macros                //////////////////
////////////////////////////////////////////////////////////////////////////////
#define RLV_TFW__EXPECT_INT_EQUAL(observed,expected) \
RLV_LOG_LINE("Checking that "#observed" (=%u) is equal to "#expected" (=%u)%s", \
  (uint32_t)observed,(uint32_t)expected,(expected == observed) ? RLV_PASS_STRING:RLV_FAILS_STRING)
#define RLV_TFW__EXPECT_INT_NOT_EQUAL(observed,expected) \
RLV_LOG_LINE("Checking that "#observed" (=%u) is not equal to "#expected" (=%u)%s", \
  (uint32_t)observed,(uint32_t)expected,(expected != observed) ? RLV_PASS_STRING:RLV_FAILS_STRING)

#define RLV_TFW__CALL_DID_NOT_CRASH(function,function_name)  \
do{ \
    function; \
    RLV_LOG_LINE("Function call to '%s' did not crash"RLV_PASS_STRING, function_name); \
}while(0)


#define RLV_TFW__RUN_STEP(step_name) \
step_name()

#define RLV_TFW__PRINT_STATUS()  \
do{ \
RLV_LOG_LINE("p->status :"); \
if (p->status & IRQ_RCV_OK         ) RLV_LOG_LINE("IRQ_RCV_OK      "); \
if (p->status & IRQ_CRC_ERR        ) RLV_LOG_LINE("IRQ_CRC_ERR     "); \
if (p->status & IRQ_RCV_TRIG       ) RLV_LOG_LINE("IRQ_RCV_TRIG    "); \
if (p->status & IRQ_CMD            ) RLV_LOG_LINE("IRQ_CMD         "); \
if (p->status & IRQ_MD             ) RLV_LOG_LINE("IRQ_MD          "); \
if (p->status & IRQ_TIMEOUT        ) RLV_LOG_LINE("IRQ_TIMEOUT     "); \
if (p->status & IRQ_RCV_FAIL       ) RLV_LOG_LINE("IRQ_RCV_FAIL    "); \
if (p->status & IRQ_DONE           ) RLV_LOG_LINE("IRQ_DONE        "); \
if (p->status & IRQ_ERR_ENC        ) RLV_LOG_LINE("IRQ_ERR_ENC     "); \
if (p->status & IRQ_TX_OK          ) RLV_LOG_LINE("IRQ_TX_OK       "); \
if (p->status & BIT_TX_SKIP        ) RLV_LOG_LINE("BIT_TX_SKIP     "); \
if (p->status & IRQ_CONFIG_ERR     ) RLV_LOG_LINE("IRQ_CONFIG_ERR  "); \
if (p->status & BIT_TX_MODE        ) RLV_LOG_LINE("BIT_TX_MODE     "); \
if (p->status & BIT_TIME_OVERRUN   ) RLV_LOG_LINE("BIT_TIME_OVERRUN"); \
if (p->status & BIT_ACT2_ERROR     ) RLV_LOG_LINE("BIT_ACT2_ERROR  "); \
if (p->status & IRQ_WAKEUP_2       ) RLV_LOG_LINE("IRQ_WAKEUP_2    "); \
if (p->status & BIT_AES_READY      ) RLV_LOG_LINE("BIT_AES_READY   "); \
}while(0)
////////////////////////////////////////////////////////////////////////////////
//////////////////               Polymorpher Macro            //////////////////
////////////////////////////////////////////////////////////////////////////////
#define  DO_(function, type, data,arg) \
function##type((type*)&data,arg)
#define  DO_AUTO_(function,data,arg)   \
_Generic((&data)+0,  \
_Bool* : DO_(function, _Bool, data,arg), \
FunctionalState_t * : DO_(function, FunctionalState_t, data,arg), \
apDataRoutine_e_t * : DO_(function, apDataRoutine_e_t, data,arg), \
apCondRoutine_e_t * : DO_(function, apCondRoutine_e_t, data,arg), \
actionPacket_e_t * : DO_(function, actionPacket_e_t, data,arg), \
uint8_t* : DO_(function, uint8_t, data,arg), \
uint16_t* : DO_(function, uint16_t, data,arg), \
uint32_t* : DO_(function, uint32_t, data,arg), \
array_uint8_t * : DO_(function, array_uint8_t, data,arg), \
array_uint16_t* : DO_(function, array_uint16_t, data,arg), \
array_uint32_t* : DO_(function, array_uint32_t, data,arg))

#define RLV_SHOW_ARRAY(val,size) \
do { \
    RLV_LOG_LINE(#val); \
    RLV_APPEND_LOG("[%u] = {",size); \
    uint16_t i; \
    for(i = 0; (i < RLV_MAX_DISPLAYABLE_ARR_SIZE)&&(i < size); i++) \
    { \
        RLV_APPEND_LOG("0x%x",val[i]); \
        if((i +1 < RLV_MAX_DISPLAYABLE_ARR_SIZE) && (i + 1 < size)) {RLV_APPEND_LOG(",");} \
    } \
    if(i == size) \
    { \
        RLV_APPEND_LOG("}"); \
    } \
    else \
    { \
        RLV_APPEND_LOG(",...}"); \
    } \
} while(0)

////////////////////////////////////////////////////////////////////////////////
//////////////////                Print generation            //////////////////
////////////////////////////////////////////////////////////////////////////////    
#define  print_param_(param) RLV_Parameters_ptr->displayArrayWithChar ? DO_AUTO_(print_,param,"'%c'"):DO_AUTO_(print_,param,"0x%02x")

#define RLV_SHOW_PARAM(paramName) do{ RLV_LOG_LINE(#paramName); print_param_(RLV_Parameters_ptr->paramName);}while(0)

////////////////////////////////////////////////////////////////////////////////
//////////////////              Set Param generation          //////////////////
////////////////////////////////////////////////////////////////////////////////
#define add_from_arg_param_(param,gen_current_cli_arg_) \
DO_AUTO_(add_from_arg_,param,gen_current_cli_arg_)

#define add_param_from_arg_with_default_and_preset(param_name,gen_current_cli_arg_)  \
do { \
    if(!strcmp(gen_current_cli_arg_,"D"))   \
    {   \
         memcpy(&RLV_Parameters_ptr->param_name, \
                &RLV_DefaultParameters_ptr->param_name, \
                sizeof(RLV_DefaultParameters_ptr->param_name)); \
    }   \
    else if(!strcmp(gen_current_cli_arg_,"P"))   \
    {   \
    }   \
    else   \
    {   \
        add_from_arg_param_(RLV_Parameters_ptr->param_name,gen_current_cli_arg_); \
    } \
}while(0)

#define RLV_TFW__ADD_CMD_ARG_PARAM(param_name)  \
do{ \
    if(argListIndex_ > argNumber ) \
    { \
        RLV_LOG_ERROR("Number of param set (%u) is above predefined number of params (%u), please check your command's parameters in the code.",argListIndex_,argNumber); \
    } \
    else \
    { \
        char * gen_current_cli_arg_ = argList[argListIndex_]; \
        add_param_from_arg_with_default_and_preset(param_name,gen_current_cli_arg_); \
        RLV_SHOW_PARAM(param_name); \
        argListIndex_++; \
    } \
}while(0)

#endif // RLV_TEST_FRAMEWORK_H_
#endif // RF_LLD_VALIDATION

