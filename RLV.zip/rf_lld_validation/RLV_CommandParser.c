/*******************************************************************************
* @file    TODO.c
* @author  MCD Application Team
* @brief   The aim of this module is to link CLI command + arg to functions.
*          Functions which contain tests or/and steps.
********************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2019 STMicroelectronics. 
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the 
* License. You may obtain a copy of the License at:
*                opensource.org/licenses/BSD-3-Clause
*
*******************************************************************************/
  
#if defined(RF_LLD_VALIDATION)

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include "config_rlv.h"

#ifdef USE_PROTOCOL_802154
    #include "ip802154_lld.h"
    #include "ip802154_lld_priv.h"
    #include "ip802154_lld_registers.h"
    #include "ip802154_phy_valid.h"
#endif //USE_PROTOCOL_802154
#ifdef USE_PROTOCOL_BLE
    #include "ipBLE_lld.h"
    #include "hal_BLE.h"
#endif //USE_PROTOCOL_BLE


#include "RLV_CommandParser.h"
#include "RLV_TFW_Commandlist.h"
#include "RLV_TestFramework.h"
#include "RLV_Logger.h"
#ifdef USE_PROTOCOL_BLE
#include "RLV_BLE_Commandlist.h"
#endif
#ifdef USE_PROTOCOL_802154
#include "RLV_154_Commandlist.h"
#endif

////////////////////////////////////////////////////////////////////////////////
//////////////////                  Types                     //////////////////
////////////////////////////////////////////////////////////////////////////////

typedef void (*callback_t)(char **, uint8_t);

typedef struct 
{
    char *        name;                        // command name
    callback_t    Callback;                    // command callback
    uint32_t      argNumber;                   // number of arguments for this command
    char *        use;                         // information about command use--> '[command] <init_time[0;100]> <n_packet_to_send{1,2,10,1000}>'
    char *        purpose;                     // information about command purpose --> 'this command is an example'
} command_t;


////////////////////////////////////////////////////////////////////////////////
//////////////////              Private variables             //////////////////
////////////////////////////////////////////////////////////////////////////////
static command_t commands[] =
{
    LIST_TFW_commands(INIT_command)
#ifdef USE_PROTOCOL_BLE
    LIST_BLE_commands(INIT_command)
#endif
#ifdef USE_PROTOCOL_802154
    LIST_154_commands(INIT_command)
#endif
};

////////////////////////////////////////////////////////////////////////////////
//////////////////             Private functions              //////////////////
////////////////////////////////////////////////////////////////////////////////
static void cliHelp(void)
{
    RLV_LOG_LINE(" - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
    RLV_LOG_LINE(" RLV is a Command Line Interface for RF LLD Validation");
    RLV_LOG_LINE(" - Type 'List' to get the full command list");
    RLV_LOG_LINE(" - Type <command name> 'Help' to get more information about a command");
    RLV_LOG_LINE(" - Type <command name> to run the command with preset value for all args"); 
    RLV_LOG_LINE(" - Type <command name> <arg1> P <arg3> to get command with your custom arg1 and arg3, and with preset value for arg2"); 
    RLV_LOG_LINE(" - Type <command name> D <arg2> <arg3> to get command with your custom arg2 and arg3, and with default value for arg1"); 
    RLV_LOG_LINE(" - Result per step is [OK], [FAILS], or [SKIPPED]");
    RLV_LOG_LINE(" - Type 'Help' to get this message");
    RLV_LOG_LINE(" - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
    return;
}


////////////////////////////////////////////////////////////////////////////////
//////////////////             Public functions               //////////////////
////////////////////////////////////////////////////////////////////////////////

void RLV_ParseCommandArgsAndRunCommand(char * commandString, uint16_t commandLength)
{

    
    
    //parsing starts
    char *      currentCommandArgList[CMD_ARG_NUMBER_MAX] = {0}; //  current argument list (cmd + arg)
    char *      cmdToken;
    uint8_t     argIndex = 0;

    if ( commandLength == 0 )
    {
        RLV_LOG_ERROR("Command length must not be null, please check your command syntax");
        cliHelp();
    }
    else if (!strcmp(commandString, "info\0") ||
             !strcmp(commandString, "Info\0"))
    {
        HOST_LldTests_PrintInfo(1);
    }
    else if (!strcmp(commandString, "List\0") ||
             !strcmp(commandString, "list\0"))
    {
        RLV_LOG_LINE("Listing CLI commands :");
        for(uint16_t commandId = 0 ; commandId < sizeof(commands)/sizeof(command_t); commandId++)
        {
            RLV_LOG_LINE(" - %s", commands[commandId].name);
        }
    }
    else if (!strcmp(commandString, "help\0") ||
             !strcmp(commandString, "Help\0") )
    {
        cliHelp();
    }
    else 
    {
        //clean the buffer
        memset(currentCommandArgList,0,sizeof(currentCommandArgList));
        // Fill the arg list array
        cmdToken = strtok(commandString, " ");
        while(cmdToken != NULL)
        {
            currentCommandArgList[argIndex++] = cmdToken;
            cmdToken = strtok(NULL, " ");
        }
        
        // Check if currentCommandArgList not empty
        if(sizeof(currentCommandArgList) == 0)
        {
            RLV_LOG_ERROR("There is no command provided in the M0 source code, please check the M0 code");
        }
        else
        {
            // Find the command
            bool wasCommandFound = false;
            uint16_t commandId;

            for (commandId = 0; commandId < sizeof(commands)/sizeof(command_t); commandId++) 
            {
                if(!strcmp(currentCommandArgList[0],commands[commandId].name))
                {
                    wasCommandFound = true;
                    break;
                }
            }
            // Check the command syntax
            if(!wasCommandFound)
            {
                RLV_LOG_ERROR("Command name was not found, please check your command syntax");
                cliHelp();
            }
            else  if((sizeof(currentCommandArgList[0]) >= 1) && (!strcmp(currentCommandArgList[1],"Help") || !strcmp(currentCommandArgList[1],"help")))
            {
                RLV_LOG_LINE("------------------------------------------");
                RLV_LOG_LINE("  - Purpose: %s", commands[commandId].purpose);
                RLV_LOG_LINE("  - Arguments: %s",commands[commandId].use);
            }
            else if((argIndex - 1 != commands[commandId].argNumber) && (argIndex - 1 != 0))
            {
                RLV_LOG_ERROR("%d args were provided, not %d nor 0, please check your command syntax",argIndex - 1,commands[commandId].argNumber);
            }
            else if(commands[commandId].Callback == NULL)
            {
                RLV_LOG_ERROR("callback for command is not defined, please check the M0 code");
            }
            else
            {
                RLV_LOG_LINE("------------------- Running command '%s':", commands[commandId].name);
                RLV_PRINT_LOG(); //flush buffer before entering in command callback
                commands[commandId].Callback(&currentCommandArgList[1], argIndex - 1); //pass only arguments
                RLV_LOG_LINE("------------------- End of command");
                RLV_LOG_LINE(" ");
            }
        }
    }
    RLV_PRINT_LOG();//display log once command callback is called 
    return;
}


#endif //RF_LLD_VALIDATION