/**
  ******************************************************************************
  * @file    TODO.h
  * @author  MCD Application Team
  * @brief   TODO
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

#if defined(RF_LLD_VALIDATION)
#ifndef RLV_BLE_TYPES_H_
#define RLV_BLE_TYPES_H_

////////////////////////////////////////////////////////////////////////////////
//////////////////                 Includes                   //////////////////
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//////////////////                  Types                     //////////////////
////////////////////////////////////////////////////////////////////////////////
typedef uint8_t (*apDataRoutine_t)(ActionPacket*, ActionPacket*);
typedef uint8_t (*apCondRoutine_t)(ActionPacket*);

#define LIST_apDataRoutine_e(X) \
        X(APDR_NULL) \
        X(APDR_SIMPLE_RET_TRUE) \
        X(APDR_SIMPLE_RET_FALSE) \
        X(APDR_CLEAR_FLAG_IF_IRQ_DONE) \
        X(APDR_CLEAR_FLAG_IF_TXRX_ACTION_DONE) \
        X(APDR_JUST_CLEAR_FLAGS) \
        X(APDR_INC_CHANNEL) \
        X(APDR_INC_RXTX_COUNTER)

#define LIST_apCondRoutine_e(X) \
        X(APCR_NULL) \
        X(APCR_SIMPLE_RET_TRUE) \
        X(APCR_SIMPLE_RET_FALSE) \
        X(APCR_RET_TRUE_IF_SUCCESS) \
        X(APCR_RET_TRUE_IF_PACKET_AS_EXPECTED) \
        X(APCR_RET_TRUE_IF_STRESS_TIMES_OUT)
          
#define LIST_actionPacket_e(X) \
        X(AP_UNINITIALIZED) \
        X(AP_EMPTY) \
        X(AP_END) \
        X(AP_TXRX)

#define LIST_FunctionalState(X) \
        X(ENABLE) \
        X(DISABLE)
          
DEF_x_e(apDataRoutine_e);
DEF_x_e(apCondRoutine_e);
DEF_x_e(actionPacket_e);

DEF_x_st(FunctionalState);
DEF_x_st(apDataRoutine_e);
DEF_x_st(apCondRoutine_e);
DEF_x_st(actionPacket_e);

#endif // RLV_BLE_TYPES_H_
#endif // RF_LLD_VALIDATION

